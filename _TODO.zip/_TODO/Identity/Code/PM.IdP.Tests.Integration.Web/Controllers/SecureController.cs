﻿using System.Web.Mvc;

namespace PM.IdP.Tests.Integration.Web.Controllers
{
    [Authorize]
    public class SecureController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}