﻿using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OpenIdConnect;
using Owin;

namespace PM.IdP.Tests.Integration.Web
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.UseCookieAuthentication(new CookieAuthenticationOptions
                                        {
                                            AuthenticationType = "Cookies"
                                        })
               .UseOpenIdConnectAuthentication(new OpenIdConnectAuthenticationOptions
                                               {
                                                   Authority = "https://localhost:44320/Identity",
                                                   ClientId = "test-website",
                                                   SignInAsAuthenticationType = "Cookies",
                                                   RedirectUri = "https://localhost:44307"
                                               });
        }
    }
}