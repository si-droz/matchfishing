﻿using System;
using System.Collections.Generic;
using System.Web.Http.Dependencies;
using Microsoft.Practices.Unity;

namespace PartnerAccess.Identity.Common.DependencyResolution
{
    public class UnityDependencyScope : IDependencyScope
    {
        private readonly IUnityContainer _childContainer;

        public UnityDependencyScope(IUnityContainer childContainer)
        {
            _childContainer = childContainer;
        }

        public object GetService(Type serviceType)
        {
            try
            {
                return _childContainer.Resolve(serviceType);
            }
            catch(ResolutionFailedException)
            {
                return null;
            }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            try
            {
                return _childContainer.ResolveAll(serviceType);
            }
            catch(ResolutionFailedException)
            {
                return null;
            }
        }

        public void Dispose()
        {
            _childContainer.Dispose();
        }
    }
}