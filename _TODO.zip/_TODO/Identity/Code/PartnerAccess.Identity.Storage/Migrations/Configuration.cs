using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using PartnerAccess.Identity.Storage.Data.Implementation;
using PartnerAccess.Identity.Storage.Entitites;

namespace PartnerAccess.Identity.Storage.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<IdentityProviderServiceContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "PartnerAccess.Identity.Storage.Data.Implementation.IdentityProviderServiceContext";
        }

        protected override void Seed(IdentityProviderServiceContext context)
        {
            //Scopes
            var openIdScope = new StorageScope
            {
                ExternalId = Guid.Parse("3589BDFC-0BBA-4CF0-AE24-64257CF3C6D9"),
                Name = "openid"
            };
            var nameScope = new StorageScope
            {
                ExternalId = Guid.Parse("2BBDA6BA-7610-42E0-A856-315AA9EB3DA3"),
                Name = "name"
            };
            var profileScope = new StorageScope
            {
                ExternalId = Guid.Parse("F5800CA6-1F52-40B6-8DCA-EEB84934A762"),
                Name = "profile"
            };
            var partnerServiceApiScope = new StorageScope
            {
                ExternalId = Guid.Parse("D24476C4-7F5E-4103-A19D-B5EF2CFADD41"),
                Name = "partner-access-partner-service-api"
            };
            var partnerAccessSimsPrimaryApi = new StorageScope
            {
                ExternalId = Guid.Parse("C53DF7CD-EB8D-4BD0-8816-A22319F9FC25"),
                Name = "partner-access-sims-primary-api"
            };
            var partnerManagementAccessServiceApi = new StorageScope
            {
                ExternalId = Guid.Parse("08521C03-743E-499E-8820-4C7B834A6166"),
                Name = "partner-management-access-service-api"
            };

            context.Scopes.AddOrUpdate(scopes => scopes.ExternalId, openIdScope);
            context.Scopes.AddOrUpdate(scopes => scopes.ExternalId, nameScope);
            context.Scopes.AddOrUpdate(scopes => scopes.ExternalId, profileScope);
            context.Scopes.AddOrUpdate(scopes => scopes.ExternalId, partnerServiceApiScope);
            context.Scopes.AddOrUpdate(scopes => scopes.ExternalId, partnerAccessSimsPrimaryApi);
            context.Scopes.AddOrUpdate(scopes => scopes.ExternalId, partnerManagementAccessServiceApi);

            //Client Types
            var hybridFlowType = new StorageClientSecurityFlowType
            {
                ExternalId = Guid.Parse("5F3F1133-6BC8-4346-A6FD-6CF844DCDD36"),
                FlowType = "Hybrid"
            };
            var clientCredentialsFlowType = new StorageClientSecurityFlowType
            {
                ExternalId = Guid.Parse("34AA9195-4A68-403C-857E-E6088BBA4A50"),
                FlowType = "ClientCredentials"
            };

            context.ClientSecurityFlowTypes.AddOrUpdate(flow => flow.FlowType, hybridFlowType);
            context.ClientSecurityFlowTypes.AddOrUpdate(flow => flow.FlowType, clientCredentialsFlowType);

#if DEBUG
            //Clients if in Debug build configuration
            context.Clients.AddOrUpdate(client => client.ExternalId, new StorageClient
            {
                ExternalId = Guid.Parse("FD59D1C2-7A8B-49C5-A53A-E92B40A3A71A"),
                Enabled = true,
                SecurityFlowType = hybridFlowType,
                Name = "Partner's Management Portal",
                IdentityProviderNames = IdentityProviderNames.AzureActiveDirectoryIdentityProviderName,
                ClientId = "partners-management-portal",
                RedirectUris = new List<StorageRedirecturi>
                                    {
                                        new StorageRedirecturi
                                        {
                                            ExternalId = Guid.Parse("6A966DCE-75A4-4FAE-B79D-7AAF89DED259"),
                                            Uri = "https://pm-dev.azurewebsites.net"
                                        }
                                    },
                AllowedScopes = new List<StorageScope>
                                    {
                                        openIdScope,
                                        nameScope,
                                        profileScope,
                                        partnerServiceApiScope
                                    }
            });
            
            // THOUGHT: this is wrapped in an if debug; how would this get deployed to live? It would need different GUIDs
            context.Clients.AddOrUpdate(client => client.ExternalId, new StorageClient
            {
                ExternalId = Guid.Parse("40C6716E-C4BE-4332-9C35-5A1222F65EEA"),
                Enabled = true,
                SecurityFlowType = clientCredentialsFlowType,
                Name = "Service API Administration Access",
                IdentityProviderNames = IdentityProviderNames.BuiltInIdentityProviderName,
                ClientId = "partners-management-service-api",
                AllowedScopes = new List<StorageScope>
                                    {
                                        partnerManagementAccessServiceApi
                                    },
                Secrets = new List<StorageSecret>
                                {
                                    new StorageSecret
                                    {
                                        ExternalId = Guid.Parse("4BBAA093-A689-4EBB-8AE1-43B592CE3DE9"),
                                        Secret = "3B487F46-EAD1-4F3E-92BA-456FEB495238"
                                    }
                                }
            });
#endif
        }
    }
}