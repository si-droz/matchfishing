namespace PartnerAccess.Identity.Storage.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Clients",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ExternalId = c.Guid(nullable: false),
                        Name = c.String(nullable: false),
                        ClientId = c.String(nullable: false, maxLength: 100),
                        Enabled = c.Boolean(nullable: false),
                        IdentityProviderNames = c.String(nullable: false),
                        SecurityFlowType_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.ClientFlowType", t => t.SecurityFlowType_Id, cascadeDelete: true)
                .Index(t => t.ExternalId)
                .Index(t => t.SecurityFlowType_Id);
            
            CreateTable(
                "dbo.Scopes",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ExternalId = c.Guid(nullable: false),
                        Name = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.ExternalId)
                .Index(t => t.Name);
            
            CreateTable(
                "dbo.RedirectUris",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ExternalId = c.Guid(nullable: false),
                        Uri = c.String(nullable: false),
                        StorageClient_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Clients", t => t.StorageClient_Id)
                .Index(t => t.ExternalId)
                .Index(t => t.StorageClient_Id);
            
            CreateTable(
                "dbo.Secrets",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ExternalId = c.Guid(nullable: false),
                        Secret = c.String(nullable: false),
                        StorageClient_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Clients", t => t.StorageClient_Id)
                .Index(t => t.ExternalId)
                .Index(t => t.StorageClient_Id);
            
            CreateTable(
                "dbo.ClientFlowType",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        ExternalId = c.Guid(nullable: false),
                        FlowType = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.ExternalId);
            
            CreateTable(
                "dbo.ClientToScopes",
                c => new
                    {
                        ClientId = c.Int(nullable: false),
                        ScopeId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.ClientId, t.ScopeId })
                .ForeignKey("dbo.Clients", t => t.ClientId, cascadeDelete: true)
                .ForeignKey("dbo.Scopes", t => t.ScopeId, cascadeDelete: true)
                .Index(t => t.ClientId)
                .Index(t => t.ScopeId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Clients", "SecurityFlowType_Id", "dbo.ClientFlowType");
            DropForeignKey("dbo.Secrets", "StorageClient_Id", "dbo.Clients");
            DropForeignKey("dbo.RedirectUris", "StorageClient_Id", "dbo.Clients");
            DropForeignKey("dbo.ClientToScopes", "ScopeId", "dbo.Scopes");
            DropForeignKey("dbo.ClientToScopes", "ClientId", "dbo.Clients");
            DropIndex("dbo.ClientToScopes", new[] { "ScopeId" });
            DropIndex("dbo.ClientToScopes", new[] { "ClientId" });
            DropIndex("dbo.ClientFlowType", new[] { "ExternalId" });
            DropIndex("dbo.Secrets", new[] { "StorageClient_Id" });
            DropIndex("dbo.Secrets", new[] { "ExternalId" });
            DropIndex("dbo.RedirectUris", new[] { "StorageClient_Id" });
            DropIndex("dbo.RedirectUris", new[] { "ExternalId" });
            DropIndex("dbo.Scopes", new[] { "Name" });
            DropIndex("dbo.Scopes", new[] { "ExternalId" });
            DropIndex("dbo.Clients", new[] { "SecurityFlowType_Id" });
            DropIndex("dbo.Clients", new[] { "ExternalId" });
            DropTable("dbo.ClientToScopes");
            DropTable("dbo.ClientFlowType");
            DropTable("dbo.Secrets");
            DropTable("dbo.RedirectUris");
            DropTable("dbo.Scopes");
            DropTable("dbo.Clients");
        }
    }
}
