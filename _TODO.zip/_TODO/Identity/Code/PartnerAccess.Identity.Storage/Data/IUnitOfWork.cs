using System;
using System.Threading;
using System.Threading.Tasks;

namespace PartnerAccess.Identity.Storage.Data
{
    public interface IUnitOfWork : IDisposable
    {
        IRepository<T> GetRepository<T>() where T : class;

        Task<int> SaveAsync();
        Task<int> SaveAsync(CancellationToken cancellationToken);
    }
}