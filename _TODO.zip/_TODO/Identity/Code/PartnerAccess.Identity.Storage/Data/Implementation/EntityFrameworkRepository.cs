﻿using System.Data.Entity;
using System.Linq;

namespace PartnerAccess.Identity.Storage.Data.Implementation
{
    internal class EntityFrameworkRepository<T> : IRepository<T> where T : class
    {
        private readonly IDbSet<T> _dbSet;

        public EntityFrameworkRepository(IDbSet<T> dbSet)
        {
            _dbSet = dbSet;
        }

        public IQueryable<T> All => _dbSet;

        public void Add(T entity)
        {
            _dbSet.Add(entity);
        }
    }
}