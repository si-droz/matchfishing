﻿using System.Data.Entity;
using PartnerAccess.Identity.Storage.Entitites;

namespace PartnerAccess.Identity.Storage.Data.Implementation
{
    internal class IdentityProviderServiceContext : DbContext
    {
        public IdentityProviderServiceContext()
        {
        }

        public IdentityProviderServiceContext(string connectionString) : base(connectionString)
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<StorageClient>()
                        .HasMany(client => client.AllowedScopes)
                        .WithMany()
                        .Map(x =>
                             {
                                 x.ToTable("ClientToScopes");
                                 x.MapLeftKey("ClientId");
                                 x.MapRightKey("ScopeId");
                             });

            base.OnModelCreating(modelBuilder);
        }

        public IDbSet<StorageClient> Clients { get; set; }
        public IDbSet<StorageClientSecurityFlowType> ClientSecurityFlowTypes { get; set; }
        public IDbSet<StorageRedirecturi> RedirectUris { get; set; }
        public IDbSet<StorageSecret> Secrets { get; set; }
        public IDbSet<StorageScope> Scopes { get; set; }
    }
}