﻿namespace PartnerAccess.Identity.Storage.Data.Implementation
{
    internal class UnitOfWorkFactory : IUnitOfWorkFactory
    {
        public IUnitOfWork GetUnitOfWork()
        {
            return new UnitOfWork(new IdentityProviderServiceContext());
        }
    }
}