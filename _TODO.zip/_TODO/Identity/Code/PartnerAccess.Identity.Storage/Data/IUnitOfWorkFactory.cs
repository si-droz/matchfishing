﻿namespace PartnerAccess.Identity.Storage.Data
{
    public interface IUnitOfWorkFactory
    {
        IUnitOfWork GetUnitOfWork();
    }
}