﻿using System.Linq;

namespace PartnerAccess.Identity.Storage.Data
{
    public interface IRepository<T> where T : class
    {
        IQueryable<T> All { get; }
        void Add(T entity);
    }
}