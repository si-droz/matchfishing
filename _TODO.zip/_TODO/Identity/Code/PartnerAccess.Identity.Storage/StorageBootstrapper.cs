﻿using Microsoft.Practices.Unity;
using PartnerAccess.Identity.Storage.Data;
using PartnerAccess.Identity.Storage.Data.Implementation;

namespace PartnerAccess.Identity.Storage
{
    public static class StorageBootstrapper
    {
        public static IUnityContainer RegisterStorageDependencies(this IUnityContainer unityContainer)
        {
            unityContainer.RegisterType<IUnitOfWorkFactory, UnitOfWorkFactory>();

            return unityContainer;
        }
    }
}