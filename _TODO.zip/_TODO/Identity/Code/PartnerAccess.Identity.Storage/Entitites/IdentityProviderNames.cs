﻿namespace PartnerAccess.Identity.Storage.Entitites
{
    public class IdentityProviderNames
    {
        public const string BuiltInIdentityProviderName = "idsrv";
        public const string AzureActiveDirectoryIdentityProviderName = "aad";
    }
}