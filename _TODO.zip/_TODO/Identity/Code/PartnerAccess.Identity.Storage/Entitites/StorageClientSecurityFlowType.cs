﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PartnerAccess.Identity.Storage.Entitites
{
    [Table("ClientFlowType")]
    public class StorageClientSecurityFlowType
    {
        [Key]
        public int Id { get; set; }

        [Index]
        [Required]
        public Guid ExternalId { get; set; }

        [Required]
        public string FlowType { get; set; }
    }
}