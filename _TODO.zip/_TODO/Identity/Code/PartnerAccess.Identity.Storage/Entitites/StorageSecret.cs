﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PartnerAccess.Identity.Storage.Entitites
{
    [Table("Secrets")]
    public class StorageSecret
    {
        [Key]
        public int Id { get; set; }

        [Index]
        [Required]
        public Guid ExternalId { get; set; }

        [Required]
        public string Secret { get; set; }
    }
}