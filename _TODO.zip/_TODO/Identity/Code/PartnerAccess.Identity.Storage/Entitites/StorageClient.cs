﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PartnerAccess.Identity.Storage.Entitites
{
    [Table("Clients")]
    public class StorageClient
    {
        private const string PartnerIdProductIdClientIdUniqueConstraint = "PartnerIdProductIdClientIdUniqueConstraint";

        [Key]
        public int Id { get; set; }

        [Index]
        [Required]
        public Guid ExternalId { get; set; }

        [Required]
        public virtual StorageClientSecurityFlowType SecurityFlowType { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        [MaxLength(100)]
        public string ClientId { get; set; }

        [Required]
        public bool Enabled { get; set; }

        /// <summary>
        /// Can provide one or several Identity Provider Names separated by a ';'
        /// </summary>
        [Required]
        public string IdentityProviderNames { get; set; }

        public virtual List<StorageRedirecturi> RedirectUris { get; set; }

        public virtual List<StorageScope> AllowedScopes { get; set; }

        public virtual List<StorageSecret> Secrets { get; set; }
    }
}