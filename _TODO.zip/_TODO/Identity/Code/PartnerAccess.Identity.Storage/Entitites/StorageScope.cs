﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PartnerAccess.Identity.Storage.Entitites
{
    [Table("Scopes")]
    public class StorageScope
    {
        [Key]
        public int Id { get; set; }

        [Index]
        [Required]
        public Guid ExternalId { get; set; }

        [Index]
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
    }
}