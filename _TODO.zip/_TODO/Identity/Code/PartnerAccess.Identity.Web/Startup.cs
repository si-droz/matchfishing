﻿using System.Globalization;
using System.Web.Configuration;
using IdentityServer3.Core.Configuration;
using IdentityServer3.Core.Services;
using Microsoft.Owin.Security.OpenIdConnect;
using Microsoft.Practices.Unity;
using Owin;
using PartnerAccess.Identity.Storage;
using PartnerAccess.Identity.Storage.Entitites;
using PartnerAccess.Identity.Web.Identity;
using Serilog;

namespace PartnerAccess.Identity.Web
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            //Configure debug messaging
            Log.Logger = new LoggerConfiguration().WriteTo
                                                  .Trace(outputTemplate: "{Timestamp:HH:mm} [{Level}] ({Name:l}){NewLine} {Message}{NewLine}{Exception}")
                                                  .CreateLogger();

            //Configure the rest
            var unityContainer = new UnityContainer().RegisterStorageDependencies()
                                                     .RegisterWebDependencies();

            //Setup Identity Server
            app.Map("/identity", appBuilder =>
                                 {
                                     appBuilder.UseIdentityServer(new IdentityServerOptions
                                                                  {
                                                                      SigningCertificate = unityContainer.Resolve<ICertificateProvider>().GetPrimaryCertificate(),
                                                                      Factory = new IdentityServerServiceFactory
                                                                                {
                                                                                    UserService = new Registration<IUserService>(unityContainer.Resolve<IUserService>()),
                                                                                    ClientStore = new Registration<IClientStore>(unityContainer.Resolve<IClientStore>()),
                                                                                    ScopeStore = new Registration<IScopeStore>(unityContainer.Resolve<IScopeStore>())
                                                                                },
                                                                      AuthenticationOptions = new AuthenticationOptions
                                                                                              {
                                                                                                  IdentityProviders = ConfigureIdentityProviders,
                                                                                                  EnableSignOutPrompt = false // to perform prompt sign out
                                                                                              },
                                                                      EnableWelcomePage = false,
                                                                      SiteName = "Capita SIMS - Partner Management",
                                                                      CspOptions = new CspOptions
                                                                                   {
                                                                                       Enabled = true
                                                                                   }
                                                                  });
                                 });
        }

        private static void ConfigureIdentityProviders(IAppBuilder app, string signInAsType)
        {
            string clientId = WebConfigurationManager.AppSettings["ActiveDirectory:ClientId"];
            string aadInstance = WebConfigurationManager.AppSettings["ActiveDirectory:AADInstance"];
            string tenant = WebConfigurationManager.AppSettings["ActiveDirectory:Tenant"];
            string postLogoutRedirectUri = WebConfigurationManager.AppSettings["ActiveDirectory:PostLogoutRedirectUri"];
            string authority = string.Format(CultureInfo.InvariantCulture, aadInstance, tenant);

            var openIdConnectAuthenticationOptions = new OpenIdConnectAuthenticationOptions
                                                     {
                                                         ClientId = clientId,
                                                         Authority = authority,
                                                         PostLogoutRedirectUri = postLogoutRedirectUri,
                                                         AuthenticationType = IdentityProviderNames.AzureActiveDirectoryIdentityProviderName,
                                                         Caption = "Partner Management Portal",
                                                         SignInAsAuthenticationType = signInAsType
                                                     };
            app.UseOpenIdConnectAuthentication(openIdConnectAuthenticationOptions);
        }
    }
}