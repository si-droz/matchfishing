﻿using System;
using System.Configuration;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using Serilog;

namespace PartnerAccess.Identity.Web.Identity.Implementation
{
    internal class CertificateProvider : ICertificateProvider
    {
        private readonly string _thumbprint;

        public CertificateProvider()
        {
            _thumbprint = ConfigurationManager.AppSettings["IdentityProvider:SigningCertificateThumbprint"];
        }

        public X509Certificate2 GetPrimaryCertificate()
        {
#if DEBUG
            if(string.IsNullOrWhiteSpace(_thumbprint))
            {
                using(Stream certificateResourceStream = GetType().Assembly.GetManifestResourceStream("PartnerAccess.Identity.Web.Certificates.idsrv3test.pfx"))
                using(MemoryStream memoryStream = new MemoryStream())
                {
                    certificateResourceStream.CopyTo(memoryStream);
                    byte[] bytes = memoryStream.ToArray();

                    return new X509Certificate2(bytes, "idsrv3test");
                }
            }
#endif
            // If we're on live we should be getting the cert from the web app cert store
            X509Certificate2 certificate = null;
            X509Store certStore = new X509Store(StoreName.My, StoreLocation.CurrentUser);
            certStore.Open(OpenFlags.ReadOnly);

            Log.Information($"Find certificate by thumbprint: {_thumbprint}");
            X509Certificate2Collection certCollection = certStore.Certificates.Find(X509FindType.FindByThumbprint, _thumbprint, false);

            // Get the first cert with the thumbprint
            if(certCollection.Count > 0)
            {
                Log.Information($"Certificate with thumbprint {_thumbprint} found");
                certificate = certCollection[0];
            }

            certStore.Close();

            if(certificate == null)
            {
                Log.Error($"Unable to find certificate with thumbprint {_thumbprint}");
                throw new InvalidOperationException($"Unable to retrieve certificate from Azure cert store with thumbprint {_thumbprint}");
            }

            return certificate;
        }
    }
}