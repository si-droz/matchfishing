﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using IdentityServer3.Core.Models;
using IdentityServer3.Core.Services;

namespace PartnerAccess.Identity.Web.Identity.Implementation
{
    public class ScopeStore : IScopeStore
    {
        private readonly List<Scope> _scopes = new List<Scope>
                                               {
                                                   StandardScopes.OpenId,
                                                   StandardScopes.Profile,
                                                   new Scope
                                                   {
                                                       Enabled = true,
                                                       DisplayName = "Partner Service API",
                                                       Name = "partner-access-partner-service-api",
                                                       Description = "Access to the Partner Service API",
                                                       Type = ScopeType.Resource,
                                                       Claims = new List<ScopeClaim>
                                                                {
                                                                    new ScopeClaim {Name = "PartnerId", AlwaysIncludeInIdToken = true}
                                                                },
                                                       Required = true
                                                   },
                                                   new Scope
                                                   {
                                                       Enabled = true,
                                                       DisplayName = "Partner Access Identity Service API",
                                                       Name = "partner-access-identity-provider-api",
                                                       Description = "Access to the Identity Service API",
                                                       Type = ScopeType.Resource,
                                                       Required = true
                                                   },
                                                   new Scope
                                                   {
                                                       Enabled = true,
                                                       DisplayName = "Partner Access SIMS Primary API",
                                                       Name = "partner-access-sims-primary-api",
                                                       Description = "Access to the SIMS Primary API",
                                                       Type = ScopeType.Resource,
                                                       Claims = new List<ScopeClaim>
                                                                {
                                                                    new ScopeClaim {Name = "sit", AlwaysIncludeInIdToken = true}
                                                                },
                                                       Required = true
                                                   },
                                                   new Scope
                                                   {
                                                       Enabled = true,
                                                       DisplayName = "Service API Administration Access",
                                                       Name = "partner-management-access-service-api",
                                                       Description = "Partner Management access to service api",
                                                       Type = ScopeType.Resource,
                                                       Required = true
                                                   }
                                               };

        public Task<IEnumerable<Scope>> FindScopesAsync(IEnumerable<string> scopeNames)
        {
            return Task.FromResult(_scopes.AsEnumerable());
        }

        public Task<IEnumerable<Scope>> GetScopesAsync(bool publicOnly = true)
        {
            return Task.FromResult(_scopes.AsEnumerable());
        }
    }
}