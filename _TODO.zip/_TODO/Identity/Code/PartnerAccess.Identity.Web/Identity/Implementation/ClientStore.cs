﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using iSIMS.Common;
using IdentityServer3.Core.Models;
using IdentityServer3.Core.Services;
using PartnerAccess.Identity.Storage.Data;
using PartnerAccess.Identity.Storage.Entitites;

namespace PartnerAccess.Identity.Web.Identity.Implementation
{
    public class ClientStore : IClientStore
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public ClientStore(IUnitOfWorkFactory unitOfWorkFactory)
        {
            _unitOfWorkFactory = unitOfWorkFactory;
        }

        public async Task<Client> FindClientByIdAsync(string clientId)
        {
            Client mappedClient;

            using (IUnitOfWork unitOfWork = _unitOfWorkFactory.GetUnitOfWork())
            {
                StorageClient selectedClient = await unitOfWork.GetRepository<StorageClient>()
                                                               .All
                                                               .Include(client => client.SecurityFlowType)
                                                               .Include(client => client.AllowedScopes)
                                                               .Include(client => client.RedirectUris)
                                                               .Include(client => client.Secrets)
                                                               .SingleOrDefaultAsync(client => client.ClientId == clientId);
                mappedClient = Map(selectedClient);
            }


            return mappedClient;
        }

        private Client Map(StorageClient storageClient)
        {
            Client client;
            // Restrict identity server according to the client
            var identityProviderNames = storageClient?.IdentityProviderNames?.Split(';')?.ToList();
            var enableLocalLogin = false;

            if (identityProviderNames != null)
            {
                enableLocalLogin = identityProviderNames.Contains(IdentityProviderNames.BuiltInIdentityProviderName);
            }

            switch (storageClient.SecurityFlowType.FlowType)
            {
                case "Hybrid":
                    {
                        client = new Client
                        {
                            Flow = Flows.Hybrid,
                            ClientName = storageClient.Name,
                            ClientId = storageClient.ClientId,
                            RedirectUris = storageClient.RedirectUris.Select(redirectUri => redirectUri.Uri).ToList(),
                            Enabled = storageClient.Enabled,
                            EnableLocalLogin = enableLocalLogin,
                            AllowedScopes = storageClient.AllowedScopes?.Select(scope => scope.Name).ToList(),
                            IdentityProviderRestrictions = identityProviderNames
                        };
                        break;
                    }
                case "ClientCredentials":
                    {
                        client = new Client
                        {
                            Flow = Flows.ClientCredentials,
                            ClientName = storageClient.Name,
                            ClientId = storageClient.ClientId,
                            ClientSecrets = storageClient.Secrets.Select(secret => new Secret(secret.Secret.Sha256())).ToList(),
                            Enabled = storageClient.Enabled,
                            EnableLocalLogin = enableLocalLogin,
                            AllowedScopes = storageClient.AllowedScopes?.Select(scope => scope.Name).ToList(),
                            IdentityProviderRestrictions = identityProviderNames
                        };
                        break;
                    }
                default:
                    {
                        throw new InvalidOperationException($"Support for the SecurityFlowType of {storageClient.SecurityFlowType.FlowType} has not yet been implemented.");
                    }
            }

            return client;
        }
    }
}