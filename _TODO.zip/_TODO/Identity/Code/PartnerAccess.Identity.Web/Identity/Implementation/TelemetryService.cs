﻿using System;
using System.Diagnostics;
using Microsoft.ApplicationInsights;

namespace PartnerAccess.Identity.Web.Identity.Implementation
{
    internal class TelemetryService : ITelemetryService
    {
        public void TrackException(Exception exception)
        {
            Trace.WriteLine($"Trace : An exception has occured:\n\n{exception}\n\n---------------------------------------------");
            var ai = new TelemetryClient();
            ai.TrackException(exception);
        }
    }
}