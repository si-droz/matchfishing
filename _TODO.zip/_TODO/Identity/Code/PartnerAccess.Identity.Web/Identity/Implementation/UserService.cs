﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security;
using System.Security.Claims;
using System.ServiceModel;
using System.Threading.Tasks;
using System.Web.Http;
using IdentityServer3.Core.Models;
using IdentityServer3.Core.Services;
using Microsoft.Ajax.Utilities;
using PartnerAccess.Identity.Storage.Entitites;

namespace PartnerAccess.Identity.Web.Identity.Implementation
{
    public class UserService : IUserService
    {
        private readonly ITelemetryService _telemetryService;

        public UserService(ITelemetryService telemetryService)
        {
            _telemetryService = telemetryService;
        }

        public Task PreAuthenticateAsync(PreAuthenticationContext context)
        {
            Debug.WriteLine("PreAuthenticateAsync");
            return Task.FromResult(0);
        }

        public Task AuthenticateLocalAsync(LocalAuthenticationContext context)
        {
            throw new NotImplementedException();
        }

        [Authorize]
        public Task AuthenticateExternalAsync(ExternalAuthenticationContext context)
        {
            Debug.WriteLine("AuthenticateExternalAsync");

            try
            {
                var upnClaim = context.ExternalIdentity.Claims.SingleOrDefault(claim => claim.Type == "upn");

                if(upnClaim == null)
                {
                    throw new SecurityException("The UPN claim is not present.");
                }


                var upn = upnClaim.Value;

                if(string.IsNullOrEmpty(upn))
                {
                    throw new SecurityException("The UPN claim does not contain a value. This is unexpected.");
                }
                else
                {
                    context.AuthenticateResult = new AuthenticateResult(Guid.Parse("E7F23CD8-8D73-496E-8F74-39AEF3765DE7").ToString(),
                                                                        upn,
                                                                        new List<Claim>
                                                                        {
                                                                            new Claim("sit", $"{upn}")
                                                                        }, IdentityProviderNames.AzureActiveDirectoryIdentityProviderName);
                }
            }
            catch(FaultException exception)
            {
                _telemetryService.TrackException(exception);
                context.AuthenticateResult = new AuthenticateResult(exception.Message);
            }
            catch(Exception exception)
            {
                _telemetryService.TrackException(exception);
                throw;
            }

            return Task.FromResult(0);
        }

        public Task PostAuthenticateAsync(PostAuthenticationContext context)
        {
            Debug.WriteLine("PostAuthenticateAsync");
            return Task.FromResult(0);
        }

        public Task SignOutAsync(SignOutContext context)
        {
            Debug.WriteLine("SignOutAsync");
            return Task.FromResult(0);
        }

        public Task GetProfileDataAsync(ProfileDataRequestContext context)
        {
            Debug.WriteLine("GetProfileDataAsync");

            Claim signinTokenClaim = context.Subject.Identities.First().Claims.SingleOrDefault(claim => claim.Type == "sit");

            if(signinTokenClaim != null)
            {
                context.IssuedClaims = new List<Claim> {signinTokenClaim};
            }

            return Task.FromResult(0);
        }

        public Task IsActiveAsync(IsActiveContext context)
        {
            Debug.WriteLine("IsActiveAsync");
            return Task.FromResult(0);
        }
    }
}