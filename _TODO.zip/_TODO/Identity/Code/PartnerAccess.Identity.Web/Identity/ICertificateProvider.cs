﻿using System.Security.Cryptography.X509Certificates;

namespace PartnerAccess.Identity.Web.Identity
{
    public interface ICertificateProvider
    {
        X509Certificate2 GetPrimaryCertificate();
    }
}