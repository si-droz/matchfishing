﻿using System;

namespace PartnerAccess.Identity.Web.Identity
{
    public interface ITelemetryService
    {
        void TrackException(Exception exception);
    }
}