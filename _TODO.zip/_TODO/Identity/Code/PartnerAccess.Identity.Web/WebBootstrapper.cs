﻿using IdentityServer3.Core.Services;
using Microsoft.Practices.Unity;
using PartnerAccess.Identity.Web.Identity;
using PartnerAccess.Identity.Web.Identity.Implementation;

namespace PartnerAccess.Identity.Web
{
    public static class WebBootstrapper
    {
        public static IUnityContainer RegisterWebDependencies(this IUnityContainer unityContainer)
        {
            unityContainer.RegisterType<IUserService, UserService>()
                          .RegisterType<IClientStore, ClientStore>()
                          .RegisterType<IScopeStore, ScopeStore>()
                          .RegisterType<ICertificateProvider, CertificateProvider>()
                          .RegisterType<ITelemetryService, TelemetryService>();

            return unityContainer;
        }
    }
}