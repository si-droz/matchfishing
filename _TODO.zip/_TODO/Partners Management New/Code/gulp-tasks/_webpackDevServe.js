'use strict';

const gulp = require("gulp");
// const gutil = require("gulp-util");
const webpack = require("webpack");
const WebpackDevServer = require("webpack-dev-server");

// const webpackConfig = require("./webpack.config.js");

gulp.task("webpack-dev-server", function(callback) {
    // modify some webpack config options
    const webpackConfig = {
         output: {
           // your stuff
           publicPath: './app/dist/'
         }
    }

    var myConfig = Object.create(webpackConfig);
    myConfig.devtool = "eval";
    myConfig.debug = true;

    	// var myConfig = Object.create(webpackConfig);

    	// Start a webpack-dev-server
    	new WebpackDevServer(webpack(myConfig), {
    		publicPath:  "/" + myConfig.output.publicPath,
    		stats: {
    			colors: true
    		}
    	}).listen(44323, "localhost", function(err) {
  //   		if(err) throw new gutil.PluginError("webpack-dev-server", err);
  //   		gutil.log("[webpack-dev-server]", "http://localhost:8080/webpack-dev-server/index.html");
    	});
});
