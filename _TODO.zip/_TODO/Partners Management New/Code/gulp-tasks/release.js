'use strict';

const gulp = require('gulp');
const gulpSequence = require('gulp-sequence');

gulp.task('dev', gulpSequence(
  'distribution-clean',
  'environment-set-dev',
  'bower-components-copy',
  'copy-iis-deployment-parameters',
  'css-bundle-minify',
  'img-minify',
  'lang-copy',
  'html-transform',
  'html-templatecache',
  'js-config-angular-transform',
  'js-config-transform',
  'js-transpile',
  'js-parse',
  'js-bundle-minify',
  'js-config-angular-transform',
  'js-config-transform'
));

gulp.task('live', gulpSequence(
  'distribution-clean',
  'environment-set-live',
  'bower-components-copy',
  'copy-iis-deployment-parameters',
  'css-bundle-minify',
  'img-minify',
  'lang-copy',
  'html-transform',
  'html-templatecache',
  'js-config-angular-transform',
  'js-config-transform',
  'js-transpile',
  'js-parse',
  'js-bundle-minify',
  'js-config-angular-transform',
  'js-config-transform'
));

gulp.task('copy-iis-deployment-parameters', () =>{
  return gulp.src('parameters.xml')
  .pipe(gulp.dest('app/dist'));
});
