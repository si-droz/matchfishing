'use strict';

const gulp = require('gulp');
const rename = require("gulp-rename");
const xml2json = require('gulp-xml2json');

gulp.task('xml-transform', () => {
  return gulp.src('web.config.xml') //xml extension has to be there
         .pipe(xml2json())
         .pipe(rename({extname: '.json'}))
         .pipe(gulp.dest('.'));
});
