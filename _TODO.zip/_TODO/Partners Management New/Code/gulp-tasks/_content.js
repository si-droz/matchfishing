'use strict';

const gulp = require('gulp');
const minifyCss = require('gulp-minify-css');
const concat = require('gulp-concat');
const merge = require('merge-stream');

const imagemin = require('gulp-imagemin');

gulp.task('css-bundle', () => {
    // minified
    return gulp.src([
            'app/bower_components/bootstrap/dist/css/bootstrap.min.css',
            'app/bower_components/bootstrap/dist/css/bootstrap-theme.min.css',
            'app/bower_components/html5-boilerplate/dist/css/main.css',
            'app/bower_components/html5-boilerplate/dist/css/normalize.css',
            'app/src/css/*.css'
        ])
        .pipe(concat('style.css'))
        .pipe(gulp.dest('app/dist/css'));
});

gulp.task('css-bundle-minify', () => {
    // minified
    const minifiedStream = gulp.src([
            'app/bower_components/bootstrap/dist/css/bootstrap.min.css',
            'app/bower_components/bootstrap/dist/css/bootstrap-theme.min.css'
        ])
        .pipe(concat('minified.min.css'));

    // to minify
    const rawStream = gulp.src([
            'app/bower_components/html5-boilerplate/dist/css/main.css',
            'app/bower_components/html5-boilerplate/dist/css/normalize.css',
            'app/src/css/*.css'
        ])
        .pipe(minifyCss())
        .pipe(concat('raw.min.css'));

    const mergedStream = merge(minifiedStream, rawStream)
        .pipe(concat('style.css'))
        .pipe(gulp.dest('app/dist/css'))

    return mergedStream;
});


gulp.task('img-minify', () =>
    gulp.src('app/src/css/images/*')
        .pipe(imagemin())
        .pipe(gulp.dest('app/dist/css/images'))
);

gulp.task('img-copy', () => {
    gulp.src('app/src/css/images/*')
        .pipe(gulp.dest('app/dist/css/images'));
});

gulp.task('lang-copy', () => {
  gulp.src('app/src/lang/*')
    .pipe(gulp.dest('app/dist/lang'));
});
