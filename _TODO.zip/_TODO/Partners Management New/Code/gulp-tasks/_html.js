'use strict';

const gulp = require('gulp');
const fs = require('fs');
const template = require('gulp-template');
const data = require('gulp-data');
const ngTemplates = require('gulp-ng-templates');

gulp.task('html-templatecache', () => {
      return gulp.src('app/**/tmpl/**/*.html')
          .pipe(ngTemplates({
              filename: 'app.templates.js',
              module: 'templates',
          }))
          .pipe(gulp.dest('app/src'));
});

gulp.task('html-transform', () => {
  let settings = JSON.parse(fs.readFileSync('env.config.json', 'utf8'));
  const env = global.CONFIG.Env;
  process.stdout.write(`html-transform, environment: ${env} \n`);

  gulp.src('web.config')
    .pipe(data(() =>
        ({
          serviceApi: settings[env].EnvironmentConfig.serviceApi,
          azureContainerUrl: settings[env].EnvironmentConfig.azureContainerUrl,
          azureGuidanceContainerUrl: settings[env].EnvironmentConfig.azureGuidanceContainerUrl
        })))
    .pipe(template())
    .pipe(gulp.dest('app/dist'));

  return gulp.src('app/*.html')
    .pipe(data(() =>
        ({
          identityServer: settings[env].EnvironmentConfig.identityServer,
          redirectUrl: settings[env].EnvironmentConfig.redirectUrl
        })))
    .pipe(template())
    .pipe(gulp.dest('app/dist'));
});
