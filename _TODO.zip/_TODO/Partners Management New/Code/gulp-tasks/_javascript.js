'use strict';

const gulp = require('gulp');
const gulpNgConfig = require('gulp-ng-config');

const replace = require('gulp-replace-task');
const fs = require('fs');
const rename = require("gulp-rename");
// const preprocess = require('gulp-preprocess');
const concat = require('gulp-concat');
const uglify = require('gulp-uglify');
const jshint = require('gulp-jshint');
const babel = require('gulp-babel');
const minify = require('gulp-babel-minify');

const ngAnnotate = require('gulp-ng-annotate');

// requires browserify and vinyl-source-stream
const browserify = require('browserify');
const source = require('vinyl-source-stream');
const buffer = require('vinyl-buffer');

const es = require('event-stream');

gulp.task('js-config-angular-transform', () => {
  const env = global.CONFIG.Env;
  process.stdout.write(`js-config-angular-transform, environment: ${env} \n`);
  const temp =  gulp.src('env.config.json')
                .pipe(gulpNgConfig('partners.management.config', {environment: `${env}`}))
                .pipe(gulp.dest('app/temp_dist'))



                const src =  gulp.src('env.config.json')
                              .pipe(gulpNgConfig('partners.management.config', {environment: `${env}`}))
                              .pipe(gulp.dest('app/src'))

      return es.concat(temp,src);

});

gulp.task('js-config-transform', () => {
   const env = global.CONFIG.Env;
   process.stdout.write(`js-config-transform, environment: ${env} \n`);
   let settings = JSON.parse(fs.readFileSync('env.config.json', 'utf8'));
    // Replace each placeholder with the correct value for the variable.
    gulp.src('app/tests/protractor.template.conf.js')
      .pipe(replace({
        patterns: [
          {
            match: 'allScriptsTimeout',
            replacement: settings[env].ProtractorConfig.allScriptsTimeout
          }
        ]
      }))
      .pipe(rename("protractor.conf.js"))
      .pipe(gulp.dest('app/tests'));
});


gulp.task('js-bundle', () => {
	// Grabs the app.js file
    return browserify('app/temp_dist/app.js')
        .bundle()
        .pipe(source('main.js'))
        .pipe(gulp.dest('app/dist/js/'));
});


gulp.task('js-bundle-minify', () => {
  // Grabs the app.js file
    return browserify('app/temp_dist/app.js')
        .bundle()
        .pipe(source('main.js'))
        .pipe(buffer())
        .pipe(uglify())
        .pipe(gulp.dest('app/dist/js/'));
});

gulp.task('js-transpile', () => {
    return gulp.src('app/src/**/*.js')
                .pipe(babel())
                .pipe(ngAnnotate())
                .pipe(gulp.dest('app/temp_dist/'));
});

gulp.task('js-parse', () => {
    return gulp.src('app/temp_dist/js/*.js')
                .pipe(jshint())
                .pipe(jshint.reporter('default'));
});
