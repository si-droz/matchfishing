'use strict';

const gulp = require('gulp');
const browserSync = require('browser-sync').create();
const gulpSequence = require('gulp-sequence');
const modRewrite  = require('connect-modrewrite');
const path = require('path');
const url = require("url");
const fs = require('fs');
const historyFallback = require('connect-history-api-fallback');

// Static Server + watching scss/html files
gulp.task('browsersync-serve', () => {
    browserSync.init({
        server: {
            baseDir: './app/dist',
            middleware: [
                historyFallback({
                    // verbose: true,
                    // logger: console.log.bind(console),
                    // disableDotRule: false
                })
            ]
        },
        https: false,
        port: 9000
    });

    gulp.watch('app/src/**/*.js').on('change', () => {
        gulpSequence('js-transpile', 'js-bundle', browserSync.reload);
    });
    gulp.watch('app/src/**/*.css').on('change', () => {
        gulpSequence('img-copy', 'css-bundle', browserSync.reload);
    });
    gulp.watch('app/src/**/*.html').on('change', () => {
        gulpSequence('html-transform', 'html-templatecache', 'js-transpile', 'js-bundle', browserSync.reload);
    });

});