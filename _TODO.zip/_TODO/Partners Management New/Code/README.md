# Partner Management Portal

This document is a developer documentation for Partner Management Portal.

## Environment setup

### Installing dependencies

Install latest stable version of [git](https://git-scm.com/)

Install latest stable version of [node.js](https://nodejs.org/en/)

Install latest stable version of [Visual Studio](https://www.visualstudio.com/en-us/downloads/download-visual-studio-vs.aspx)

Install latest stable version of [SQL Server](https://www.microsoft.com/en-us/cloud-platform/sql-server-editions-developers)

Install latest stable version of [gulp](http://gulpjs.com/)
    check whether your node.js and node package manager is correctly installed using commands: `node -v` and `npm -v`    
    run command: `npm install gulp -g`  
    check that gulp is correctly installed using the command: `gulp -v` - if this does not give you the gulp versions, reinstall nodejs and try again

### Cloning repositories

Clone Partner Management portal
    `git clone https://capita-sims-satellites.visualstudio.com/Partner%20API/_git/Partners%20Management%20New`

Clone Integration Testing
    `git clone https://capita-sims-satellites.visualstudio.com/Partner%20API/_git/Integration%20Testing`

Clone Partner Access Identity
    `git clone https://capita-sims-satellites.visualstudio.com/Partner%20API/_git/Identity`

Clone Partner Access ServiceAPI
    `git clone https://capita-sims-satellites.visualstudio.com/Partner%20API/_git/Identity`


### Running Partner Management Portal

#### Portal first-time setup

Navigate to the Code folder of Partner Management Portal

Install node dependencies
    run command: `npm install`

Install bower components
    run command 'bower install'

Install localhost certificate
    `ca.crt`

Add installed certificate to trusted root certification authorities

#### Run Portal

Start Partner Access Identity Web project using angular-work branch
Start Partner Access ServiceAPI project using angular-work branch

Navigate to the Code folder of Partner Management Portal

Run Partner Management Portal
    check whether port 44323 is available
    run command: `gulp local`

##### Database first-time setup

After initial requests to Identity and ServiceAPI your local sql server should contain following databases:
    pm-idp-api-local-dev
    pm-management-api-local-dev

##### Enable databases
    if the databases are not in place then you would need to from the service api project run the nuget console and install the latest version of the database.
    From nuget console run;

    Enable-Migrations
    Update-Database -ConnectionString 'Server=.;Database=pm-management-api-local-dev Timeout=30;Integrated Security=True' -ConnectionProviderName 'System.Data.SqlClient' -Verbose

    For the identity server from the identity project;
    From nuget console run;

    Enable-Migrations
    Update-Database -ConnectionString 'Server=.;Database=pm-idp-api-local-dev Timeout=30;Integrated Security=True' -ConnectionProviderName 'System.Data.SqlClient' -Verbose
