angular.module("partners.management.config", [])
.constant("EnvironmentConfig", {"identityServer":"https://simsid-partner-stsserver.azurewebsites.net","serviceApi":"https://localhost:44322","redirectUrl":"https://localhost:44323","azureContainerUrl":"https://pmapidocumentationdev.blob.core.windows.net","azureGuidanceContainerUrl":"https://pmapis.azure-api.net","documentationUrl":"https://localhost:44304","partnerApi":"https://localhost:44300"})
.constant("ProtractorConfig", {"allScriptsTimeout":80000});
