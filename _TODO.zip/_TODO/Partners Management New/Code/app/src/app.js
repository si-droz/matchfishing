'use strict';

// vendor scripts
import angular from '../bower_components/angular/angular.min.js';
import '../bower_components/angular-route/angular-route.min.js';
import '../bower_components/angular-translate/angular-translate.min.js';
import '../bower_components/angular-bootstrap/ui-bootstrap.min.js';
import '../bower_components/angular-bootstrap/ui-bootstrap-tpls.min.js';
import '../bower_components/angularLocalStorage/dist/angularLocalStorage.min.js';
import '../bower_components/angular-animate/angular-animate.min.js';
import '../bower_components/angular-cookies/angular-cookies.min.js';
import '../bower_components/angular-resource/angular-resource.min.js';
import '../bower_components/angular-sanitize/angular-sanitize.min.js';
import '../bower_components/angular-touch/angular-touch.min.js';
import '../bower_components/angular-messages/angular-messages.min.js';
import '../bower_components/angular-md5/angular-md5.min.js';
import '../bower_components/checklist-model/checklist-model.js';
import '../bower_components/angular-translate-loader-static-files/angular-translate-loader-static-files.min.js'

// app scripts
import './app.templates.js';

// home
import './areas/home/home.module.js';
import './areas/home/controllers/home.controller.js';
import './areas/home/services/hero.service.js';

// product
import './areas/product/product.module.js';
import './areas/product/services/product.service.js';
import './areas/product/filters/flowFormatter.filter.js';
import './areas/product/controllers/product.list.controller.js';
import './areas/product/controllers/product.edit.controller.js';

// client
import './areas/product/areas/client/product.client.module.js';
import './areas/product/areas/client/services/product.client.service.js';
import './areas/product/areas/client/services/azure.api.service.js';
import './areas/product/areas/client/controllers/product.client.list.controller.js';

// documentation
import './areas/documentation/documentation.module.js'
import './areas/documentation/controllers/documentation.controller.js'
import './areas/documentation/services/documentation.service.js'

// guidance
import './areas/guidance/guidance.module.js'
import './areas/guidance/controllers/guidance.controller.js'
import './areas/guidance/services/guidance.service.js'

// main
import './app.module.js';

import './directives/angularJsOAuth2.js';
import './directives/pmMessageLogger.directive.js';
import './directives/breadcrumbs.exclusions.constant.js';
import './directives/breadcrumbs.state.service.js';
import './directives/breadcrumbs.directive.js';
import './directives/mutedAnchor.directive.js';
import './directives/ngToast.directive.js';
import './directives/autofocus.directive';

import './interceptors/loading.interceptor.js';
import './services/loading.service.js';

import './env.config.js';
import './app.config.js';
// import './config/translate.config.js';