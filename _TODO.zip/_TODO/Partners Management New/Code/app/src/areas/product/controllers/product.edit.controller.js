'use strict';

class productEditController {
    constructor(productService, breadcrumbsStateService, $location, $log, productId, ngToast) {
        'ngInject';
        const self = this;

        self.breadcrumbsStateService = breadcrumbsStateService;
        self.productService = productService;
        self.ngToast = ngToast;
        self.$location = $location;
        self.$log = $log;
        self.productId = productId;

        self.notificationOptions = {
                        content: '',
                        className: 'success',
                        classes: 'foo',
                        dismissOnTimeout: true,
                        timeout: 3000,
                        dismissButton: true,
                        dismissButtonHtml: '&times',
                        dismissOnClick: true,
                        compileContent: false
         };

        self.isError = false;

        if (productId)
            self.loadProduct(productId);
    }

    loadProduct(productId) {
        const self = this;

        self.productService.get(productId).then((response) => {
                self.existingProduct = response;
                self.product = angular.extend({}, self.existingProduct);

                self.breadcrumbsStateService.update([{id:self.product.ExternalId, value: self.product.Name}]);
            })
            .catch((error) => {
                self.isError = true;
            });
    }

    createProduct(product) {
        const self = this;

        let isValid = self.validate();
        if (isValid) {
            self.productService.create(product)
                .then((response) => {
                    this.$location.path(`/products/${response.data.ExternalId}/clients`);
                    self.notificationOptions.content = `Product ${product.Name} successfully created`;
                    self.ngToast.create(self.notificationOptions);
                })
                .catch((error) => {
                    if (error.status === 409) {
                        self.form.productName.$setValidity("nameConflict", false);
                    } else {
                        self.form.$setValidity("errorCreate", false);
                    }
                });
        }
    }

    updateProduct(product) {
        const self = this;

        let isValid = self.validate();
        if (isValid) {

            if (self.existingProduct.Name === self.product.Name) {
                this.$location.path('/products');
                return;
            }

            self.productService.update(product)
                .then((response) => {
                    this.$location.path('/products');
                    self.notificationOptions.content = `Product ${self.existingProduct.Name} successfully updated`;
                    self.ngToast.create(self.notificationOptions);
                })
                .catch((error) => {
                    if (error.status === 409) {
                        self.form.productName.$setValidity("nameConflict", false);
                    } else {
                        self.form.$setValidity("errorUpdate", false);
                    }
                });
        }
    }

    validate() {
        const self = this;

        angular.forEach(self.form.$error, (fields) => {
            angular.forEach(fields, (field) => {
                field.$setTouched();
                field.$setDirty();
            });
        });

        return self.form.$valid;
    }

    clearNameConflict() {
        const self = this;

        self.form.productName.$setValidity("nameConflict", null);
    }

}

angular.module('areas.product').controller('productEditController', productEditController);
