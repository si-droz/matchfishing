'use strict';

function azureApiService($http, EnvironmentConfig) {
    'ngInject';
    let service;
    const azureApiUrl = `${EnvironmentConfig.serviceApi}/api/azureApi`;

    service = {
        get: (clientId) => {
          return $http.get(`${azureApiUrl}/${clientId}`).then((response) => response.data);
        },
        getReadOnlySubscriptionKey: () => {
            return $http.get(`${azureApiUrl}/getReadOnlySubscriptionKey`).then((response) => response.data);
        }
    };

    return service;
}

angular.module('areas.product').factory('azureApiService', azureApiService);
