'use strict';

function productClientService($http, EnvironmentConfig, $cacheFactory) {
    'ngInject';

  const cache = $cacheFactory('product.client');
    const productsUrl = `${EnvironmentConfig.serviceApi}/api/products`;

    let service = {
      list: (productId) => {
        return $http.get(`${productsUrl}/${productId}/clients/`).then((response) => response.data);
      },
      get: (productId, clientId) => {
        return $http.get(`${productsUrl}/${productId}/clients/${clientId}`).then((response) => response.data);
      },
      create: (productId, client) => {
        cache.remove(`${productsUrl}/${productId}/clients/`);
        return $http.post(
          `${productsUrl}/${productId}/clients/`,
          JSON.stringify(client), {
            headers: {
              'Content-Type': 'application/json'
            }
          });
      },
      update: (productId, client) => {
        cache.remove(`${productsUrl}/${productId}/clients/`);
        cache.remove(`${productsUrl}/${productId}/clients/${client.ExternalId}`);
        return $http.patch(
          `${productsUrl}/${productId}/clients/`,
          JSON.stringify(client), {
            headers: {
              'Content-Type': 'application/json'
            }
          });
      },
      getReadOnlyClient: () => {
        return $http.get(`${productsUrl}/clients/getReadOnlyClient`).then((response) => response.data);
      }
    };

    return service;
}

angular.module('areas.product').factory('productClientService', productClientService);
