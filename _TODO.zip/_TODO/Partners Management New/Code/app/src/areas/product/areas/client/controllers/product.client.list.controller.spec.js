// 'use strict';
//
// describe('product.client.list.controller.js', () => {
//   let controller, breadcrumbsStateService, productService, productClientService, product, clients, $q, $scope, $httpBackend;
//   let productDemoSystemService, demoSystems;
//
//   beforeEach(angular.mock.inject((_$rootScope_, _$httpBackend_, _$q_, _$location_, _$log_) => {
//       $q = _$q_;
//       $scope = _$rootScope_;
//       $httpBackend = _$httpBackend_;
//
//       product = {
//         Name: 'PM',
//         ExternalId: '1755400e-269c-44da-89bc-1fe35b23e85c'
//       };
//
//       clients = [
//         {ExternalId: "9755400e-269c-44da-89bc-1fe35b23e85b", Name: "23483908490284", Flow:'Client Credentials'},
//         {ExternalId: "cc34627c-5555-4db5-a29f-692b4dd7e791", Name: "dasasdasdasdasdas", Flow: 'Hybrid'},
//         {ExternalId: "6fe29876-80bb-4c3c-9c39-0c99f76b3ed4", Name: "0.08844945183955133", Flow: 'Hybrid'}
//       ];
//
//       demoSystems = [
//         {OrganisationId: "abcd", OrganisationName: "demo 1"},
//         {OrganisationId: "dcba", OrganisationName: "demo 2"}
//       ]
//
//       productClientService = jasmine.createSpyObj('productClientService', ['list']);
//       productClientService.list.and.callFake((productId) => {return params[productId];}).and.returnValue($q.when(clients));
//
//       productDemoSystemService = jasmine.createSpyObj('productDemoSystemService', ['list']);
//       productDemoSystemService.list.and.returnValue($q.when(demoSystems));
//
//       productService = jasmine.createSpyObj('productService', ['get']);
//       productService.get.and.callFake((productId) => {return params[productId];}).and.returnValue($q.when(product));
//
//       breadcrumbsStateService = jasmine.createSpyObj('breadcrumbsStateService', ['update']);
//
//       controller = new productClientListController(productService, productClientService, productDemoSystemService, breadcrumbsStateService, product.ExternalId);
//       $scope.$apply();
//   }));
//
//   afterEach(() => {
//       $httpBackend.verifyNoOutstandingExpectation();
//       $httpBackend.verifyNoOutstandingRequest();
//   });
//
//   describe('initialization', () => {
//       it('should not throw errors', () => {
//           expect(controller).toBeDefined();
//       });
//
//       it('should initially be loading clients', () => {
//           expect(productClientService.list).toHaveBeenCalledWith(product.ExternalId);
//           expect(controller.clients).not.toBeNull();
//           expect(controller.clients).not.toBeUndefined();
//           expect(controller.clients.length).toBe(3);
//           expect(productDemoSystemService.list).toHaveBeenCalled();
//           expect(controller.demoSystems).not.toBeNull();
//           expect(controller.demoSystems).not.toBeUndefined();
//           expect(controller.demoSystems.length).toBe(2);
//       });
//   });
// });
