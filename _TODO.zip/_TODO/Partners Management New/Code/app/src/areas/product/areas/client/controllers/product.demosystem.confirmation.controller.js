'use strict';

class demoSystemConfirmationController {
    constructor ($window, $uibModalInstance, productDemoSystemService, data) {
        'ngInject';
        const self = this;

        self.$window = $window;
        self.$uibModalInstance = $uibModalInstance;
        self.organisationId = data.organisationId;
        self.clientId = data.clientId;
        self.productId = data.productId;
        self.productDemoSystemService = productDemoSystemService;
        self.client = data.client;
        self.isBusy = false;
    }

    yes(){
        const self = this;
        self.isBusy = true;

        self.productDemoSystemService.request(self.client.ClientId, self.organisationId)
        .then((response) => {

            self.$uibModalInstance.close({
              success: true,
              message: 'Access requested.',
              error: null
            });
            self.$window.location.href = `/products/${self.productId}/clients/${self.clientId}`;

        })
        .catch((error) => {
          self.$uibModalInstance.close({
            success: false,
            message: 'An error occurred whilst trying to request access. If the problem persists please contact your development team.',
            error: error
          });
        });
    }

    no(){
        const self = this;
        self.$uibModalInstance.dismiss('User cancelled.');
    }
}

angular.module('areas.product.client').controller('demoSystemConfirmationController', demoSystemConfirmationController);
