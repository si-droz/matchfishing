'use strict';

class productListController {
    constructor(productService, $location, $log, $translate) {
        'ngInject';
        const self = this;

        self.productService = productService;
        self.$location = $location;
        self.$log = $log;

        self.products = [];
        self.loadProducts();

        // validation variables
        self.productsLoaded = false;
        self.productsLoadedEmpty = false;
        self.isError = false;
    }

    loadProducts() {
        const self = this;

        self.productService.list().then((response) => {
                if (response.length === 0) {
                    self.productsLoadedEmpty = true;
                    return;
                }
                angular.forEach(response, (value, key) => {
                    let product = {};
                    product.Name = value.Name;
                    product.ExternalId = value.ExternalId;
                    self.products.push(product);
                });
                self.productsLoaded = true;
            })
            .catch((error) => {
                self.isError = true;
            });
    }
}

angular.module('areas.product').controller('productListController', productListController);
