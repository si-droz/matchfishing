'use strict';

class productClientListController {
    constructor(productService, productClientService, breadcrumbsStateService, productId, $location) {
        'ngInject';
        const self = this;

        self.breadcrumbsStateService = breadcrumbsStateService;
        self.productService = productService;
        self.productClientService = productClientService;
        self.productName = '';
        self.ExternalId = '';
        self.productId = productId;

        self.$location = $location;

        self.pageLoaded = false;
        self.serviceCount = 0;
        self.clientsLoaded = false;
        self.clientsLoadedEmpty = false;

        self.demoSystemsLoaded = false;
        self.demoSystemsLoadedEmpty = false;

        self.isError = false;

        self.clients = [];
        self.demoSystems = [];
        self.loadClients(productId);
    }

    showPage() {
        const self = this;
        if (self.serviceCount == 1) {
            self.pageLoaded = true;
        }
    }

    loadClients(productId) {
        const self = this;

        self.productService.get(productId).then((product) => {
            self.productName = product.Name;
            self.ExternalId = product.ExternalId;

            self.productClientService.list(self.ExternalId).then((response) => {
                if (response.length === 0) {
                    self.clientsLoadedEmpty = true;
                    return;
                }
                angular.forEach(response, function (value, key) {
                    const client = {};
                    client.ClientId = value.ClientId;
                    client.Name = value.Name;
                    client.Flow = value.Flow;
                    client.OcpApiKey = value.OcpApiKey;
                    client.SimsIdStsServer = value.SimsIdStsServer;
                    client.Secrets = value.Secrets;
                    client.RedirectUris = value.RedirectUris;
                    client.ExternalId = value.ExternalId;
                    client.DemoSystemAssociations = value.DemoSystemAssociations;
                    client.ExternalApis = value.ExternalApis;
                    client.IsFreemium = value.Name.indexOf("Freemium") != -1;
                    client.AllowedScopes = value.AllowedScopes;
                    
                    self.clients.push(client);
                });
                self.clientsLoaded = true;
            })
                .catch((error) => {
                    self.isError = true;
                });
            self.serviceCount++;
            self.breadcrumbsStateService.update([{ id: self.ExternalId, value: self.productName }]);
            self.showPage();
        })
            .catch((error) => {
                self.isError = true;
            });
    }
}


angular.module('areas.product.client').controller('productClientListController', productClientListController);
