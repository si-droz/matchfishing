'use strict';

describe('product.list.controller.js', () => {
  let controller, productService, products, $q, $scope, $httpBackend;

  beforeEach(angular.mock.inject(($rootScope, _$httpBackend_, _$q_, $location, $log) => {
      $q = _$q_;
      $scope = $rootScope.$new();
      $httpBackend = _$httpBackend_;

      products = [
        {ExternalId: "9755400e-269c-44da-89bc-1fe35b23e85b", Name: "23483908490284"},
        {ExternalId: "cc34627c-5555-4db5-a29f-692b4dd7e791", Name: "dasasdasdasdasdas"},
        {ExternalId: "6fe29876-80bb-4c3c-9c39-0c99f76b3ed4", Name: "0.08844945183955133"}
      ];

      productService = jasmine.createSpyObj('productService', ['list', 'create']);
      productService.list.and.returnValue($q.when(products));
      productService.create.and.returnValue($q.defer().promise);

      controller = new productListController(productService, $location, $log);
      $scope.$apply();
  }));

  afterEach(() => {
      $httpBackend.verifyNoOutstandingExpectation();
      $httpBackend.verifyNoOutstandingRequest();
  });

  describe('initialization', () => {
      it('should not throw errors', () => {
          expect(controller).toBeDefined();
      });

      it('should initially be loading products', () => {
          expect(productService.list).toHaveBeenCalled();
          expect(controller.products).not.toBeNull();
          expect(controller.products).not.toBeUndefined();

          expect(controller.products[0].ExternalId).toBe(products[0].ExternalId);
          expect(controller.products[1].ExternalId).toBe(products[1].ExternalId);
          expect(controller.products[2].ExternalId).toBe(products[2].ExternalId);
      });
  });

});
