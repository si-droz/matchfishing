'use strict';

angular.module('areas.product.client', ['templates']);
