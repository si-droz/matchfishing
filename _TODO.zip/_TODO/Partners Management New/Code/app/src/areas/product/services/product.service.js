'use strict';

function productService($http, EnvironmentConfig, $cacheFactory) {
    'ngInject';
    let service;

    const cache = $cacheFactory('product');
    const productsUrl = `${EnvironmentConfig.serviceApi}/api/products/`;

    service = {
        list: (filter) => {
            return $http.get(productsUrl).then((response) => response.data);
        },
        get: (productId) => {
            return $http.get(`${productsUrl}/${productId}`).then((response) => response.data);
        },
        create: (product) => {
            cache.remove(productsUrl);
            return $http.post(
                productsUrl,
                JSON.stringify(product), {
                    headers: {
                        'Content-Type': 'application/json'
                    }
            });
        },
        update: (product) => {
            cache.remove(productsUrl);
            cache.remove(`${productsUrl}/${product.ExternalId}`);
            return $http.put(
                productsUrl,
                JSON.stringify(product), {
                    headers: {
                        'Content-Type': 'application/json'
                    }
            });
        }
    };

    return service;
}

angular.module('areas.product').factory('productService', productService);
