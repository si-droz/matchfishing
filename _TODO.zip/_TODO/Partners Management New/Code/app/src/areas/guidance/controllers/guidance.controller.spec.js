'use strict';

describe('guidance.controller.js', () => {
  let guidanceService, $q, $scope;

  beforeEach(angular.mock.inject(($rootScope, _$q_) => {
    $q = _$q_;
    $scope = $rootScope.$new();
    guidanceService = jasmine.createSpyObj('guidanceService', ['getGuidanceDocuments']);
  }));

  describe('get guidance', () => {
    let controller, deferredGetDocumentsCall;
    let guidanceDocuments = {};

    it('loads guidance documents', () => {

      //Arrange
      deferredGetDocumentsCall = $q.defer();
      deferredGetDocumentsCall.resolve(guidanceDocuments);
      guidanceService.getGuidanceDocuments.and.returnValue(deferredGetDocumentsCall.promise);

      //Act
      controller = new guidanceController(guidanceService);
      $scope.$apply();

      //Assert
      expect(guidanceService.getGuidanceDocuments).toHaveBeenCalled();
      expect(controller.guidanceDocuments).toBe(guidanceDocuments);
    });
  });
});