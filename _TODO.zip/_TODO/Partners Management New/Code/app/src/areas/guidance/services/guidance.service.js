'use strict';

function guidanceService($http, EnvironmentConfig, $cacheFactory) {
  'ngInject';

  const cache = $cacheFactory('guidance');

  const guidanceIndexUrl = `${EnvironmentConfig.azureGuidanceContainerUrl}/guidance/documentIndex.json`;

  function getGuidanceDocuments() {
    return $http.get(guidanceIndexUrl, { cache: cache }).then((response) => {
      return response.data;
    });
  }

  let service = {
    getGuidanceDocuments: () => {
      return getGuidanceDocuments();
    }
  };

  return service;
}

angular.module('areas.guidance').factory('guidanceService', guidanceService);