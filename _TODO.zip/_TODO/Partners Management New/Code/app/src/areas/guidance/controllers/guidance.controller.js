'use strict';

class guidanceController {
  constructor(guidanceService) {
    'ngInject';
    const self = this;

    self.guidanceService = guidanceService;
    self.guidanceLoaded = false;
    self.isError = false;
    self.guidanceDocuments = [];

    self.loadGuidanceDocuments();
  }

  loadGuidanceDocuments() {
    const self = this;

    self.guidanceService.getGuidanceDocuments()
      .then((response) => {
        self.guidanceDocuments = response;
      })
      .then(() => {
        self.guidanceLoaded = true;
      })
      .catch(() => {
        self.isError = true;
      });
  }
}

angular.module('areas.guidance').controller('guidanceController', guidanceController);