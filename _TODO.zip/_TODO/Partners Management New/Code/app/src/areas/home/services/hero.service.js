'use strict';

function heroService($http, EnvironmentConfig, $cacheFactory) {
    'ngInject';

    const cache = $cacheFactory('hero');
    const heroUrl = `${EnvironmentConfig.serviceApi}/home/api/hero`;
    const heroImageUrl = `${EnvironmentConfig.azureContainerUrl}/images/HeroImage.jpg`;

    let service = {
    getHeroText: () => {
      return $http.get(heroUrl, { cache: cache }).then((response) => response.data);
    },
    getHeroImageUrl: () => {
      return heroImageUrl;
      }
    }
    return service;

  }

angular.module('areas.home').factory('heroService', heroService);
