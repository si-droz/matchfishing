'use strict';

class homeController {
  constructor(heroService) {
    'ngInject';
    const self = this;

    self.heroService = heroService;
    self.heroHtml = "<div class='jumbotron' style='padding-left: 60px;'><h1>Partners Development Portal</h1></div>";
    self.heroImageUrl = "";
    self.loadHero();
  }

  loadHero() {
    const self = this;

    self.heroService.getHeroText()
      .then((response) => {
        self.heroHtml = response;
      });

    self.heroImageUrl = self.heroService.getHeroImageUrl();

  }
}

angular.module('areas.home').controller('homeController', homeController);
