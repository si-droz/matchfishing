'use strict';

function documentationService($http, EnvironmentConfig, $cacheFactory) {
  'ngInject';
  let service;

  const cache = $cacheFactory('documentation');

  const basicContainerUrl = `${EnvironmentConfig.azureContainerUrl}/documentation`;
  const enhancedContainerUrl = `${EnvironmentConfig.azureContainerUrl}/documentationenhanced`;

  const documentationUrl = `${EnvironmentConfig.documentationUrl}/index.html`;

  function getBlobs(containerUrl) {
    return $http.get(containerUrl + '?restype=container&comp=list', { cache: cache }).then((response) => {

      var apiDataModels = [];
      var apiDataModelFolders = [];

      var parser = new DOMParser();
      var xmlDoc = parser.parseFromString(response.data, 'text/xml');

      var blobs = xmlDoc.documentElement.childNodes[0];

      var apiNames = blobs.getElementsByTagName('Name');

      //extract the folder names
      for(var apiNamesIndex = 0; apiNamesIndex < apiNames.length; apiNamesIndex++) {
        var folderTemp = apiNames[apiNamesIndex].textContent;
        var index = folderTemp.indexOf("/");
        var folderName = folderTemp.substring(0, index);

        if(apiDataModelFolders.indexOf(folderName) === -1) {
          apiDataModelFolders.push(folderName);
        }
      }

      //create the models to include the folder name and url list
      for(var apiDataModelFoldersIndex = 0;
        apiDataModelFoldersIndex < apiDataModelFolders.length;
        apiDataModelFoldersIndex++) {
        const apiDataModel = {};

        apiDataModel.FolderName = apiDataModelFolders[apiDataModelFoldersIndex];

        var urls = [];

        for(var apiNamesIndex = 0; apiNamesIndex < apiNames.length; apiNamesIndex++) {
          var url = {};
          var fileName = apiNames[apiNamesIndex].textContent;
          if(fileName.indexOf(apiDataModelFolders[apiDataModelFoldersIndex] + '/') > -1) {
            url.FileName = fileName.replace('.json', '').slice(-2);
            url.Url = documentationUrl + '?url=' + containerUrl + '/' + fileName;
            urls.push(url);
          }
        }

        apiDataModel.Urls = urls;
        apiDataModels.push(apiDataModel);
      }

      return apiDataModels;
    });
  }

  service = {
    getBasic: () => {
      return getBlobs(basicContainerUrl);
    },
    getEnhanced: () => {
      return getBlobs(enhancedContainerUrl);
    }
  };

  return service;
}

angular.module('areas.documentation').factory('documentationService', documentationService);