'use strict';

describe('documentation.controller.js', () => {
  let documentationService, $q, $scope;

  beforeEach(angular.mock.inject(($rootScope, _$q_) => {
    $q = _$q_;
    $scope = $rootScope.$new();
    documentationService = jasmine.createSpyObj('documentationService', ['getBasic', 'getEnhanced']);
  }));

  describe('get documentation', () => {
    let controller, deferredBasicCall, deferredEnhancedCall;
    let basicApiData = {};
    let enhancedApiData = {};

    it('loads API documentation data', () => {
      //Arrange
      deferredBasicCall = $q.defer();
      deferredEnhancedCall = $q.defer();

      deferredBasicCall.resolve(basicApiData);
      deferredEnhancedCall.resolve(enhancedApiData);

      documentationService.getBasic.and.returnValue(deferredBasicCall.promise);
      documentationService.getEnhanced.and.returnValue(deferredEnhancedCall.promise);

      //Act
      controller = new documentationController(documentationService);
      $scope.$apply();

      //Assert
      expect(documentationService.getBasic).toHaveBeenCalled();
      expect(documentationService.getEnhanced).toHaveBeenCalled();
      expect(controller.basicApiDataModels).toBe(basicApiData);
      expect(controller.enhancedApiDataModels).toBe(enhancedApiData);
    });
  });

});