'use strict';

class documentationController {
  constructor(documentationService) {
    'ngInject';
    const self = this;

    self.documentationService = documentationService;
    self.documentationLoaded = false;
    self.isError = false;
    self.basicApiDataModels = [];
    self.enhancedApiDataModels = [];

    self.loadApiDataModels();
  }

  loadApiDataModels() {
    const self = this;

    self.documentationService.getBasic()
      .then((response) => {
        self.basicApiDataModels = response;
      })
      .then(() => {
        return self.documentationService.getEnhanced();
      })
      .then((response) => {
        self.enhancedApiDataModels = response;
        self.documentationLoaded = true;
      })
      .catch((error) => {
        self.isError = true;
      });
  }
}

angular.module('areas.documentation').controller('documentationController', documentationController);