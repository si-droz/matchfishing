'use strict';

angular.module('areas.documentation', ['templates']);