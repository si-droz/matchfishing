'use strict';

function loadingInterceptor($q, LoadingService) {
    'ngInject';

    var xhrCreations = 0;
    var xhrResolutions = 0;

    function isLoading() {
        return xhrResolutions < xhrCreations;
    }

    function updateStatus() {
        LoadingService.setLoading(isLoading());
    }

    const loadingInterceptor = {
        request: (config) => {
            xhrCreations++;
            updateStatus();
            return config;
        },
        requestError: (rejection) => {
            xhrCreations++;
            updateStatus();
            return $q.reject(rejection);
        },
        response: (response) => {

            xhrResolutions++;
            updateStatus();

            return response;
        },
        responseError: (rejection) => {
            xhrResolutions++;
            updateStatus();
            return $q.reject(rejection);
        }
    };

    return loadingInterceptor;
}

angular.module('partners.management').factory('LoadingInterceptor', loadingInterceptor);
