'use strict';

angular.module('partners.management').constant('breadcrumbsExclusions', {update: 'update'});
