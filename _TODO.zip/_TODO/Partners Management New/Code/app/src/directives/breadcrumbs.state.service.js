'use strict';

function breadcrumbsStateService ($rootScope) {
    'ngInject';
    let service;
    let state;

    service = {
        get: () => {
            return state;
        },
        set: (path) => {
            state = path;
        },
        update: (arrayOfMappings) => {
            $rootScope.$emit('routeUpdate', arrayOfMappings);
        }
    };

    return service;
}

angular.module('partners.management').service('breadcrumbsStateService', breadcrumbsStateService);
