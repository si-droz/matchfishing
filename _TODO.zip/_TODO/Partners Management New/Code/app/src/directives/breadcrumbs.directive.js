'use strict';

function breadcrumbsDirective($rootScope, $location, productService, productClientService, breadcrumbsExclusions, breadcrumbsStateService) {
  return {
    replace: true,
    transclude: true,
    restrict: 'E',
    scope: {},
    template: `<div>\
                <ul class="breadcrumbs">\
                  <li>\
                    <ng-switch on="breadcrumbs.length === 0">\
                      <span ng-switch-when="true">Home</span>\
                      <span ng-switch-default><a href="/">Home</a></span>\
                    </ng-switch>\
                  </li>\
                  <li ng-repeat="breadcrumb in breadcrumbs">\
                    <span class="divider">></span>\
                    <ng-switch on="$last">\
                      <span ng-switch-when="true">{{breadcrumb.name}}</span>\
                      <span ng-switch-default>\
                          <span ng-switch on="{{breadcrumbsExclusions.hasOwnProperty(breadcrumb.name)}}">\
                                <span ng-switch-when="true">\
                                  {{breadcrumb.name}}\
                                </span>\
                                <span ng-switch-default>\
                                  <a href="{{breadcrumb.url}}">{{breadcrumb.name}}</a>\
                                </span>\
                           </span>\
                      </span>\
                    </ng-switch>\
                  </li>\
                </ul>\
              </div>`,
    link: (scope, element, attrs) => {

      $rootScope.$on('routeUpdate', (event, data) => {
        const current = breadcrumbsStateService.get();
        current.forEach((breadcrumb, i) => {
          data.forEach((item, i) => {
            if (breadcrumb.name === item.id) {
              breadcrumb.name = item.value;
            }
          });
        });
      });

      $rootScope.$on('$routeChangeSuccess', (a, b, c, d, e) => {
        const guidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

        scope.breadcrumbs = [];
        scope.breadcrumbsExclusions = breadcrumbsExclusions;
        if ($location.path() === '/') {
          return scope.breadcrumbs;
        } else {
          let segments = $location.path().split('/').slice(1);
          segments.map((segment) => {

            let index;
            index = segments.indexOf(segment);

            // ensure proper casing for breadcrumbs, but leave guids
            // intact as these are converted to the product/client name
            var name;
            if (segment.match(guidPattern)) {
              name = segment;
            } else {
              name = segment.charAt(0).toUpperCase() + segment.slice(1).toLowerCase();
            }

            let url = "/" + (segments.slice(0, +index + 1 || 9e9).join('/'));

            scope.breadcrumbs.push({
              name: name,
              url: url
            });
          });

          breadcrumbsStateService.set(scope.breadcrumbs);
        }
      });
    }
  };
}


angular.module('partners.management').directive('breadcrumbs', breadcrumbsDirective);
