'use strict';

pmMessageLoggerDirective.$inject = ["$log"];
function pmMessageLoggerDirective($log) {
    return {
        link: function link(scope, element, attr) {
            $log.debug(element[0].textContent);
        }
    };
}

angular.module('partners.management').directive('pmMessageLogger', pmMessageLoggerDirective);