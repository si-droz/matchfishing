'use strict';

angular.module('partners.management').directive('mutedAnchor', function () {
    return {
        compile: function compile(tElement, tAttrs, transclude) {
            //Disable ngClick
            tAttrs["ngClick"] = "!(" + tAttrs["mutedAnchor"] + ") && (" + tAttrs["ngClick"] + ")";

            //return a link function
            return function (scope, iElement, iAttrs) {

                //Toggle "disabled" to class when mutedAnchor becomes true
                scope.$watch(iAttrs["mutedAnchor"], function (newValue) {
                    if (newValue !== undefined) {
                        iElement.toggleClass("disabled", newValue);
                    }
                });

                //Disable href on click
                iElement.on("click", function (e) {
                    if (scope.$eval(iAttrs["mutedAnchor"])) {
                        e.preventDefault();
                    }
                });
            };
        }
    };
});