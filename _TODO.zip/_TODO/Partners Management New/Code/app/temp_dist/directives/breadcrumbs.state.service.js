'use strict';

breadcrumbsStateService.$inject = ["$rootScope"];
function breadcrumbsStateService($rootScope) {
    'ngInject';

    var service = void 0;
    var state = void 0;

    service = {
        get: function get() {
            return state;
        },
        set: function set(path) {
            state = path;
        },
        update: function update(arrayOfMappings) {
            $rootScope.$emit('routeUpdate', arrayOfMappings);
        }
    };

    return service;
}

angular.module('partners.management').service('breadcrumbsStateService', breadcrumbsStateService);