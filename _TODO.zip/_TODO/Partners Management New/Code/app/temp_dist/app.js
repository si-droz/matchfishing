'use strict';

// vendor scripts

var _angularMin = require('../bower_components/angular/angular.min.js');

var _angularMin2 = _interopRequireDefault(_angularMin);

require('../bower_components/angular-route/angular-route.min.js');

require('../bower_components/angular-translate/angular-translate.min.js');

require('../bower_components/angular-bootstrap/ui-bootstrap.min.js');

require('../bower_components/angular-bootstrap/ui-bootstrap-tpls.min.js');

require('../bower_components/angularLocalStorage/dist/angularLocalStorage.min.js');

require('../bower_components/angular-animate/angular-animate.min.js');

require('../bower_components/angular-cookies/angular-cookies.min.js');

require('../bower_components/angular-resource/angular-resource.min.js');

require('../bower_components/angular-sanitize/angular-sanitize.min.js');

require('../bower_components/angular-touch/angular-touch.min.js');

require('../bower_components/angular-messages/angular-messages.min.js');

require('../bower_components/angular-md5/angular-md5.min.js');

require('../bower_components/checklist-model/checklist-model.js');

require('../bower_components/angular-translate-loader-static-files/angular-translate-loader-static-files.min.js');

require('./app.templates.js');

require('./areas/home/home.module.js');

require('./areas/home/controllers/home.controller.js');

require('./areas/home/services/hero.service.js');

require('./areas/product/product.module.js');

require('./areas/product/services/product.service.js');

require('./areas/product/filters/flowFormatter.filter.js');

require('./areas/product/controllers/product.list.controller.js');

require('./areas/product/controllers/product.edit.controller.js');

require('./areas/product/areas/client/product.client.module.js');

require('./areas/product/areas/client/services/product.client.service.js');

require('./areas/product/areas/client/services/azure.api.service.js');

require('./areas/product/areas/client/controllers/product.client.list.controller.js');

require('./areas/documentation/documentation.module.js');

require('./areas/documentation/controllers/documentation.controller.js');

require('./areas/documentation/services/documentation.service.js');

require('./areas/guidance/guidance.module.js');

require('./areas/guidance/controllers/guidance.controller.js');

require('./areas/guidance/services/guidance.service.js');

require('./app.module.js');

require('./directives/angularJsOAuth2.js');

require('./directives/pmMessageLogger.directive.js');

require('./directives/breadcrumbs.exclusions.constant.js');

require('./directives/breadcrumbs.state.service.js');

require('./directives/breadcrumbs.directive.js');

require('./directives/mutedAnchor.directive.js');

require('./directives/ngToast.directive.js');

require('./directives/autofocus.directive');

require('./interceptors/loading.interceptor.js');

require('./services/loading.service.js');

require('./env.config.js');

require('./app.config.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }