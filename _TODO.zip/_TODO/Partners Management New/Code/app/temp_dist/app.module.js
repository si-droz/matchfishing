'use strict';

angular.module('partners.management', ['ui.bootstrap', 'partners.management.config', 'pascalprecht.translate', 'ngToast', 'ngAnimate', 'ngCookies', 'ngResource', 'angularLocalStorage', 'ngRoute', 'ngSanitize', 'ngTouch', 'afOAuth2', 'ngMessages', 'areas.home', 'areas.product', 'areas.product.client', 'areas.documentation', 'areas.guidance', 'utils.autofocus', 'checklist-model']);