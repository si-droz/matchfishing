'use strict';

loadingInterceptor.$inject = ["$q", "LoadingService"];
function loadingInterceptor($q, LoadingService) {
    'ngInject';

    var xhrCreations = 0;
    var xhrResolutions = 0;

    function isLoading() {
        return xhrResolutions < xhrCreations;
    }

    function updateStatus() {
        LoadingService.setLoading(isLoading());
    }

    var loadingInterceptor = {
        request: function request(config) {
            xhrCreations++;
            updateStatus();
            return config;
        },
        requestError: function requestError(rejection) {
            xhrCreations++;
            updateStatus();
            return $q.reject(rejection);
        },
        response: function response(_response) {

            xhrResolutions++;
            updateStatus();

            return _response;
        },
        responseError: function responseError(rejection) {
            xhrResolutions++;
            updateStatus();
            return $q.reject(rejection);
        }
    };

    return loadingInterceptor;
}

angular.module('partners.management').factory('LoadingInterceptor', loadingInterceptor);