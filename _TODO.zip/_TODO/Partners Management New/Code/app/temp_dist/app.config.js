'use strict';

angular.module('partners.management').config(["$locationProvider", "$routeProvider", "$compileProvider", "$httpProvider", "ngToastProvider", function ($locationProvider, $routeProvider, $compileProvider, $httpProvider, ngToastProvider) {
    'ngInject';

    $compileProvider.debugInfoEnabled(true); // change it in production to boost performance

    ngToastProvider.configure({
        animation: 'fade',
        horizontalPosition: 'right',
        verticalPosition: 'top',
        maxNumber: 0,
        combineDuplications: true,
        className: 'success',
        timeout: 2000
    });

    $locationProvider.html5Mode({
        enabled: true
    });

    $routeProvider.when('/', {
        templateUrl: 'src/areas/home/tmpl/home.html',
        controller: 'homeController',
        controllerAs: 'vm'
    }).when('/products', {
        templateUrl: 'src/areas/product/tmpl/list.html',
        controller: 'productListController',
        controllerAs: 'vm',
        requireToken: true
    }).when('/products/create', {
        templateUrl: 'src/areas/product/tmpl/edit.html',
        controller: 'productEditController',
        controllerAs: 'vm',
        requireToken: true,
        resolve: {
            productId: ["$route", function productId($route) {
                return $route.current.params.productId;
            }]
        }
    }).when('/products/:productId', {
        redirectTo: '/products/:productId/clients'
    }).when('/products/:productId/clients', {
        templateUrl: 'src/areas/product/areas/client/tmpl/list.html',
        controller: 'productClientListController',
        controllerAs: 'vm',
        requireToken: true,
        resolve: {
            productId: ["$route", function productId($route) {
                return $route.current.params.productId;
            }]
        }
    }).when('/documentation', {
        templateUrl: 'src/areas/documentation/tmpl/documentation.html',
        controller: 'documentationController',
        controllerAs: 'vm'
    }).when('/guidance', {
        templateUrl: 'src/areas/guidance/tmpl/guidance.html',
        controller: 'guidanceController',
        controllerAs: 'vm'
    }).otherwise({ redirectTo: '/' });

    $httpProvider.interceptors.push('LoadingInterceptor');
}]).config(["$translateProvider", function ($translateProvider) {
    $translateProvider.useStaticFilesLoader({
        files: [{
            prefix: '/lang/local-',
            suffix: '.json'
        }]
    });

    $translateProvider.useSanitizeValueStrategy('escapeParameters');
    $translateProvider.preferredLanguage('en');
}]).config(['$locationProvider', function ($locationProvider) {
    // see https://docs.angularjs.org/guide/migration#commit-aa077e8 - upgrading to angular 1.6.6 breaks routing
    $locationProvider.hashPrefix('');
}]).run(["$window", "$rootScope", function ($window, $rootScope) {

    $rootScope.$on('oauth2:authSuccess', function (data) {
        var token = $window.sessionStorage.getItem('token');

        try {
            var id = token.split('.')[1];
            $rootScope.userName = JSON.parse($window.atob(id))['sit'];
            $rootScope.isSignedIn = true;
        } catch (e) {
            $rootScope.userName = null;
            $rootScope.isSignedIn = false;
        }
    });
}]);