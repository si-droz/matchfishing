'use strict';

describe('documentation.controller.js', function () {
  var documentationService = void 0,
      $q = void 0,
      $scope = void 0;

  beforeEach(angular.mock.inject(function ($rootScope, _$q_) {
    $q = _$q_;
    $scope = $rootScope.$new();
    documentationService = jasmine.createSpyObj('documentationService', ['getBasic', 'getEnhanced']);
  }));

  describe('get documentation', function () {
    var controller = void 0,
        deferredBasicCall = void 0,
        deferredEnhancedCall = void 0;
    var basicApiData = {};
    var enhancedApiData = {};

    it('loads API documentation data', function () {
      //Arrange
      deferredBasicCall = $q.defer();
      deferredEnhancedCall = $q.defer();

      deferredBasicCall.resolve(basicApiData);
      deferredEnhancedCall.resolve(enhancedApiData);

      documentationService.getBasic.and.returnValue(deferredBasicCall.promise);
      documentationService.getEnhanced.and.returnValue(deferredEnhancedCall.promise);

      //Act
      controller = new documentationController(documentationService);
      $scope.$apply();

      //Assert
      expect(documentationService.getBasic).toHaveBeenCalled();
      expect(documentationService.getEnhanced).toHaveBeenCalled();
      expect(controller.basicApiDataModels).toBe(basicApiData);
      expect(controller.enhancedApiDataModels).toBe(enhancedApiData);
    });
  });
});