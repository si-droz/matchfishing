'use strict';

function flowFormatter() {
  return function (input) {
    //TODO: move values to consts
    if (input === 'ClientCredential') {
      return 'Client Credentials';
    }
    if (input === 'Hybrid') {
      return 'Hybrid';
    }

    return input;
  };
}

angular.module('areas.product').filter('flowFormatter', flowFormatter);