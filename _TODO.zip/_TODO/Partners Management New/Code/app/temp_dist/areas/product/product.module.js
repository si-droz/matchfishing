'use strict';

angular.module('areas.product', ['templates', 'areas.product.client']);