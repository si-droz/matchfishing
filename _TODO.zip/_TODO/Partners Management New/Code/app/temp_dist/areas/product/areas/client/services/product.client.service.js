'use strict';

productClientService.$inject = ["$http", "EnvironmentConfig", "$cacheFactory"];
function productClientService($http, EnvironmentConfig, $cacheFactory) {
  'ngInject';

  var cache = $cacheFactory('product.client');
  var productsUrl = EnvironmentConfig.serviceApi + '/api/products';

  var service = {
    list: function list(productId) {
      return $http.get(productsUrl + '/' + productId + '/clients/').then(function (response) {
        return response.data;
      });
    },
    get: function get(productId, clientId) {
      return $http.get(productsUrl + '/' + productId + '/clients/' + clientId).then(function (response) {
        return response.data;
      });
    },
    create: function create(productId, client) {
      cache.remove(productsUrl + '/' + productId + '/clients/');
      return $http.post(productsUrl + '/' + productId + '/clients/', JSON.stringify(client), {
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    update: function update(productId, client) {
      cache.remove(productsUrl + '/' + productId + '/clients/');
      cache.remove(productsUrl + '/' + productId + '/clients/' + client.ExternalId);
      return $http.patch(productsUrl + '/' + productId + '/clients/', JSON.stringify(client), {
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    getReadOnlyClient: function getReadOnlyClient() {
      return $http.get(productsUrl + '/clients/getReadOnlyClient').then(function (response) {
        return response.data;
      });
    }
  };

  return service;
}

angular.module('areas.product').factory('productClientService', productClientService);