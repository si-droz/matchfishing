'use strict';

productService.$inject = ["$http", "EnvironmentConfig", "$cacheFactory"];
function productService($http, EnvironmentConfig, $cacheFactory) {
    'ngInject';

    var service = void 0;

    var cache = $cacheFactory('product');
    var productsUrl = EnvironmentConfig.serviceApi + '/api/products/';

    service = {
        list: function list(filter) {
            return $http.get(productsUrl).then(function (response) {
                return response.data;
            });
        },
        get: function get(productId) {
            return $http.get(productsUrl + '/' + productId).then(function (response) {
                return response.data;
            });
        },
        create: function create(product) {
            cache.remove(productsUrl);
            return $http.post(productsUrl, JSON.stringify(product), {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        },
        update: function update(product) {
            cache.remove(productsUrl);
            cache.remove(productsUrl + '/' + product.ExternalId);
            return $http.put(productsUrl, JSON.stringify(product), {
                headers: {
                    'Content-Type': 'application/json'
                }
            });
        }
    };

    return service;
}

angular.module('areas.product').factory('productService', productService);