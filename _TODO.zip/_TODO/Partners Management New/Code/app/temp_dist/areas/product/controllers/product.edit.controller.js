'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var productEditController = function () {
    productEditController.$inject = ["productService", "breadcrumbsStateService", "$location", "$log", "productId", "ngToast"];
    function productEditController(productService, breadcrumbsStateService, $location, $log, productId, ngToast) {
        'ngInject';

        _classCallCheck(this, productEditController);

        var self = this;

        self.breadcrumbsStateService = breadcrumbsStateService;
        self.productService = productService;
        self.ngToast = ngToast;
        self.$location = $location;
        self.$log = $log;
        self.productId = productId;

        self.notificationOptions = {
            content: '',
            className: 'success',
            classes: 'foo',
            dismissOnTimeout: true,
            timeout: 3000,
            dismissButton: true,
            dismissButtonHtml: '&times',
            dismissOnClick: true,
            compileContent: false
        };

        self.isError = false;

        if (productId) self.loadProduct(productId);
    }

    _createClass(productEditController, [{
        key: 'loadProduct',
        value: function loadProduct(productId) {
            var self = this;

            self.productService.get(productId).then(function (response) {
                self.existingProduct = response;
                self.product = angular.extend({}, self.existingProduct);

                self.breadcrumbsStateService.update([{ id: self.product.ExternalId, value: self.product.Name }]);
            }).catch(function (error) {
                self.isError = true;
            });
        }
    }, {
        key: 'createProduct',
        value: function createProduct(product) {
            var _this = this;

            var self = this;

            var isValid = self.validate();
            if (isValid) {
                self.productService.create(product).then(function (response) {
                    _this.$location.path('/products/' + response.data.ExternalId + '/clients');
                    self.notificationOptions.content = 'Product ' + product.Name + ' successfully created';
                    self.ngToast.create(self.notificationOptions);
                }).catch(function (error) {
                    if (error.status === 409) {
                        self.form.productName.$setValidity("nameConflict", false);
                    } else {
                        self.form.$setValidity("errorCreate", false);
                    }
                });
            }
        }
    }, {
        key: 'updateProduct',
        value: function updateProduct(product) {
            var _this2 = this;

            var self = this;

            var isValid = self.validate();
            if (isValid) {

                if (self.existingProduct.Name === self.product.Name) {
                    this.$location.path('/products');
                    return;
                }

                self.productService.update(product).then(function (response) {
                    _this2.$location.path('/products');
                    self.notificationOptions.content = 'Product ' + self.existingProduct.Name + ' successfully updated';
                    self.ngToast.create(self.notificationOptions);
                }).catch(function (error) {
                    if (error.status === 409) {
                        self.form.productName.$setValidity("nameConflict", false);
                    } else {
                        self.form.$setValidity("errorUpdate", false);
                    }
                });
            }
        }
    }, {
        key: 'validate',
        value: function validate() {
            var self = this;

            angular.forEach(self.form.$error, function (fields) {
                angular.forEach(fields, function (field) {
                    field.$setTouched();
                    field.$setDirty();
                });
            });

            return self.form.$valid;
        }
    }, {
        key: 'clearNameConflict',
        value: function clearNameConflict() {
            var self = this;

            self.form.productName.$setValidity("nameConflict", null);
        }
    }]);

    return productEditController;
}();

angular.module('areas.product').controller('productEditController', productEditController);