'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var productListController = function () {
    productListController.$inject = ["productService", "$location", "$log", "$translate"];
    function productListController(productService, $location, $log, $translate) {
        'ngInject';

        _classCallCheck(this, productListController);

        var self = this;

        self.productService = productService;
        self.$location = $location;
        self.$log = $log;

        self.products = [];
        self.loadProducts();

        // validation variables
        self.productsLoaded = false;
        self.productsLoadedEmpty = false;
        self.isError = false;
    }

    _createClass(productListController, [{
        key: 'loadProducts',
        value: function loadProducts() {
            var self = this;

            self.productService.list().then(function (response) {
                if (response.length === 0) {
                    self.productsLoadedEmpty = true;
                    return;
                }
                angular.forEach(response, function (value, key) {
                    var product = {};
                    product.Name = value.Name;
                    product.ExternalId = value.ExternalId;
                    self.products.push(product);
                });
                self.productsLoaded = true;
            }).catch(function (error) {
                self.isError = true;
            });
        }
    }]);

    return productListController;
}();

angular.module('areas.product').controller('productListController', productListController);