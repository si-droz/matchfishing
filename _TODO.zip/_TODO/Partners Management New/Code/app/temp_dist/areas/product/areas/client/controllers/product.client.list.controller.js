'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var productClientListController = function () {
    productClientListController.$inject = ["productService", "productClientService", "breadcrumbsStateService", "productId", "$location"];
    function productClientListController(productService, productClientService, breadcrumbsStateService, productId, $location) {
        'ngInject';

        _classCallCheck(this, productClientListController);

        var self = this;

        self.breadcrumbsStateService = breadcrumbsStateService;
        self.productService = productService;
        self.productClientService = productClientService;
        self.productName = '';
        self.ExternalId = '';
        self.productId = productId;

        self.$location = $location;

        self.pageLoaded = false;
        self.serviceCount = 0;
        self.clientsLoaded = false;
        self.clientsLoadedEmpty = false;

        self.demoSystemsLoaded = false;
        self.demoSystemsLoadedEmpty = false;

        self.isError = false;

        self.clients = [];
        self.demoSystems = [];
        self.loadClients(productId);
    }

    _createClass(productClientListController, [{
        key: 'showPage',
        value: function showPage() {
            var self = this;
            if (self.serviceCount == 1) {
                self.pageLoaded = true;
            }
        }
    }, {
        key: 'loadClients',
        value: function loadClients(productId) {
            var self = this;

            self.productService.get(productId).then(function (product) {
                self.productName = product.Name;
                self.ExternalId = product.ExternalId;

                self.productClientService.list(self.ExternalId).then(function (response) {
                    if (response.length === 0) {
                        self.clientsLoadedEmpty = true;
                        return;
                    }
                    angular.forEach(response, function (value, key) {
                        var client = {};
                        client.ClientId = value.ClientId;
                        client.Name = value.Name;
                        client.Flow = value.Flow;
                        client.OcpApiKey = value.OcpApiKey;
                        client.SimsIdStsServer = value.SimsIdStsServer;
                        client.Secrets = value.Secrets;
                        client.RedirectUris = value.RedirectUris;
                        client.ExternalId = value.ExternalId;
                        client.DemoSystemAssociations = value.DemoSystemAssociations;
                        client.ExternalApis = value.ExternalApis;
                        client.IsFreemium = value.Name.indexOf("Freemium") != -1;
                        client.AllowedScopes = value.AllowedScopes;

                        self.clients.push(client);
                    });
                    self.clientsLoaded = true;
                }).catch(function (error) {
                    self.isError = true;
                });
                self.serviceCount++;
                self.breadcrumbsStateService.update([{ id: self.ExternalId, value: self.productName }]);
                self.showPage();
            }).catch(function (error) {
                self.isError = true;
            });
        }
    }]);

    return productClientListController;
}();

angular.module('areas.product.client').controller('productClientListController', productClientListController);