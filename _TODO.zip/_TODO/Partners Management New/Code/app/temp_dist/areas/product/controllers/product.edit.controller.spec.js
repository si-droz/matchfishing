'use strict';

describe('product.edit.controller.js', function () {
  var productService = void 0,
      breadcrumbsStateService = void 0,
      product = void 0,
      $q = void 0,
      $scope = void 0,
      $httpBackend = void 0,
      $log = void 0,
      $location = void 0,
      ngToast = void 0;

  beforeEach(angular.mock.inject(function ($rootScope, _$httpBackend_, _$q_, _$location_, _$log_) {
    $q = _$q_;
    $scope = $rootScope.$new();
    $httpBackend = _$httpBackend_;
    $log = _$log_;
    $location = _$location_;

    product = { ExternalId: "cc34627c-5555-4db5-a29f-692b4dd7e791", Name: "existingProduct" };

    productService = jasmine.createSpyObj('productService', ['get', 'create', 'update']);
    productService.get.and.returnValue($q.resolve(product));
    productService.create.and.returnValue($q.defer().promise);
    productService.update.and.returnValue($q.defer().promise);

    breadcrumbsStateService = jasmine.createSpyObj('breadcrumbsStateService', ['update']);

    ngToast = jasmine.createSpyObj('ngToast', ['create']);
  }));

  afterEach(function () {
    $httpBackend.verifyNoOutstandingExpectation();
    $httpBackend.verifyNoOutstandingRequest();
  });

  describe('initialization', function () {
    it('should not get product without productId specified', function () {
      //Act
      var controller = new productEditController(productService, breadcrumbsStateService, $location, $log);

      //Assert
      expect(controller).toBeDefined();
      expect(productService.get).not.toHaveBeenCalled();
    });
    it('should get product with productId specified', function () {
      //Act
      var controller = new productEditController(productService, breadcrumbsStateService, $location, $log, product.ExternalId);

      //Assert
      expect(controller).toBeDefined();
      expect(productService.get).toHaveBeenCalledWith(product.ExternalId);
    });
  });

  describe('createProduct', function () {
    var controller = void 0;
    beforeEach(function () {
      controller = new productEditController(productService, breadcrumbsStateService, $location, $log, undefined, ngToast);
    });

    it('should do nothing when the model is not valid', function () {
      //Arrange
      spyOn(controller, 'validate').and.returnValue(false);

      //Act
      controller.createProduct({});

      //Assert
      expect(productService.create).not.toHaveBeenCalled();
    });

    it('should create a product ', function () {
      //Arrange
      spyOn(controller, 'validate').and.returnValue(true);
      var productName = 'newProduct';
      var externalId = '21310E16-1AAD-45C6-8B77-6BA9F1A11089';
      productService.create.and.returnValue($q.defer().promise);

      //Act
      controller.createProduct({ Name: productName, ExternalId: externalId });

      //Assert
      expect(productService.create).toHaveBeenCalled();
    });
  });

  describe('updateProduct', function () {
    var controller = void 0;
    beforeEach(function () {
      controller = new productEditController(productService, breadcrumbsStateService, $location, $log, product.ExternalId);
    });

    it('should do nothing when the model is not valid', function () {
      //Arrange
      spyOn(controller, 'validate').and.returnValue(false);
      console.log(controller.existingProduct);

      //Act
      controller.updateProduct({});

      //Assert
      expect(productService.update).not.toHaveBeenCalled();
    });
  });
});