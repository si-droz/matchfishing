'use strict';

azureApiService.$inject = ["$http", "EnvironmentConfig"];
function azureApiService($http, EnvironmentConfig) {
    'ngInject';

    var service = void 0;
    var azureApiUrl = EnvironmentConfig.serviceApi + '/api/azureApi';

    service = {
        get: function get(clientId) {
            return $http.get(azureApiUrl + '/' + clientId).then(function (response) {
                return response.data;
            });
        },
        getReadOnlySubscriptionKey: function getReadOnlySubscriptionKey() {
            return $http.get(azureApiUrl + '/getReadOnlySubscriptionKey').then(function (response) {
                return response.data;
            });
        }
    };

    return service;
}

angular.module('areas.product').factory('azureApiService', azureApiService);