'use strict';

guidanceService.$inject = ["$http", "EnvironmentConfig", "$cacheFactory"];
function guidanceService($http, EnvironmentConfig, $cacheFactory) {
  'ngInject';

  var cache = $cacheFactory('guidance');

  var guidanceIndexUrl = EnvironmentConfig.azureGuidanceContainerUrl + '/guidance/documentIndex.json';

  function _getGuidanceDocuments() {
    return $http.get(guidanceIndexUrl, { cache: cache }).then(function (response) {
      return response.data;
    });
  }

  var service = {
    getGuidanceDocuments: function getGuidanceDocuments() {
      return _getGuidanceDocuments();
    }
  };

  return service;
}

angular.module('areas.guidance').factory('guidanceService', guidanceService);