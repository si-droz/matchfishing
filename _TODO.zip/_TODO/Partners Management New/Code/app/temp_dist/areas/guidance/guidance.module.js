'use strict';

angular.module('areas.guidance', ['templates']);