'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var guidanceController = function () {
  guidanceController.$inject = ["guidanceService"];
  function guidanceController(guidanceService) {
    'ngInject';

    _classCallCheck(this, guidanceController);

    var self = this;

    self.guidanceService = guidanceService;
    self.guidanceLoaded = false;
    self.isError = false;
    self.guidanceDocuments = [];

    self.loadGuidanceDocuments();
  }

  _createClass(guidanceController, [{
    key: 'loadGuidanceDocuments',
    value: function loadGuidanceDocuments() {
      var self = this;

      self.guidanceService.getGuidanceDocuments().then(function (response) {
        self.guidanceDocuments = response;
      }).then(function () {
        self.guidanceLoaded = true;
      }).catch(function () {
        self.isError = true;
      });
    }
  }]);

  return guidanceController;
}();

angular.module('areas.guidance').controller('guidanceController', guidanceController);