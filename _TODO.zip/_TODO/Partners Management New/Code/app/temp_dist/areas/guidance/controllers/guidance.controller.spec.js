'use strict';

describe('guidance.controller.js', function () {
  var guidanceService = void 0,
      $q = void 0,
      $scope = void 0;

  beforeEach(angular.mock.inject(function ($rootScope, _$q_) {
    $q = _$q_;
    $scope = $rootScope.$new();
    guidanceService = jasmine.createSpyObj('guidanceService', ['getGuidanceDocuments']);
  }));

  describe('get guidance', function () {
    var controller = void 0,
        deferredGetDocumentsCall = void 0;
    var guidanceDocuments = {};

    it('loads guidance documents', function () {

      //Arrange
      deferredGetDocumentsCall = $q.defer();
      deferredGetDocumentsCall.resolve(guidanceDocuments);
      guidanceService.getGuidanceDocuments.and.returnValue(deferredGetDocumentsCall.promise);

      //Act
      controller = new guidanceController(guidanceService);
      $scope.$apply();

      //Assert
      expect(guidanceService.getGuidanceDocuments).toHaveBeenCalled();
      expect(controller.guidanceDocuments).toBe(guidanceDocuments);
    });
  });
});