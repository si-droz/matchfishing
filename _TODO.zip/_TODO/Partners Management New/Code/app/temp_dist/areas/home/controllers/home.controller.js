'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var homeController = function () {
  homeController.$inject = ["heroService"];
  function homeController(heroService) {
    'ngInject';

    _classCallCheck(this, homeController);

    var self = this;

    self.heroService = heroService;
    self.heroHtml = "<div class='jumbotron' style='padding-left: 60px;'><h1>Partners Development Portal</h1></div>";
    self.heroImageUrl = "";
    self.loadHero();
  }

  _createClass(homeController, [{
    key: 'loadHero',
    value: function loadHero() {
      var self = this;

      self.heroService.getHeroText().then(function (response) {
        self.heroHtml = response;
      });

      self.heroImageUrl = self.heroService.getHeroImageUrl();
    }
  }]);

  return homeController;
}();

angular.module('areas.home').controller('homeController', homeController);