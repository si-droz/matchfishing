'use strict';

describe('home.controller.js', function () {
  var heroService = void 0,
      $q = void 0,
      $scope = void 0;

  beforeEach(angular.mock.inject(function ($rootScope, _$q_) {
    $q = _$q_;
    $scope = $rootScope.$new();
    heroService = jasmine.createSpyObj('heroService', ['getHeroText', 'getHeroImageUrl']);
  }));

  describe('get hero', function () {
    var controller = void 0,
        deferredGetCall = void 0;
    var heroHtml = "<div class='jumbotron' style='padding-left: 60px;'><h1>Partners Development Portal</h1></div>";
    var heroImageUrl = "http://test.com/image.jpg";

    it('load hero html', function () {

      //Arrange
      deferredGetCall = $q.defer();
      deferredGetCall.resolve(heroHtml);
      heroService.getHeroText.and.returnValue(deferredGetCall.promise);
      heroService.getHeroImageUrl.and.returnValue(heroImageUrl);

      //Act
      controller = new homeController(heroService);
      $scope.$apply();

      //Assert
      expect(heroService.getHeroText).toHaveBeenCalled();
      expect(controller.heroHtml).toBe(heroHtml);

      expect(heroService.getHeroImageUrl).toHaveBeenCalled();
      expect(controller.heroImageUrl).toBe(heroImageUrl);
    });
  });
});