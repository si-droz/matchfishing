'use strict';

angular.module('areas.home', ['templates']);