'use strict';

heroService.$inject = ["$http", "EnvironmentConfig", "$cacheFactory"];
function heroService($http, EnvironmentConfig, $cacheFactory) {
    'ngInject';

    var cache = $cacheFactory('hero');
    var heroUrl = EnvironmentConfig.serviceApi + '/home/api/hero';
    var heroImageUrl = EnvironmentConfig.azureContainerUrl + '/images/HeroImage.jpg';

    var service = {
        getHeroText: function getHeroText() {
            return $http.get(heroUrl, { cache: cache }).then(function (response) {
                return response.data;
            });
        },
        getHeroImageUrl: function getHeroImageUrl() {
            return heroImageUrl;
        }
    };
    return service;
}

angular.module('areas.home').factory('heroService', heroService);