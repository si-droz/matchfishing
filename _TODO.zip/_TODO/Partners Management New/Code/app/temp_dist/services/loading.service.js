'use strict';

loadingService.$inject = ["$rootScope"];
function loadingService($rootScope) {
    'ngInject';

    var self = this;
    self.setLoading = function (loading) {
        $rootScope.loadingView = loading;
    };
}

angular.module('partners.management').service('LoadingService', loadingService);