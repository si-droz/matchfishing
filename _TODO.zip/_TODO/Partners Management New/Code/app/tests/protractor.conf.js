'use strict';

// var browserstack = require('browserstack-local');

//jshint strict: false
exports.config = {

  allScriptsTimeout: '80000',

  specs: [
    'e2e/specs/*.spec.js'
  ],

  capabilities: {

    browserName: 'chrome',
    'chromeOptions': {
      args: ['--test-type --disable-extensions']
    },
    logName: 'Chrome - English'
        // browserName: 'phantomjs',
    // 'phantomjs.binary.path': require('phantomjs').path
  },

  directConnect: true,

  chromeDriver: 'chromedriver.exe',

  // disableEnvironmentOverrides: true,
  //
  // skipSourceMapSupport: true,
  //
  // untrackOutstandingTimeouts: true,

  framework: 'jasmine',

  rootElement: 'html',

  jasmineNodeOpts: {
    showColors:true,
    defaultTimeoutInterval: 30000
  }
};
