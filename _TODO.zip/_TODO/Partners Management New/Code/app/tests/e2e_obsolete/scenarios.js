// !!! keeping it for now

// 'use strict';
//
// /* https://github.com/angular/protractor/blob/master/docs/toc.md */
//
// // var webdriver = require('selenium-webdriver');
//
// describe('Partner Management', () => {
//
//   browser.ignoreSynchronization = true;
//
//   beforeEach(() => {
//
//         // browser.driver.manage().window().setSize(1280, 1024);
//
//         // browser = webdriver.PhantomJS();
//         // browser.manage().window().setSize(1280, 1024);
//         browser.get('https://localhost:44323/#/');
//         // browser.waitForAngular();
//       //  browser.driver.get('https://localhost:44323');
//         //  return browser.driver.wait(function() {
//         //       return browser.driver.getCurrentUrl().then(function (url) {
//         //           return url.indexOf('https://accounts.google.com/') > -1;
//         //       });
//         //   }, 5000);
//           //whatever you want after
//     });
//
//   it('should log it', () => {
//       element(by.id('sign-in-button')).click();
//
//       browser.sleep(2000);
//       //
//       let usenameInput = element(by.id('cred_userid_inputtext'));
//       usenameInput.sendKeys('adam01@pamad.onMicrosoft.com');
//       //
//       let passwordInput = element(by.id('cred_password_inputtext'));
//       passwordInput.sendKeys('Pa$$w0rd');
//       //
//       browser.sleep(5000);
//       //
//       element(by.id('cred_sign_in_button')).click();
//       //
//       browser.sleep(2000);
//       //
//       expect(browser.getTitle()).toEqual('Partners Management');
//   });
//
//   it('should go to the list of products', () => {
//       element(by.id('manage-products-link')).click();
//
//       browser.sleep(1000);
//
//       let productList = element(by.id('product-list-header'));
//
//       expect(productList.isDisplayed()).toBe(true);
//   });
//
//   var productName = Math.random();
//
//   it('should create a product', () => {
//       element(by.id('manage-products-link')).click();
//
//       browser.sleep(1000);
//
//       element(by.id('product-create-link')).click();
//
//       let productNameInput = element(by.id('product-name-input'));
//       productNameInput.sendKeys(productName);
//
//       browser.sleep(2000);
//
//       element(by.id('product-create-button')).click();
//
//       browser.sleep(2000);
//
//       expect(element(by.css('.product-list-element')).isPresent()).toBe(true);
//   });
//   //
//   it('should list a product clients', () => {
//       // element(by.id('manage')).click();
//       //
//       // browser.sleep(1000);
//       //
//       // let productNameInput = element(by.id('product-name-input'));
//       // productNameInput.sendKeys(productName);
//       //
//       // browser.sleep(1000);
//       //
//       // expect(element.all(by.css('product-list-element')).length).toBe(1);
//       expect(true).toBe(true);
//   });
//
// });
