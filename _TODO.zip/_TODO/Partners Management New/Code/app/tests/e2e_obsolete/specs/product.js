'use strict';

var homePage = require('../pages/home.page.js');
var vendorPage = require('../pages/vendor.authentication.page.js');
var identityPage = require('../pages/identity.page.js');
var productPage = require('../pages/product.page.js');
var productCreatePage = require('../pages/product.create.page.js');

describe('Product Creation', () => {
  browser.ignoreSynchronization = true;

  beforeAll(() => {
        homePage.land();
        //
        homePage.signIn();

        vendorPage.waitUntilLoaded();
        vendorPage.login('adam01@pamad.onMicrosoft.com', 'Pa$$w0rd');

        homePage.waitUntilLoaded();
        expect(homePage.manageLink.isPresent()).toBeTruthy();

    });

    it('should create a product', () => {
        homePage.manageProducts();

        productPage.waitUntilLoaded();
        productPage.createProduct();

        productCreatePage.waitUntilLoaded();
        productCreatePage.submitProduct();

        productPage.waitUntilLoaded();
    });

  afterAll(() => {
    homePage.signOut();
    identityPage.waitUntilLoaded();
    identityPage.logOut();
  });


});
