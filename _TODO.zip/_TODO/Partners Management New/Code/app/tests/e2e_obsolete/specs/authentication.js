'use strict';

var homePage = require('../pages/home.page.js');
var vendorPage = require('../pages/vendor.authentication.page.js');
var identityPage = require('../pages/identity.page.js');

describe('Authentication', () => {
  browser.ignoreSynchronization = true;

  beforeEach(() => {
        homePage.land();
    });

  it('should log in and get back on home page', () => {
      homePage.signIn();

      vendorPage.waitUntilLoaded();
      vendorPage.login('adam01@pamad.onMicrosoft.com', 'Pa$$w0rd');

      homePage.waitUntilLoaded();
      expect(homePage.manageLink.isPresent()).toBeTruthy();
  });

  it('should log out and get back on home page', () => {
      homePage.signOut();

      identityPage.waitUntilLoaded();
      identityPage.logOut();

      homePage.waitUntilLoaded();
      expect(homePage.manageLink.isPresent()).toBeTruthy();
  });

});
