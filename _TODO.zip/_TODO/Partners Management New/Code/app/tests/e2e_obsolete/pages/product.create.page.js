'use strict';

var basePage = require('./base.page.js');

var productCreatePage = function() {
  this.productName = element(by.id('product-name-input'));
  this.productCreateButton = element(by.id('product-create-button'));

  this.waitUntilLoaded = function() {
    browser.wait(this.inDom(this.productName), 10000);
  };

  this.submitProduct = function(productName) {
    this.productName.sendKeys(productName);
    this.productCreateButton.click();
  };

};

productCreatePage.prototype = basePage;
module.exports = new productCreatePage();
