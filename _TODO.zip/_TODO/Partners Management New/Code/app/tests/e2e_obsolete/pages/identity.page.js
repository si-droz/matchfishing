'use strict';

var basePage = require('./base.page.js');

var identityPage = function() {
  this.logOutButton = element.all(by.css('.btn')).first();

  this.waitUntilLoaded = function() {
    browser.wait(this.inDom(this.logOutButton), 10000);
  };

  this.logOut = function() {
    browser.wait(this.isClickable(this.logOutButton), 10000);
    this.logOutButton.click();
  };

};

identityPage.prototype = basePage;
module.exports = new identityPage();
