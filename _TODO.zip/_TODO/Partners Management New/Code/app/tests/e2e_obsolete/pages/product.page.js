'use strict';

var basePage = require('./base.page.js');

var productPage = function() {
  this.createProductLink = element(by.id('product-create-link'));
  this.productList = element(by.id('product-create-link'));

  this.waitUntilLoaded = function() {
    browser.wait(this.inDom(this.productList), 10000);
  };

  this.findCreatedProduct = function(productName) {
    return element(by.id('product-create-link')).all(element(by.xpath('.//*[.="productName"]')));
  };

  this.createProduct = function() {
    this.createProductLink.click();
  };

};

productPage.prototype = basePage;
module.exports = new productPage();
