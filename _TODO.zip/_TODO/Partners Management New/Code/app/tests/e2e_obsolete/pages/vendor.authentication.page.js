'use strict';

var basePage = require('./base.page.js');

var vendorLogin = function() {
  this.userInput = element(by.id('cred_userid_inputtext'));
  this.passwordInput = element(by.id('cred_password_inputtext'));
  this.signInButton = element(by.id('cred_sign_in_button'));

  this.waitUntilLoaded = function() {
    browser.wait(this.isClickable(this.signInButton), 10000);
  };

  this.login = function(user, pass) {
          browser.ignoreSynchronization = true;
    this.userInput.sendKeys(user);
    this.passwordInput.sendKeys(pass).then(() => {
      browser.wait(this.isClickable(this.signInButton), 10000).then(() => this.signInButton.click());
    });
  };

};

vendorLogin.prototype = basePage;
module.exports = new vendorLogin();
