'use strict';

var basePage = require('./base.page.js');

var partnerManagementHome = function() {
  this.signInButton = element(by.id('sign-in-button'));
  this.manageLink = element(by.id('manage-products-link'));
  //
  // this.url = 'https://localhost:44323/#/';
  // this.pageLoaded = this.isVisible(this.manageLink);

  this.land = function() {
    browser.get('https://localhost:44323/#/');
  };

  this.waitUntilLoaded = function() {
    browser.wait(this.inDom(this.manageLink), 10000);
  };

  this.manageProducts = function() {
    this.manageLink.click();
  };

  this.signIn = function() {
    this.signInButton.click();
  };

  this.signOut = function() {
    this.signInButton.click();
  };

};

partnerManagementHome.prototype = basePage;
module.exports = new partnerManagementHome();
