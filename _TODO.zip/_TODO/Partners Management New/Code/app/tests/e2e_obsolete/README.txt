We have moved integration testing to Integration Testing Repository, protractor work will not be continued
