output: {
  // your stuff
  publicPath: './app/dist/'
}
