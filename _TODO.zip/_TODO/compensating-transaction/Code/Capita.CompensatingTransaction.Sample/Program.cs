﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Serilog;

namespace Capita.CompensatingTransaction.Sample
{
    public class Program
    {
        private static void Main()
        {
            Log.Logger = new LoggerConfiguration().MinimumLevel.Verbose()
                                                  .WriteTo.Console()
                                                  .CreateLogger();

            var cancellationTokenSource = new CancellationTokenSource();

            Console.CancelKeyPress += (s, e) =>
                                      {
                                          e.Cancel = true;
                                          cancellationTokenSource.Cancel();
                                      };

            MainAsync(cancellationTokenSource.Token).Wait(cancellationTokenSource.Token);

            Log.Information("Done. Press any key to exit.");
            Console.ReadKey();
        }

        internal static async Task MainAsync(CancellationToken token)
        {
            var compensatingTransactionExecuter = new CompensatingTransactionExecuter();

            var createSystemUserActivityTasks = new List<ActivityTask<CreateSystemUserContext>>
                                               {
                                                   new CreateAzureActiveDirectoryUserActivityTask(),
                                                   new CreateAzureApiManagerUserActivityTask()
                                               };

            ActivityOutcome createSystemUserActivityOutcome = await compensatingTransactionExecuter.ExecuteSynchronouslyAsync(createSystemUserActivityTasks, new CreateSystemUserContext());

            OutputActivityOutcome(createSystemUserActivityOutcome);
        }

        private static void OutputActivityOutcome(ActivityOutcome activityOutcome)
        {
            Log.Information("Activity execution complete");
            Log.Information("Summary");

            foreach(var activityTaskSummary in activityOutcome.ActivityTaskSummaries)
            {
                Log.Information($"Description: {activityTaskSummary.Description}");
                Log.Information($"Execution Status: {activityTaskSummary.ExecutionStatus}");
                Log.Information($"Compensation Status: {activityTaskSummary.CompensationStatus}");
                Log.Information("-----");
            }
        }

        internal class CreateSystemUserContext
        {
            public Guid AzureActiveDirectoryUserId { get; set; }
        }

        internal class CreateAzureActiveDirectoryUserActivityTask : ActivityTask<CreateSystemUserContext>
        {
            public CreateAzureActiveDirectoryUserActivityTask() : base("Create AAD user")
            {
            }

            protected override async Task<ActivityTaskOutcome> ExecuteAsync(CreateSystemUserContext context)
            {
                Log.Information("Creating user in Azure Azure Active Directory.");
                await Task.Delay(1000); //Simulate doing some work
                context.AzureActiveDirectoryUserId = Guid.NewGuid();
                Log.Information($"User created with ID {context.AzureActiveDirectoryUserId}");

                return new ActivityTaskOutcome(true);
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(CreateSystemUserContext context)
            {
                throw new NotImplementedException();
            }
        }

        internal class CreateAzureApiManagerUserActivityTask : ActivityTask<CreateSystemUserContext>
        {
            public CreateAzureApiManagerUserActivityTask() : base("Create Azure API user")
            {
            }

            protected override async Task<ActivityTaskOutcome> ExecuteAsync(CreateSystemUserContext context)
            {
                Log.Information($"Creating user in Azure API Manager with the ID of {context.AzureActiveDirectoryUserId}.");
                await Task.Delay(1000); //Simulate doing some work
                Log.Information("Azure API Manager user created.");

                return new ActivityTaskOutcome(true);
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(CreateSystemUserContext context)
            {
                throw new NotImplementedException();
            }
        }
    }
}