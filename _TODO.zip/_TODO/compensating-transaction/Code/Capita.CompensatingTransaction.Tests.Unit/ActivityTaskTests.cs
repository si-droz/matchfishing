﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;
using Shouldly;

namespace Capita.CompensatingTransaction.Tests.Unit
{
    [TestFixture]
    public class ActivityTaskTests
    {
        [Test]
        public void Constructor_DefaultPropertyValuesAreSetAsExpected()
        {
            var expectedDescription = "Test description";
            var activityTask = new TestActivityTask(expectedDescription);

            activityTask.Description.ShouldBe(expectedDescription);
            activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.NotAttempted);
            activityTask.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTask.ExecutionException.ShouldBeNull();
            activityTask.CompensationException.ShouldBeNull();
            activityTask.CompensationMessage.ShouldBe(string.Empty);
            activityTask.ExecutionMessage.ShouldBe(string.Empty);
        }

        [Test]
        public async Task ExecuteCoreAsync_WhenExecutionIsSuccessful_ExecutionStatusIsSetToSuccess()
        {
            var successfulExecutionTestActivityTask = new SuccessfulExecutionTestActivityTask();

            await successfulExecutionTestActivityTask.ExecuteCoreAsync(new TestContext());

            successfulExecutionTestActivityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
        }

        [Test]
        public async Task ExecuteCoreAsync_WhenExecutionFails_ExecutionStatusIsSetToFailed()
        {
            var successfulExecutionTestActivityTask = new FailingExecutionTestActivityTask();

            await successfulExecutionTestActivityTask.ExecuteCoreAsync(new TestContext());

            successfulExecutionTestActivityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Failed);
        }

        [Test]
        public async Task ExecuteCoreAsync_WhenExecutionThrowsException_ExecutionStatusIsSetToExceptionAndTheExecutionExceptionPropertyIsPopulatedWithTheThrownException()
        {
            var expectedExceptionToBeThrownOnExecuteCoreAsyncInvocation = new Exception();
            var successfulExecutionTestActivityTask = new ExceptionThrowingTestActivityTask(expectedExceptionToBeThrownOnExecuteCoreAsyncInvocation, null);

            await successfulExecutionTestActivityTask.ExecuteCoreAsync(new TestContext());

            successfulExecutionTestActivityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Exception);
            successfulExecutionTestActivityTask.ExecutionException.ShouldBe(expectedExceptionToBeThrownOnExecuteCoreAsyncInvocation);
        }

        [Test]
        public async Task CompensateCoreAsync_WhenCompensationIsSuccessful_CompensationStatusIsSetToSuccess()
        {
            var successfulCompensationTestActivityTask = new SuccessfulCompensationTestActivityTask();

            await successfulCompensationTestActivityTask.CompensateCoreAsync(new TestContext());

            successfulCompensationTestActivityTask.CompensationStatus.ShouldBe(CompensationStatus.Successful);
        }

        [Test]
        public async Task CompensateCoreAsync_WhenCompensationFails_CompensationStatusIsSetToFailed()
        {
            var failingCompensationTestActivityTask = new FailingCompensationTestActivityTask();

            await failingCompensationTestActivityTask.CompensateCoreAsync(new TestContext());

            failingCompensationTestActivityTask.CompensationStatus.ShouldBe(CompensationStatus.Failed);
        }

        [Test]
        public async Task CompensateCoreAsync_WhenCompensationThrowsException_CompensationStatusIsSetToExceptionAndTheCompensationExceptionPropertyIsPopulatedWithTheThrownException()
        {
            var expectedExceptionToBeThrownOnExecuteCoreAsyncInvocation = new Exception();

            var exceptionThrowingTestActivityTask = new ExceptionThrowingTestActivityTask(null, expectedExceptionToBeThrownOnExecuteCoreAsyncInvocation);
            await exceptionThrowingTestActivityTask.CompensateCoreAsync(new TestContext());

            exceptionThrowingTestActivityTask.CompensationStatus.ShouldBe(CompensationStatus.Exception);
            exceptionThrowingTestActivityTask.CompensationException.ShouldBe(expectedExceptionToBeThrownOnExecuteCoreAsyncInvocation);
        }

        [Test]
        public void GetSummary_WhenInvoked_MatchesTheDescriptionOfTheActivityTask()
        {
            var expectedDescription = "Test description " + Guid.NewGuid();

            var testActivityTask = new TestActivityTask(expectedDescription);

            ActivityTaskSummary activityTaskSummary = testActivityTask.GetSummary();

            activityTaskSummary.Description.ShouldBeSameAs(expectedDescription);
        }

        [Test]
        public async Task GetSummary_WhenInvoked_MatchesTheStateOfTheInstanceItIsAcquiredFrom()
        {
            var activityTasks = new List<ActivityTask<TestContext>>
                                {
                                    new SuccessfulExecutionTestActivityTask(),
                                    new SuccessfulCompensationTestActivityTask(),
                                    new FailingExecutionTestActivityTask(),
                                    new FailingCompensationTestActivityTask(),
                                    new ExceptionThrowingTestActivityTask(new Exception(), new Exception())
                                };

            var testContext = new TestContext();

            foreach(ActivityTask<TestContext> activityTask in activityTasks)
            {
                await activityTask.ExecuteCoreAsync(testContext);
                await activityTask.CompensateCoreAsync(testContext);
                ActivityTaskSummary activityTaskSummary = activityTask.GetSummary();
                activityTaskSummary.ExecutionStatus.ShouldBe(activityTask.ExecutionStatus);
                activityTaskSummary.ExecutionException.ShouldBe(activityTask.ExecutionException);
                activityTaskSummary.CompensationStatus.ShouldBe(activityTask.CompensationStatus);
                activityTaskSummary.CompensationException.ShouldBe(activityTask.CompensationException);
            }
        }

        private class TestContext
        {
        }

        private class TestActivityTask : ActivityTask<TestContext>
        {
            public TestActivityTask(string description) : base(description)
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestContext context)
            {
                throw new NotImplementedException();
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestContext context)
            {
                throw new NotImplementedException();
            }
        }

        private class SuccessfulExecutionTestActivityTask : ActivityTask<TestContext>
        {
            public SuccessfulExecutionTestActivityTask() : base("SuccessfulExecutionTestActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestContext context)
            {
                throw new NotImplementedException();
            }
        }

        private class SuccessfulCompensationTestActivityTask : ActivityTask<TestContext>
        {
            public SuccessfulCompensationTestActivityTask() : base("SuccessfulCompensationTestActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestContext context)
            {
                throw new NotImplementedException();
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }
        }

        private class FailingExecutionTestActivityTask : ActivityTask<TestContext>
        {
            public FailingExecutionTestActivityTask() : base("FailingExecutionTestActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(false));
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestContext context)
            {
                throw new NotImplementedException();
            }
        }

        private class FailingCompensationTestActivityTask : ActivityTask<TestContext>
        {
            public FailingCompensationTestActivityTask() : base("FailingCompensationTestActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestContext context)
            {
                throw new NotImplementedException();
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(false));
            }
        }

        private class ExceptionThrowingTestActivityTask : ActivityTask<TestContext>
        {
            private readonly Exception _exceptionToBeThrownOnExecution;
            private readonly Exception _exceptionToBeThrownOnCompensation;

            public ExceptionThrowingTestActivityTask(Exception exceptionToBeThrownOnExecution, Exception exceptionToBeThrownOnCompensation) : base("ExceptionThrowingTestActivityTask")
            {
                _exceptionToBeThrownOnExecution = exceptionToBeThrownOnExecution;
                _exceptionToBeThrownOnCompensation = exceptionToBeThrownOnCompensation;
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestContext context)
            {
                throw _exceptionToBeThrownOnExecution;
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestContext context)
            {
                throw _exceptionToBeThrownOnCompensation;
            }
        }
    }
}