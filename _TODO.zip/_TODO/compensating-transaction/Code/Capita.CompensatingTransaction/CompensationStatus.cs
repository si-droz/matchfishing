namespace Capita.CompensatingTransaction
{
    public enum CompensationStatus
    {
        NotAttempted,
        Successful,
        Failed,
        Exception
    }
}