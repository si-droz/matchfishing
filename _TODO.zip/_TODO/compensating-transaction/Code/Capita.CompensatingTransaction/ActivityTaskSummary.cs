using System;

namespace Capita.CompensatingTransaction
{
    public class ActivityTaskSummary
    {
        internal ActivityTaskSummary(string description, ExecutionStatus executionStatus, Exception executionException, CompensationStatus compensationStatus, Exception compensationException, string executionMessage, string compensationMessage)
        {
            Description = description;
            ExecutionStatus = executionStatus;
            ExecutionException = executionException;
            CompensationStatus = compensationStatus;
            CompensationException = compensationException;
            ExecutionMessage = executionMessage;
            CompensationMessage = compensationMessage;
        }

        public string Description { get; }

        /// <summary>
        /// The status of the Execution of the Activity Task
        /// </summary>
        public ExecutionStatus ExecutionStatus { get; }

        /// <summary>
        /// ExecutionException should only be populated if the ExecutionStatus is set to Exception
        /// </summary>
        public Exception ExecutionException { get; }
        
        /// <summary>
        /// The status of the Compensation of the Activity Task
        /// </summary>
        public CompensationStatus CompensationStatus { get; }

        /// <summary>
        /// CompensationException should only be populated if the ExecutionStatus is set to Exception
        /// </summary>
        public Exception CompensationException { get; }

        public string ExecutionMessage { get; }

        public string CompensationMessage { get; }
    }
}