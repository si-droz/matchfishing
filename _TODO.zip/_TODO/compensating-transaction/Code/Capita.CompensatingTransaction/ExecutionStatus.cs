namespace Capita.CompensatingTransaction
{
    public enum ExecutionStatus
    {
        NotAttempted,
        Successful,
        Failed,
        Exception
    }
}