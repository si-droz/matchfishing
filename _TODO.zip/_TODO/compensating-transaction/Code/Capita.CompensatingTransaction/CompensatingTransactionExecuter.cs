﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Capita.CompensatingTransaction
{
    public sealed class CompensatingTransactionExecuter : ICompensatingTransactionExecuter
    {
        public async Task<ActivityOutcome> ExecuteSynchronouslyAsync<T>(IEnumerable<ActivityTask<T>> activityTasks, T context) where T : class
        {
            var executedActivityTasks = new Stack<ActivityTask<T>>();
            foreach(ActivityTask<T> activityTask in activityTasks)
            {
                await activityTask.ExecuteCoreAsync(context);
                executedActivityTasks.Push(activityTask);
                if(activityTask.ExecutionStatus != ExecutionStatus.Successful)
                {
                    var compensatingActivityTasks = new List<Task>();
                    foreach(ActivityTask<T> executedActivityTask in executedActivityTasks)
                    {
                        Task compensatingActivityTask = executedActivityTask.CompensateCoreAsync(context);
                        compensatingActivityTasks.Add(compensatingActivityTask);
                    }

                    await Task.WhenAll(compensatingActivityTasks);
                    break;
                }
            }

            IEnumerable<ActivityTaskSummary> activityTaskSummaries = activityTasks.Select(activityTask => activityTask.GetSummary());

            return new ActivityOutcome(activityTaskSummaries);
        }
    }
}