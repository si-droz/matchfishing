﻿namespace Capita.CompensatingTransaction
{
    public class ActivityTaskOutcome
    {
        public ActivityTaskOutcome(bool completedSuccessfully) : this(completedSuccessfully, string.Empty)
        {
        }

        public ActivityTaskOutcome(bool completedSuccessfully, string message)
        {
            CompletedSuccessfully = completedSuccessfully;
            Message = message;
        }

        public bool CompletedSuccessfully { get; }
        public string Message { get; }
    }
}