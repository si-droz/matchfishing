﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;
using Shouldly;

namespace Capita.CompensatingTransaction.Tests.Integration
{
    [TestFixture]
    public class CompensatingTransactionTests
    {
        private const string TestExecutionMessage = "Test execution message";
        private const string TestCompensationMessage = "Test compensation message";

        [Test]
        public async Task Execute_WhenAllActivitiesCompleteSuccessfully_SuccessOutcomeReturned()
        {
            IEnumerable<ActivityTask<TestActivityContext>> activities = new List<ActivityTask<TestActivityContext>>
                                                                        {
                                                                            new ExecutionSuccessActivityTask(),
                                                                            new ExecutionSuccessActivityTask()
                                                                        };

            var activityExecuter = new CompensatingTransactionExecuter();
            var activityOutcome = await activityExecuter.ExecuteSynchronouslyAsync(activities, new TestActivityContext());

            activityOutcome.CompletedSuccessfully.ShouldBeTrue();
        }

        [Test]
        public async Task Execute_WhenAnActivityFails_FailureOutcomeReturned()
        {
            IEnumerable<ActivityTask<TestActivityContext>> activities = new List<ActivityTask<TestActivityContext>>
                                                                        {
                                                                            new ExecutionSuccessActivityTask(),
                                                                            new ExecutionFailureActivityTask()
                                                                        };

            var activityExecuter = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activityExecuter.ExecuteSynchronouslyAsync(activities, new TestActivityContext());

            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
        }

        [Test]
        public async Task Execute_WhenActivityFails_ItIsPossibleToSeeWhatTaskFailed()
        {
            IEnumerable<ActivityTask<TestActivityContext>> activities = new List<ActivityTask<TestActivityContext>>
                                                                        {
                                                                            new ExecutionSuccessActivityTask(),
                                                                            new ExecutionFailureActivityTask()
                                                                        };

            var activityExecuter = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activityExecuter.ExecuteSynchronouslyAsync(activities, new TestActivityContext());

            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
            ActivityTaskSummary firstActivityTaskSummary = activityOutcome.ActivityTaskSummaries[0];
            firstActivityTaskSummary.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            firstActivityTaskSummary.ExecutionMessage.ShouldBe(string.Empty);
            firstActivityTaskSummary.CompensationStatus.ShouldBe(CompensationStatus.Successful);
            firstActivityTaskSummary.CompensationMessage.ShouldBe(string.Empty);

            ActivityTaskSummary secondActivityTaskSummary = activityOutcome.ActivityTaskSummaries[1];
            secondActivityTaskSummary.ExecutionStatus.ShouldBe(ExecutionStatus.Failed);
            secondActivityTaskSummary.ExecutionMessage.ShouldBe(TestExecutionMessage);
            secondActivityTaskSummary.CompensationStatus.ShouldBe(CompensationStatus.Successful);
            secondActivityTaskSummary.CompensationMessage.ShouldBe(string.Empty);
        }

        [Test]
        public async Task Execute_WhenAnActivityThrowsAnUnhandledException_FailureOutcomeIsReturnedWithTheException()
        {
            IEnumerable<ActivityTask<TestActivityContext>> activities = new List<ActivityTask<TestActivityContext>>
                                                                        {
                                                                            new ExecutionSuccessActivityTask(),
                                                                            new ExecutionExceptionFailureActivityTask()
                                                                        };

            var activity = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activity.ExecuteSynchronouslyAsync(activities, new TestActivityContext());

            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
        }

        [Test]
        public async Task Execute_WhenAnActivityExecutionFails_AllFollowingActivityTasksShouldNotBeExecuted()
        {
            var activityTasksThatShouldBeExecuted = new List<ActivityTask<TestActivityContext>>
                                                    {
                                                        new ExecutionSuccessActivityTask(),
                                                        new ExecutionSuccessActivityTask()
                                                    };

            var activityTaskThatWillFail = new ExecutionFailureActivityTask();

            var activityTasksThatShouldNotBeExecuted = new List<ActivityTask<TestActivityContext>>
                                                       {
                                                           new ExecutionSuccessActivityTask(),
                                                           new ExecutionSuccessActivityTask(),
                                                           new ExecutionSuccessActivityTask()
                                                       };

            var activityTasks = new List<ActivityTask<TestActivityContext>>();
            activityTasks.AddRange(activityTasksThatShouldBeExecuted);
            activityTasks.Add(activityTaskThatWillFail);
            activityTasks.AddRange(activityTasksThatShouldNotBeExecuted);

            var activity = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activity.ExecuteSynchronouslyAsync(activityTasks, new TestActivityContext());

            //THOUGHT: Not too happy with the assertions here. Is there a better way?
            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
            activityTasksThatShouldBeExecuted.ForEach(activityTask => activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Successful));
            activityTaskThatWillFail.ExecutionStatus.ShouldBe(ExecutionStatus.Failed);
            activityTasksThatShouldNotBeExecuted.ForEach(activityTask => activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.NotAttempted));
        }

        [Test]
        public async Task Execute_WhenAnActivityThrowsAnUnhandledException_AllFollowingActivityTasksShouldNotBeExecuted()
        {
            var activityTasksThatShouldBeExecuted = new List<ActivityTask<TestActivityContext>>
                                                    {
                                                        new ExecutionSuccessActivityTask(),
                                                        new ExecutionSuccessActivityTask()
                                                    };

            var activityTaskThatWillFail = new ExecutionExceptionFailureActivityTask();

            var activityTasksThatShouldNotBeExecuted = new List<ActivityTask<TestActivityContext>>
                                                       {
                                                           new ExecutionSuccessActivityTask(),
                                                           new ExecutionSuccessActivityTask(),
                                                           new ExecutionSuccessActivityTask()
                                                       };

            var activityTasks = new List<ActivityTask<TestActivityContext>>();
            activityTasks.AddRange(activityTasksThatShouldBeExecuted);
            activityTasks.Add(activityTaskThatWillFail);
            activityTasks.AddRange(activityTasksThatShouldNotBeExecuted);

            var activity = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activity.ExecuteSynchronouslyAsync(activityTasks, new TestActivityContext());
            
            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
            activityTasksThatShouldBeExecuted.ForEach(activityTask => activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Successful));
            activityTaskThatWillFail.ExecutionStatus.ShouldBe(ExecutionStatus.Exception);
            activityTasksThatShouldNotBeExecuted.ForEach(activityTask => activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.NotAttempted));
        }

        [Test]
        public async Task Execute_WhenAnActivityThrowsAnUnhandledException_AllExecutedActivityTasksAreCompensated()
        {
            var activityTasksExpectedToCompensateSuccessfully = new List<ActivityTask<TestActivityContext>>
                                                                {
                                                                    new ExecutionSuccessActivityTask(),
                                                                    new ExecutionSuccessActivityTask()
                                                                };

            var activityTaskThatWillThrowAnExceptionAndShouldBeCompensated = new ExecutionExceptionFailureActivityTask();

            var activityTasksExpectedToBeNotCompensated = new List<ActivityTask<TestActivityContext>>
                                                          {
                                                              new ExecutionSuccessActivityTask(),
                                                              new ExecutionSuccessActivityTask(),
                                                              new ExecutionSuccessActivityTask()
                                                          };

            var activityTasks = new List<ActivityTask<TestActivityContext>>();
            activityTasks.AddRange(activityTasksExpectedToCompensateSuccessfully);
            activityTasks.Add(activityTaskThatWillThrowAnExceptionAndShouldBeCompensated);
            activityTasks.AddRange(activityTasksExpectedToBeNotCompensated);

            var activity = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activity.ExecuteSynchronouslyAsync(activityTasks, new TestActivityContext());
            
            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
            activityTasksExpectedToCompensateSuccessfully.ForEach(activityTask => activityTask.CompensationStatus.ShouldBe(CompensationStatus.Successful));
            activityTaskThatWillThrowAnExceptionAndShouldBeCompensated.CompensationStatus.ShouldBe(CompensationStatus.Successful);
            activityTasksExpectedToBeNotCompensated.ForEach(activityTask => activityTask.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted));
        }

        [Test]
        public async Task Execute_WhenCompensatingIfCompensationExecutionFails_AllOtherActivityTasksStillCompensate()
        {
            var exceptionOnCompensationActivityTask = new ExecutionSuccessCompensationFailureActivityTask();
            var activityTasksExpectedToCompensateSuccessfully = new List<ActivityTask<TestActivityContext>>
                                                                {
                                                                    new ExecutionSuccessActivityTask(),
                                                                    new ExecutionSuccessActivityTask(),
                                                                    new ExecutionExceptionFailureActivityTask()
                                                                };

            var activityTasks = new List<ActivityTask<TestActivityContext>> {exceptionOnCompensationActivityTask};
            activityTasks.AddRange(activityTasksExpectedToCompensateSuccessfully);

            var activity = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activity.ExecuteSynchronouslyAsync(activityTasks, new TestActivityContext());
            
            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
            exceptionOnCompensationActivityTask.CompensationStatus.ShouldBe(CompensationStatus.Failed);
            exceptionOnCompensationActivityTask.CompensationMessage.ShouldBe(TestCompensationMessage);
            activityTasksExpectedToCompensateSuccessfully.ForEach(activityTask => { activityTask.CompensationStatus.ShouldBe(CompensationStatus.Successful); });
        }

        [Test]
        public async Task Execute_WhenCompensatingIfCompensationExecutionExperiencesAnUnhandledException_AllOtherActivityTasksStillCompensate()
        {
            var exceptionOnCompensationActivityTask = new ExecutionSuccessCompensationExceptionActivityTask();
            var activityTasksExpectedToCompensateSuccessfully = new List<ActivityTask<TestActivityContext>>
                                                                {
                                                                    new ExecutionSuccessActivityTask(),
                                                                    new ExecutionSuccessActivityTask(),
                                                                    new ExecutionExceptionFailureActivityTask()
                                                                };

            var activityTasks = new List<ActivityTask<TestActivityContext>> {exceptionOnCompensationActivityTask};
            activityTasks.AddRange(activityTasksExpectedToCompensateSuccessfully);

            var activity = new CompensatingTransactionExecuter();
            ActivityOutcome activityOutcome = await activity.ExecuteSynchronouslyAsync(activityTasks, new TestActivityContext());

            //THOUGHT: Not too happy with the assertions here. Is there a better way?
            activityOutcome.CompletedSuccessfully.ShouldBeFalse();
            exceptionOnCompensationActivityTask.CompensationStatus.ShouldBe(CompensationStatus.Exception);
            activityTasksExpectedToCompensateSuccessfully.ForEach(activityTask => activityTask.CompensationStatus.ShouldBe(CompensationStatus.Successful));
        }

        private class TestActivityContext
        {
        }

        private class ExecutionSuccessActivityTask : ActivityTask<TestActivityContext>
        {
            public ExecutionSuccessActivityTask() : base("ExecutionSuccessActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestActivityContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestActivityContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }
        }

        private class ExecutionFailureActivityTask : ActivityTask<TestActivityContext>
        {
            public ExecutionFailureActivityTask() : base("ExecutionFailureActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestActivityContext context)
            {
                var outcome = new ActivityTaskOutcome(false, TestExecutionMessage);
                return Task.FromResult(outcome);
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestActivityContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }
        }

        private class ExecutionExceptionFailureActivityTask : ActivityTask<TestActivityContext>
        {
            public ExecutionExceptionFailureActivityTask() : base("ExecutionExceptionFailureActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestActivityContext context)
            {
                throw new InvalidOperationException();
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestActivityContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }
        }

        private class ExecutionSuccessCompensationExceptionActivityTask : ActivityTask<TestActivityContext>
        {
            public ExecutionSuccessCompensationExceptionActivityTask() : base("ExecutionSuccessCompensationExceptionActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestActivityContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestActivityContext context)
            {
                throw new InvalidOperationException();
            }
        }

        private class ExecutionSuccessCompensationFailureActivityTask : ActivityTask<TestActivityContext>
        {
            public ExecutionSuccessCompensationFailureActivityTask() : base("ExecutionSuccessCompensationFailureActivityTask")
            {
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(TestActivityContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(true));
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(TestActivityContext context)
            {
                return Task.FromResult(new ActivityTaskOutcome(false, TestCompensationMessage));
            }
        }
    }
}