﻿using System.Configuration;
using System.Data.Entity;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using AccidentalFish.ApplicationSupport.Core;
using AccidentalFish.ApplicationSupport.Core.Components;
using AccidentalFish.ApplicationSupport.Core.Repository;
using AccidentalFish.ApplicationSupport.Repository.EntityFramework;
using AccidentalFish.ApplicationSupport.Unity;
using Microsoft.Owin.Testing;
using Microsoft.Practices.Unity;
using Newtonsoft.Json;
using NUnit.Framework;
using Owin;
using PM.Audit;
using PM.Onboarding.External.API.DTOs.V1;
using PM.Onboarding.External.API.Storage;
using PM.Onboarding.External.API.Storage.Database;
using PM.Onboarding.External.API.Storage.Entities;
using PM.Onboarding.External.API.Web;
using PM.Onboarding.External.API.Web.DependencyResolution;
using Shouldly;

namespace PM.Onboarding.External.Tests.Integration.Api.V1
{
    [TestFixture]
    public class OnboardingExternalServiceV1IntegrationTests
    {
        private const string ApiUrl = "/V1/Onboarding";

        private const string ContentType = "application/json";

        private const string ConnectionAppConfig = "pm-onboarding-external-api.sql-connection-string";

        private IUnityContainer _unityContainer;

        private string _databaseConnectionString;

        [SetUp]
        public void Setup()
        {
            _unityContainer = new UnityContainer().RegisterStorageDependencies()
                                                  .RegisterOnboardingDependencies();
            var dependencyResolver = new UnityApplicationFrameworkDependencyResolver(_unityContainer);
            dependencyResolver.UseCore().UseEntityFramework();
            _databaseConnectionString = ConfigurationManager.AppSettings[ConnectionAppConfig];
            var onboardingApiDataContext = new OnboardingExternalApiDataContext(_databaseConnectionString);
            new DropCreateDatabaseAlways<OnboardingExternalApiDataContext>().InitializeDatabase(onboardingApiDataContext);
        }

        [Test]
        public async Task Post_WhenInvokedWithEmptyBody_ReturnsStausCodeOfBadRequest()
        {
            using(TestServer server = TestServer.Create<OnboardingServiceIntegrationTestsStartup>())
            using(HttpResponseMessage response = await server.CreateRequest(ApiUrl).PostAsync())
            {
                response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
            }
        }

        [Test]
        public async Task Post_WhenInvokedWithInvalidOnboardingExternalPartner_NullObject()
        {
            PartnerOnboarding partner = null;
            using(TestServer server = TestServer.Create<OnboardingServiceIntegrationTestsStartup>())
            using(HttpResponseMessage response = await server.CreateRequest(ApiUrl)
                                                             .And(message => message.Content = new StringContent(JsonConvert.SerializeObject(partner), Encoding.UTF8, ContentType))
                                                             .PostAsync())
            {
                response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
            }
        }

        [Test]
        public async Task Post_WhenInvokedWithInvalidOnboardingExternalPartner_WithInvalidModel()
        {
            var partner = CreateErrorMockPartnerOnboardingObjectWithErrorInModel();
            using(TestServer server = TestServer.Create<OnboardingServiceIntegrationTestsStartup>())
            using(HttpResponseMessage response = await server.CreateRequest(ApiUrl)
                                                             .And(message => message.Content = new StringContent(JsonConvert.SerializeObject(partner), Encoding.UTF8, ContentType))
                                                             .PostAsync())
            {
                response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
            }
        }

        [Test]
        public async Task Post_WhenInvokedWithInvalidOnboardingExternalPartner_NullCompanyObject()
        {
            var partner = CreateErrorMockPartnerOnboardingObjectWithNullCompany();
            using(TestServer server = TestServer.Create<OnboardingServiceIntegrationTestsStartup>())
            using(HttpResponseMessage response = await server.CreateRequest(ApiUrl)
                                                             .And(message => message.Content = new StringContent(JsonConvert.SerializeObject(partner), Encoding.UTF8, ContentType))
                                                             .PostAsync())
            {
                response.StatusCode.ShouldBe(HttpStatusCode.BadRequest);
            }
        }

        [Test]
        public async Task Post_WhenInvokedWithValidOnboardingExternalPartner_ReturnsStatusCodeOfCreated()
        {
            var partner = CreateMockPartnerOnboardingObject();
            using(TestServer server = TestServer.Create<OnboardingServiceIntegrationTestsStartup>())
            using(HttpResponseMessage response = await server.CreateRequest(ApiUrl)
                                                             .And(message => message.Content = new StringContent(JsonConvert.SerializeObject(partner), Encoding.UTF8, ContentType))
                                                             .PostAsync())
            {
                response.StatusCode.ShouldBe(HttpStatusCode.Created);
            }
        }

        [Test]
        public async Task Post_WhenInvokedWithValidOnboardingExternalPartner_WritesTheCustomerToTheDatabase_ReadValidateValues()
        {
            var partner = CreateMockPartnerOnboardingObject();
            using(TestServer server = TestServer.Create<OnboardingServiceIntegrationTestsStartup>())
            using(HttpResponseMessage response = await server.CreateRequest(ApiUrl)
                                                             .And(message => message.Content = new StringContent(JsonConvert.SerializeObject(partner), Encoding.UTF8, ContentType))
                                                             .PostAsync())
            {
                response.StatusCode.ShouldBe(HttpStatusCode.Created);
                IApplicationResourceFactory applicationResourceFactory = _unityContainer.Resolve<IApplicationResourceFactory>();

                IUnitOfWorkFactory unitOfWorkFactory = applicationResourceFactory.GetUnitOfWorkFactory(ComponentIdentities.PmOnboardingApi);
                using(IUnitOfWorkAsync unitOfWorkAsync = unitOfWorkFactory.CreateAsync())
                {
                    IRepositoryAsync<StorageCompany> companyRepository = unitOfWorkAsync.GetRepository<StorageCompany>();
                    (await companyRepository.All.CountAsync()).ShouldBe(1);

                    var writtenOnboardingPartner = await companyRepository.All.SingleAsync();
                    writtenOnboardingPartner.CompanyName.ShouldBe(partner.Company.Name);
                    writtenOnboardingPartner.Url.ShouldBe(partner.Company.Website);
                    writtenOnboardingPartner.AddressLine1.ShouldBe(partner.Company.Address.Line1);
                    writtenOnboardingPartner.AddressLine2.ShouldBe(partner.Company.Address.Line2);
                    writtenOnboardingPartner.AddressLine3.ShouldBe(partner.Company.Address.Line3);
                    writtenOnboardingPartner.County.ShouldBe(partner.Company.Address.County);
                    writtenOnboardingPartner.CityTown.ShouldBe(partner.Company.Address.CityTown);
                    writtenOnboardingPartner.Country.ShouldBe(partner.Company.Address.Country);
                    writtenOnboardingPartner.PostCode.ShouldBe(partner.Company.Address.PostCode);
                    writtenOnboardingPartner.CompanySummary.ShouldBe(partner.Company.Summary);
                    writtenOnboardingPartner.SimsPrimary.ShouldBe(partner.Company.SimsPrimary);
                    writtenOnboardingPartner.SimsId.ShouldBe(partner.Company.SimsId);
                    writtenOnboardingPartner.TermsAndConditionsRead.ShouldBe(partner.Company.TermsAndConditionsRead);
                    writtenOnboardingPartner.Contact.Title.ShouldBe(partner.Contact.Title);
                    writtenOnboardingPartner.Contact.FirstName.ShouldBe(partner.Contact.FirstName);
                    writtenOnboardingPartner.Contact.LastName.ShouldBe(partner.Contact.LastName);
                    writtenOnboardingPartner.Contact.WorkEmail.ShouldBe(partner.Contact.WorkEmail);
                    writtenOnboardingPartner.Contact.WorkTelephone.ShouldBe(partner.Contact.WorkPhone);
                }
            }
        }

        [TearDown]
        public void Teardown()
        {
            Database.Delete(_databaseConnectionString);
        }

        private class OnboardingServiceIntegrationTestsStartup
        {
            public void Configuration(IAppBuilder app)
            {
                var httpConfiguration = new HttpConfiguration();
                httpConfiguration.MessageHandlers.Add(new AuditingMessageHandler());
                httpConfiguration.MapHttpAttributeRoutes();
                httpConfiguration.Formatters.Clear();
                httpConfiguration.Formatters.Add(new JsonMediaTypeFormatter());

                var unityContainer = new UnityContainer().RegisterOnboardingDependencies().RegisterStorageDependencies();
                var dependencyResolver = new UnityApplicationFrameworkDependencyResolver(unityContainer);
                dependencyResolver.UseCore().UseEntityFramework();
                httpConfiguration.DependencyResolver = new UnityDependencyResolver(unityContainer);

                app.UseWebApi(httpConfiguration);
            }
        }

        private PartnerOnboarding CreateMockPartnerOnboardingObject()
        {
            return new PartnerOnboarding
                   {
                       Company = new Company
                                 {
                                     Name = "Test Company Ltd",
                                     Website = "http://www.test.com",
                                     Summary = "This is a test company summary about this test company.",
                                     SimsPrimary = true,
                                     SimsId = true,
                                     TermsAndConditionsRead = true,
                                     Address = new Address
                                               {
                                                   Line1 = "1 The Road",
                                                   Line2 = "Test Place",
                                                   CityTown = "Test City",
                                                   County = "Test County",
                                                   Country = "England",
                                                   PostCode = "WC1 1AB"
                                               }
                                 },
                       Contact = new Contact
                                 {
                                     FirstName = "Joe",
                                     LastName = "Bloggs",
                                     Title = "Mr",
                                     WorkEmail = "joe.bloggs@test.com",
                                     WorkPhone = "01234 456 789"
                                 }
                   };
        }

        private PartnerOnboarding CreateErrorMockPartnerOnboardingObjectWithNullCompany()
        {
            return new PartnerOnboarding
                   {
                       Company = null,
                       Contact = new Contact
                                 {
                                     FirstName = "Joe",
                                     LastName = "Bloggs",
                                     Title = "Mr",
                                     WorkEmail = "joe.bloggs@test.com",
                                     WorkPhone = "01234 456 789"
                                 }
                   };
        }

        private PartnerOnboarding CreateErrorMockPartnerOnboardingObjectWithErrorInModel()
        {
            return new PartnerOnboarding
                   {
                       Company = new Company
                                 {
                                     Name = "Test Company Ltd",
                                     Website = "http://www.test.com",
                                     Summary = "This is a test company summary about this test company.",
                                     SimsPrimary = true,
                                     SimsId = true,
                                     TermsAndConditionsRead = true,
                                     Address = new Address
                                               {
                                                   Line1 = "1 The Road",
                                                   Line2 = "Test Place",
                                                   CityTown = "Test City",
                                                   County = "Test County",
                                                   Country = "England",
                                                   PostCode = "WC1 1ABxxxxxxxxxxxxxxxx"
                                               }
                                 },
                       Contact = new Contact
                                 {
                                     FirstName = "Joe",
                                     LastName = "Bloggs",
                                     Title = "Mrrrrrrrrrrrrrrrrrrrrs",
                                     WorkEmail = "joe.bloggs@test.com",
                                     WorkPhone = "01234 456 789"
                                 }
                   };
        }
    }
}