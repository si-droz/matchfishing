﻿using System.ComponentModel.DataAnnotations;

namespace PM.Onboarding.External.API.DTOs.V1
{
    public class Contact
    {
        [Required(ErrorMessage = "You must provide a title."), MinLength(1, ErrorMessage = "Title must be a minimum of 1 character."), MaxLength(20, ErrorMessage = "Title must be a maximum of 20 character.")]
        [DataType(DataType.Text)]
        public string Title { get; set; }

        [Required(ErrorMessage = "You must provide a first name."), MinLength(1, ErrorMessage = "First name must be a minimum of 1 character."), MaxLength(100, ErrorMessage = "First name must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "You must provide a last name."), MinLength(1, ErrorMessage = "Last name must be a minimum of 1 character."), MaxLength(100, ErrorMessage = "Last name must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string LastName { get; set; }

        [Required(ErrorMessage = "You must provide a email address."), MinLength(1, ErrorMessage = "Email address must be a minimum of 1 character."), MaxLength(100, ErrorMessage = "Email address must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string WorkEmail { get; set; }

        [Required(ErrorMessage = "You must provide a work telephone."), MinLength(1, ErrorMessage = "Work telephone must be a minimum of 1 character."), MaxLength(100, ErrorMessage = "Work telephone must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string WorkPhone { get; set; }
    }
}