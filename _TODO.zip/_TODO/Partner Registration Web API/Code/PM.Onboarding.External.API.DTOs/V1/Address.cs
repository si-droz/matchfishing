﻿using System.ComponentModel.DataAnnotations;

namespace PM.Onboarding.External.API.DTOs.V1
{
    public class Address
    {
        [Required(ErrorMessage = "You must provide a company address line 1."), MinLength(1, ErrorMessage = "Company address line 1 must be a minimum of 1 character."), MaxLength(100, ErrorMessage = "Company address line 1 must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string Line1 { get; set; }

        [MaxLength(100, ErrorMessage = "Company address line 2 must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string Line2 { get; set; }

        [MaxLength(100)]
        [DataType(DataType.Text)]
        public string Line3 { get; set; }

        [Required(ErrorMessage = "You must provide a city."), MinLength(1, ErrorMessage = "County must be a minimum of 1 character."), MaxLength(100, ErrorMessage = "County must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string CityTown { get; set; }

        [MaxLength(100, ErrorMessage = "County must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string County { get; set; }

        [Required(ErrorMessage = "You must provide a country."), MinLength(1, ErrorMessage = "Country must be a minimum of 1 character."), MaxLength(100, ErrorMessage = "Country must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string Country { get; set; }

        [MaxLength(10)]
        [DataType(DataType.Text)]
        public string PostCode { get; set; }
    }
}
