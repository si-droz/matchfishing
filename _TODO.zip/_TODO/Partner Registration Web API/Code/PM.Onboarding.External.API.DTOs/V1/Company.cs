﻿using System.ComponentModel.DataAnnotations;

namespace PM.Onboarding.External.API.DTOs.V1
{
    public class Company
    {
        [Required(ErrorMessage = "You must provide a company name.")]
        [MinLength(1, ErrorMessage = "Company name must be a minimum of 1 character.")]
        [MaxLength(100, ErrorMessage = "Company name must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string Name { get; set; }

        [MaxLength(100, ErrorMessage = "Company URL must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string Website { get; set; }

        [Required]
        public Address Address { get; set; }

        [Required(ErrorMessage = "You must provide a company summary.")]
        [MinLength(1, ErrorMessage = "Company summary must be a minimum of 1 character.")]
        [MaxLength(1000, ErrorMessage = "Company summary must be a maximum of 1000 character.")]
        [DataType(DataType.Text)]
        public string Summary { get; set; }

        public bool SimsPrimary { get; set; }

        public bool SimsId { get; set; }

        public bool TermsAndConditionsRead { get; set; }
    }
}