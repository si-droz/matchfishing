﻿using System.ComponentModel.DataAnnotations;

namespace PM.Onboarding.External.API.DTOs.V1
{
    public class PartnerOnboarding
    {
        [Required(AllowEmptyStrings = false, ErrorMessage = "Company data cannot be null.")]
        public Company Company { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "Contact data cannot be null.")]
        public Contact Contact { get; set; }
    }
}