﻿namespace PM.Onboarding.External.API.DTOs.V1.Administration
{
    public class PartnerOnboarding
    {
        public PartnerCompany Company { get; set; }

        public PartnerContact Contact { get; set; }
    }
}