﻿namespace PM.Onboarding.External.API.DTOs.V1.Administration
{
    public class PartnerRegistration
    {
        public string CompanyName { get; set; }

        public string RequestedBy { get; set; }

        public int CompanyId { get; set; }
    }
}