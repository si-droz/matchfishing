﻿namespace PM.Onboarding.External.API.DTOs.V1.Administration
{
    public class PartnerCompany
    {
        public string Name { get; set; }

        public string Website { get; set; }

        public string Summary { get; set; }

        public int CompanyId { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string AddressLine3 { get; set; }

        public string CityTown { get; set; }

        public string County { get; set; }

        public string Country { get; set; }

        public string PostCode { get; set; }

        public bool SimsId { get; set; }

        public bool SimsPrimary { get; set; }

        public bool TermsAndConditionsRead { get; set; }
    }
}