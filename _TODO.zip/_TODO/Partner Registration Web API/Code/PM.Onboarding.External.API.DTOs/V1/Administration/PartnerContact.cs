﻿namespace PM.Onboarding.External.API.DTOs.V1.Administration
{
    public class PartnerContact
    {
        public string Title { get; set; }
        
        public string FirstName { get; set; }
        
        public string LastName { get; set; }

        public string WorkEmail { get; set; }

        public string WorkPhone { get; set; }

        public int ContactId { get; set; }
    }
}