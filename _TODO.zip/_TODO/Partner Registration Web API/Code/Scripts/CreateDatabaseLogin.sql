IF NOT EXISTS (SELECT * FROM sys.sql_logins WHERE name=N'$(varDatabaseLoginId)')
	BEGIN
		CREATE LOGIN [$(varDatabaseLoginId)] WITH PASSWORD=N'$(varDatabaseLoginPassword)';
		CREATE USER [$(varDatabaseLoginId)] FOR LOGIN [$(varDatabaseLoginId)] WITH DEFAULT_SCHEMA=[varDatabaseName];
	END
	
ELSE
	BEGIN
		ALTER LOGIN [$(varDatabaseLoginId)] WITH PASSWORD=N'$(varDatabaseLoginPassword)';
	END
GO


