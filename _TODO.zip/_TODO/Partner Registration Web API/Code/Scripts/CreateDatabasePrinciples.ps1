﻿
param(
    [Parameter(Mandatory=$true)][string]$databaseServer,
    [Parameter(Mandatory=$true)][string]$databaseName,
    [Parameter(Mandatory=$true)][string]$subscriptionName,
    [Parameter(Mandatory=$true)][string]$vaultName,
    [Parameter(Mandatory=$true)][string]$databaseLoginId,
    [Parameter(Mandatory=$true)][string]$databaseAdminId,
    [Parameter(Mandatory=$true)][string]$databaseLoginPasswordKey,
    [Parameter(Mandatory=$true)][string]$databaseAdminPasswordKey,
    [Parameter(Mandatory=$true)][string]$databaseLoginRole
)

# Input Parameters
Write-Host 'Following parameters used:'
Write-Host 'databaseServer: ' $databaseServer
Write-Host 'databaseName: ' $databaseName
Write-Host 'subscriptionName: ' $subscriptionName
Write-Host 'vaultName: ' $vaultName
Write-Host 'databaseLoginId: ' $databaseLoginId
Write-Host 'databaseAdminId: ' $databaseAdminId
Write-Host 'databaseLoginPasswordKey: ' $databaseLoginPasswordKey
Write-Host 'databaseAdminPasswordKey: ' $databaseAdminPasswordKey
Write-Host 'databaseLoginRole: ' $databaseLoginRole
 
<# Connect to Azure used for running locally.
Write-Host 'Connecting to Azure.'
Login-AzureRmAccount
# Switch to subscription
Write-Host 'Getting Azure Subsciption.'
Get-AzureSubscription -SubscriptionName $subscriptionName
#>

# Get Passwords from Vault
Write-Host 'Getting admin password from azure vault ' $vaultName '.'
$adminPassword = Get-AzureKeyVaultSecret -VaultName $vaultName -Name $databaseAdminPasswordKey
Write-Host 'Getting user password from azure vault ' $vaultName '.';
$dbLoginPassword = Get-AzureKeyVaultSecret -VaultName $vaultName -Name $databaseLoginPasswordKey

# Define variables needed for sqlcmd
[string]$scriptDir = Split-Path -Path $script:MyInvocation.MyCommand.Path
[string]$createLoginDatabaseServerScript = $scriptDir + "\CreateDatabaseLogin.sql"
[string]$createLoginAssocDatabaseScript = $scriptDir + "\CreateDatabaseUser.sql"
[string]$databaseLoginPwd = $dbLoginPassword.SecretValueText

# Execute sqlcmd for create database user
Write-Host 'Connecting to master database.'
sqlcmd -S $databaseServer -d master -U $databaseAdminId -P $adminPassword.SecretValueText -I -v varDatabaseLoginId=$databaseLoginId varDatabaseLoginPassword=$databaseLoginPwd varDatabaseName=$databaseName -i $createLoginDatabaseServerScript
Write-Host 'Created user in SQL database server.'

# Execute sqlcmd for associating user to database
Write-Host 'Connecting to ' $databaseName ' database.'
sqlcmd -S $databaseServer -d $databaseName -U $databaseAdminId -P $adminPassword.SecretValueText -I -v varDatabaseLoginId=$databaseLoginId varDatabaseName=$databaseName varDatabaseLoginRole=$databaseLoginRole -i $createLoginAssocDatabaseScript
Write-Host 'Linked user: ' $databaseLoginId ' to SQL database ' $databaseName '.'

#Script complete
Write-Host 'Script complete.'
