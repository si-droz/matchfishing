IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name=N'$(varDatabaseLoginId)')
	BEGIN
		CREATE USER [$(varDatabaseLoginId)] FOR LOGIN [$(varDatabaseLoginId)] WITH DEFAULT_SCHEMA=[$(varDatabaseName)];
	END

	ALTER ROLE [$(varDatabaseLoginRole)] ADD MEMBER [$(varDatabaseLoginId)];
	ALTER ROLE [db_datareader] ADD MEMBER [$(varDatabaseLoginId)];
	GRANT CONNECT TO [$(varDatabaseLoginId)];
GO
