Enable-Migrations
Add-Migration -ConnectionString 'Server=.;Database=pm-onboarding-api-local-dev;Connection Timeout=30;Integrated Security=True' -ConnectionProviderName 'System.Data.SqlClient' -Name 'V1'
Update-Database -ConnectionString 'Server=.;Database=pm-onboarding-api-local-dev;Connection Timeout=30;Integrated Security=True' -ConnectionProviderName 'System.Data.SqlClient' -Verbose