namespace PM.Onboarding.External.API.Storage.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class V1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Company",
                c => new
                    {
                        CompanyId = c.Int(nullable: false, identity: true),
                        CompanyName = c.String(nullable: false, maxLength: 100),
                        Url = c.String(nullable: false, maxLength: 100),
                        AddressLine1 = c.String(nullable: false, maxLength: 100),
                        AddressLine2 = c.String(nullable: false, maxLength: 100),
                        AddressLine3 = c.String(maxLength: 100),
                        CityTown = c.String(nullable: false, maxLength: 100),
                        County = c.String(maxLength: 100),
                        Country = c.String(nullable: false, maxLength: 100),
                        PostCode = c.String(maxLength: 10),
                        CompanySummary = c.String(nullable: false, maxLength: 1000),
                        ContactId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.CompanyId)
                .ForeignKey("dbo.Contact", t => t.ContactId, cascadeDelete: true)
                .Index(t => t.ContactId);
            
            CreateTable(
                "dbo.Contact",
                c => new
                    {
                        ContactId = c.Int(nullable: false, identity: true),
                        Title = c.String(nullable: false, maxLength: 20),
                        FirstName = c.String(nullable: false, maxLength: 100),
                        LastName = c.String(nullable: false, maxLength: 100),
                        WorkEmail = c.String(nullable: false, maxLength: 100),
                        WorkTelephone = c.String(nullable: false, maxLength: 100),
                    })
                .PrimaryKey(t => t.ContactId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Company", "ContactId", "dbo.Contact");
            DropIndex("dbo.Company", new[] { "ContactId" });
            DropTable("dbo.Contact");
            DropTable("dbo.Company");
        }
    }
}
