using System.Data.Entity.Migrations;

namespace PM.Onboarding.External.API.Storage.Migrations
{
    public partial class V15 : DbMigration
    {
        public override void Up()
        {
            const bool isNullable = false;
            const bool defaultValue = false;
            AddColumn("dbo.Company", "SimsPrimary", c => c.Boolean(isNullable, defaultValue));
            AddColumn("dbo.Company", "SimsId", c => c.Boolean(isNullable, defaultValue));
        }

        public override void Down()
        {
            DropColumn("dbo.Company", "SimsId");
            DropColumn("dbo.Company", "SimsPrimary");
        }
    }
}