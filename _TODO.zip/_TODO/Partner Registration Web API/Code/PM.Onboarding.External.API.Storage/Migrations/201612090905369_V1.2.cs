namespace PM.Onboarding.External.API.Storage.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class V12 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Company", "Url", c => c.String(maxLength: 100));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Company", "Url", c => c.String(nullable: false, maxLength: 100));
        }
    }
}
