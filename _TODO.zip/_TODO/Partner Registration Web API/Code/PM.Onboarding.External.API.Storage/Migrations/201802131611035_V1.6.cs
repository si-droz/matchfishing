using System.Data.Entity.Migrations;

namespace PM.Onboarding.External.API.Storage.Migrations
{
    public partial class V16 : DbMigration
    {
        public override void Up()
        {
            const bool isNullable = false;
            const bool defaultValue = false;
            AddColumn("dbo.Company", "TermsAndConditionsRead", c => c.Boolean(isNullable, defaultValue));
        }

        public override void Down()
        {
            DropColumn("dbo.Company", "TermsAndConditionsRead");
        }
    }
}