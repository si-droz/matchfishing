﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PM.Onboarding.External.API.Storage.Entities
{
    [Table("Company")]
    public class StorageCompany
    {
        [Key]
        public int CompanyId { get; set; }

        [Required(ErrorMessage = "You must provide a company name.")]
        [MinLength(1, ErrorMessage = "Company name must be a minimum of 1 character.")]
        [MaxLength(100, ErrorMessage = "Company name must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string CompanyName { get; set; }

        [MaxLength(100, ErrorMessage = "Company URL must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string Url { get; set; }

        [Required(ErrorMessage = "You must provide a company address line 1.")]
        [MinLength(1, ErrorMessage = "Company address line 1 must be a minimum of 1 character.")]
        [MaxLength(100, ErrorMessage = "Company address line 1 must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string AddressLine1 { get; set; }

        [MaxLength(100, ErrorMessage = "Company address line 2 must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string AddressLine2 { get; set; }

        [MaxLength(100)]
        [DataType(DataType.Text)]
        public string AddressLine3 { get; set; }

        [Required(ErrorMessage = "You must provide a city.")]
        [MinLength(1, ErrorMessage = "County must be a minimum of 1 character.")]
        [MaxLength(100, ErrorMessage = "County must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string CityTown { get; set; }

        [MaxLength(100, ErrorMessage = "County must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string County { get; set; }

        [Required(ErrorMessage = "You must provide a country.")]
        [MinLength(1, ErrorMessage = "Country must be a minimum of 1 character.")]
        [MaxLength(100, ErrorMessage = "Country must be a maximum of 100 character.")]
        [DataType(DataType.Text)]
        public string Country { get; set; }

        [MaxLength(10)]
        [DataType(DataType.Text)]
        public string PostCode { get; set; }

        [Required(ErrorMessage = "You must provide a company summary.")]
        [MinLength(1, ErrorMessage = "Company summary must be a minimum of 1 character.")]
        [MaxLength(1000, ErrorMessage = "Company summary must be a maximum of 1000 character.")]
        [DataType(DataType.Text)]
        public string CompanySummary { get; set; }

        public bool SimsPrimary { get; set; }

        public bool SimsId { get; set; }

        public bool TermsAndConditionsRead { get; set; }

        [ForeignKey("ContactId")]
        [Required]
        public virtual StorageContact Contact { get; set; }

        public int ContactId { get; set; }

        [Required(ErrorMessage = "You must provide a created date & time.")]
        public DateTime CreateDate { get; set; }
    }
}