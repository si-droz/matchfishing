﻿using Microsoft.Practices.Unity;
using PM.Onboarding.External.API.Storage.Database;

namespace PM.Onboarding.External.API.Storage
{
    public static class StorageBootstrapper
    {
        public static IUnityContainer RegisterStorageDependencies(this IUnityContainer unityContainer)
        {
            return unityContainer.RegisterType<OnboardingExternalApiDataContext>();
        }
    }
}
