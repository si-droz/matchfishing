﻿using System.Data.Entity;
using PM.Onboarding.External.API.Storage.Entities;


namespace PM.Onboarding.External.API.Storage.Database
{
    internal class OnboardingExternalApiDataContext : DbContext
    {
        public OnboardingExternalApiDataContext()
        {
            
        }
        public OnboardingExternalApiDataContext(string connectionString) : base(connectionString)
        {           
        }

        public DbSet<StorageCompany> Company { get; set; }
        
        public DbSet<StorageContact> Contact { get; set; } 
    }
}
