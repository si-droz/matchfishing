﻿using System.Collections.Generic;
using System.Configuration;
using System.Net.Http.Formatting;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using AccidentalFish.ApplicationSupport.Core;
using AccidentalFish.ApplicationSupport.Repository.EntityFramework;
using AccidentalFish.ApplicationSupport.Unity;
using IdentityServer3.AccessTokenValidation;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Owin.Cors;
using Microsoft.Practices.Unity;
using Owin;
using PM.Audit;
using PM.Onboarding.External.API.Storage;
using PM.Onboarding.External.API.Web.DependencyResolution;
using PM.Onboarding.External.API.Web.Helper;
using PM.Security.Extensions;
using Serilog;

namespace PM.Onboarding.External.API.Web
{
    public class Startup
    {
        private readonly string _identityProviderAuthority = ConfigurationManager.AppSettings["IdentityProvider:Authority"];

        public void Configuration(IAppBuilder app)
        {
            TelemetryConfiguration.Active.InstrumentationKey =
                WebConfigurationManager.AppSettings["ApplicationInsights:InstrumentationKey"];

            Log.Logger = new LoggerConfiguration().ReadFrom.AppSettings()
                                                  .WriteTo.Trace()
                                                  .CreateLogger();

            OnboardingConfiguration(app);

            app.Map("/administration", AdministrationConfiguration);
        }

        private void OnboardingConfiguration(IAppBuilder app)
        {
            var container = new UnityContainer()
                .RegisterOnboardingDependencies()
                .RegisterStorageDependencies();

            HttpConfiguration httpConfiguration = GetHttpConfiguration(container);

#if DEBUG
            app.UseCors(CorsOptions.AllowAll);
#endif

            app.UseAllowHttpsOnly().UseWebApi(httpConfiguration);
        }

        private void AdministrationConfiguration(IAppBuilder app)
        {
            var container = new UnityContainer()
                .RegisterAdministrationDependencies()
                .RegisterStorageDependencies();

            HttpConfiguration httpConfiguration = GetHttpConfiguration(container);

            app.UseIdentityServerBearerTokenAuthentication(new IdentityServerBearerTokenAuthenticationOptions
                                                           {
                                                               Authority = _identityProviderAuthority,
                                                               RequiredScopes = new List<string> {"partner-access-onboarding-api"}
                                                           });

            app.UseAllowHttpsOnly().UseWebApi(httpConfiguration);
        }

        private HttpConfiguration GetHttpConfiguration(IUnityContainer container)
        {
            var httpConfiguration = new HttpConfiguration();
            httpConfiguration.MessageHandlers.Add(new AuditingMessageHandler());

            httpConfiguration.Services.Add(typeof(IExceptionLogger), new AiExceptionLogger());
            httpConfiguration.MapHttpAttributeRoutes();
            httpConfiguration.Formatters.Clear();
            httpConfiguration.Formatters.Add(new JsonMediaTypeFormatter());

            var dependencyResolver = new UnityApplicationFrameworkDependencyResolver(container);
            dependencyResolver.UseCore().UseEntityFramework();
            httpConfiguration.DependencyResolver = new UnityDependencyResolver(container);

            return httpConfiguration;
        }
    }
}