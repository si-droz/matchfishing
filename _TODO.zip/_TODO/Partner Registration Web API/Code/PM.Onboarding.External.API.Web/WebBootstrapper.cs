﻿using Microsoft.Practices.Unity;
using PM.Onboarding.External.API.Web.Api.V1;

namespace PM.Onboarding.External.API.Web
{
    public static class WebBootstrapper
    {
        public static IUnityContainer RegisterOnboardingDependencies(this IUnityContainer unityContainer)
        {
            return unityContainer.RegisterType<OnboardingV1Controller>();
        }

        public static IUnityContainer RegisterAdministrationDependencies(this IUnityContainer unityContainer)
        {
            return unityContainer.RegisterType<PartnerRegistrationV1Controller>();
        }
    }
}