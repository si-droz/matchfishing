﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using Newtonsoft.Json;

namespace PM.Onboarding.External.API.Web.Filters
{
    [AttributeUsage(AttributeTargets.Method)]
    public class ReCaptchaCheckAttribute : ActionFilterAttribute
    {
        private bool _integrationTestMode = false;
        private const string gCaptchaResponseParameter = "g-captcha-response";

        public bool IntegrationTestMode
        {
            get
            {
                CheckIntegrationMode();
                return _integrationTestMode;
            }
        }
        
        public override void OnActionExecuting(HttpActionContext filterContext)
        {
            if (!IntegrationTestMode)
            {
                string secret = ConfigurationManager.AppSettings["pm-onboarding-external-api-recaptcha-secret"];
                string gCaptchaResponse = filterContext.Request.Headers.GetValues(gCaptchaResponseParameter).FirstOrDefault();

                if (string.IsNullOrEmpty(gCaptchaResponse))
                {
                    filterContext.Response = filterContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, new ArgumentNullException(gCaptchaResponseParameter));
                    return;
                }

                using (var client = new WebClient())
                {
                    string response = client.DownloadString($"https://www.google.com/recaptcha/api/siteverify?secret={secret}&response={gCaptchaResponse}");

                    var captchaResponse = JsonConvert.DeserializeObject<CaptchaResponse>(response);
                    if (!captchaResponse.IsSuccess)
                    {
                        filterContext.Response = filterContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest, new CaptchaResponseException(string.Join(" ", captchaResponse.ErrorCodes)));
                    }
                }
            }
        }

        [Conditional("Test")]
        private void CheckIntegrationMode()
        {
          _integrationTestMode = true;
        }
        
        public class CaptchaResponse
        {
            [JsonProperty("success")]
            public bool IsSuccess { get; set; }

            [JsonProperty("error-codes")]
            public string[] ErrorCodes { get; set; }
        }
        
        public class CaptchaResponseException : Exception
        {
            public CaptchaResponseException(string errorCode) : base(errorCode) { }
        }
    }
}