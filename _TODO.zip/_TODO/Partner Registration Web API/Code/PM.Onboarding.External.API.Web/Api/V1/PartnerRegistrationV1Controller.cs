﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using AccidentalFish.ApplicationSupport.Core.Components;
using AccidentalFish.ApplicationSupport.Core.Repository;
using PM.Onboarding.External.API.DTOs.V1.Administration;
using PM.Onboarding.External.API.Storage.Entities;
using PM.Onboarding.External.API.Web.Extensions;

namespace PM.Onboarding.External.API.Web.Api.V1
{
    [Authorize]
    public class PartnerRegistrationV1Controller : ApiController
    {
        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        public PartnerRegistrationV1Controller(IApplicationResourceFactory applicationResourceFactory)
        {
            _unitOfWorkFactory = applicationResourceFactory.GetUnitOfWorkFactory(ComponentIdentities.PmOnboardingApi);
        }

        [HttpGet]
        [Route("api/v1/partnerRegistrations")]
        public async Task<IHttpActionResult> GetAll()
        {
            using(IUnitOfWorkAsync unitOfWorkAsync = _unitOfWorkFactory.CreateAsync())
            {
                IRepositoryAsync<StorageCompany> companyRepository = unitOfWorkAsync.GetRepository<StorageCompany>();
                IEnumerable<StorageCompany> companies = await companyRepository.AllIncluding(company => company.Contact).ToListAsync();
                IEnumerable<PartnerRegistration> partnerRegistrations = companies.Select(new PartnerRegistration().Map);

                return Ok(partnerRegistrations);
            }
        }

        [HttpGet]
        [Route("api/v1/partnerRegistration/{id}")]
        public async Task<IHttpActionResult> Get(int id)
        {
            using(IUnitOfWorkAsync unitOfWorkAsync = _unitOfWorkFactory.CreateAsync())
            {
                IRepositoryAsync<StorageCompany> companyRepository = unitOfWorkAsync.GetRepository<StorageCompany>();
                StorageCompany company = await companyRepository.FindAsync(id);
                PartnerOnboarding partnerRegistration = new PartnerOnboarding().Map(company);

                return Ok(partnerRegistration);
            }
        }
    }
}