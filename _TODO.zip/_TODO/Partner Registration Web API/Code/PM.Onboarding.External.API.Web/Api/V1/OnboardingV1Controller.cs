﻿using System.Threading.Tasks;
using System.Web.Http;
using AccidentalFish.ApplicationSupport.Core.Components;
using AccidentalFish.ApplicationSupport.Core.Repository;
using PM.Onboarding.External.API.DTOs.V1;
using PM.Onboarding.External.API.Storage.Entities;
using PM.Onboarding.External.API.Web.Extensions;
using PM.Onboarding.External.API.Web.Filters;

namespace PM.Onboarding.External.API.Web.Api.V1
{
    public class OnboardingV1Controller : ApiController
    {
        public OnboardingV1Controller(IApplicationResourceFactory applicationResourceFactory)
        {
            _unitOfWorkFactory = applicationResourceFactory.GetUnitOfWorkFactory(ComponentIdentities.PmOnboardingApi);
        }

        private readonly IUnitOfWorkFactory _unitOfWorkFactory;

        // GET api/<controller>/Post/
        [HttpPost]
        [Route("V1/Onboarding")]
        [ValidationResponseFilter]
        [CheckModelForNull]
        [ReCaptchaCheck]
        public async Task<IHttpActionResult> Post(PartnerOnboarding data)
        {
            if(data == null) return BadRequest("You must provide a partner.");

            if(ModelState.IsValid)
            {
                using(IUnitOfWorkAsync unitOfWorkAsync = _unitOfWorkFactory.CreateAsync())
                {
                    IRepositoryAsync<StorageCompany> companyRepository = unitOfWorkAsync.GetRepository<StorageCompany>();
                    companyRepository.Insert(new StorageCompany().Map(data));
                    await unitOfWorkAsync.SaveAsync();
                }
                return Created(string.Empty, data);
            }

            return BadRequest();
        }
    }
}