﻿using AccidentalFish.ApplicationSupport.Core.Components;

namespace PM.Onboarding.External.API.Web
{
    public class ComponentIdentities
    {
        public const string PmOnboardingApiFqn = "pm-onboarding-external-api";

        public static readonly IComponentIdentity PmOnboardingApi = new ComponentIdentity(PmOnboardingApiFqn);
    }
}