﻿using PM.Onboarding.External.API.DTOs.V1.Administration;
using PM.Onboarding.External.API.Storage.Entities;

namespace PM.Onboarding.External.API.Web.Extensions
{
    internal static class PartnerOnboardingAdministrationExtension
    {
        public static PartnerOnboarding Map(this PartnerOnboarding partnerOnboarding, StorageCompany company)
        {
            partnerOnboarding.Company = Map(company);
            partnerOnboarding.Contact = Map(company.Contact);

            return partnerOnboarding;
        }

        private static PartnerCompany Map(StorageCompany company)
        {
            return new PartnerCompany
                   {
                       CompanyId = company.CompanyId,
                       CityTown = company.CityTown,
                       Country = company.Country,
                       County = company.County,
                       AddressLine1 = company.AddressLine1,
                       AddressLine2 = company.AddressLine2,
                       AddressLine3 = company.AddressLine3,
                       PostCode = company.PostCode,
                       Name = company.CompanyName,
                       Summary = company.CompanySummary,
                       Website = company.Url,
                       SimsId = company.SimsId,
                       SimsPrimary = company.SimsPrimary,
                       TermsAndConditionsRead = company.TermsAndConditionsRead
                   };
        }

        private static PartnerContact Map(StorageContact contact)
        {
            return new PartnerContact
                   {
                       ContactId = contact.ContactId,
                       FirstName = contact.FirstName,
                       LastName = contact.LastName,
                       Title = contact.Title,
                       WorkEmail = contact.WorkEmail,
                       WorkPhone = contact.WorkTelephone
                   };
        }
    }
}