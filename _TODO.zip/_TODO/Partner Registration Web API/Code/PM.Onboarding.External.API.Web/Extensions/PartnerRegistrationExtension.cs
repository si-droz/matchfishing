﻿using PM.Onboarding.External.API.DTOs.V1.Administration;
using PM.Onboarding.External.API.Storage.Entities;

namespace PM.Onboarding.External.API.Web.Extensions
{
    internal static class PartnerRegistrationExtension
    {
        public static PartnerRegistration Map(this PartnerRegistration partnerRegistration, StorageCompany company)
        {
            partnerRegistration.CompanyId = company.CompanyId;
            partnerRegistration.CompanyName = company.CompanyName;
            partnerRegistration.RequestedBy = $"{company.Contact.FirstName} {company.Contact.LastName}";

            return partnerRegistration;
        }
    }
}