﻿using System;
using PM.Onboarding.External.API.DTOs.V1;
using PM.Onboarding.External.API.Storage.Entities;

namespace PM.Onboarding.External.API.Web.Extensions
{
    internal static class PartnerOnboardingExtension
    {
        public static StorageCompany Map(this StorageCompany company, PartnerOnboarding partnerOnboarding)
        {
            company.CompanyName = partnerOnboarding.Company.Name;
            company.Url = partnerOnboarding.Company.Website;
            company.AddressLine1 = partnerOnboarding.Company.Address.Line1;
            company.AddressLine2 = partnerOnboarding.Company.Address.Line2;
            company.AddressLine3 = partnerOnboarding.Company.Address.Line3;
            company.CityTown = partnerOnboarding.Company.Address.CityTown;
            company.County = partnerOnboarding.Company.Address.County;
            company.Country = partnerOnboarding.Company.Address.Country;
            company.PostCode = partnerOnboarding.Company.Address.PostCode;
            company.CompanySummary = partnerOnboarding.Company.Summary;
            company.SimsPrimary = partnerOnboarding.Company.SimsPrimary;
            company.SimsId = partnerOnboarding.Company.SimsId;
            company.TermsAndConditionsRead = partnerOnboarding.Company.TermsAndConditionsRead;
            company.Contact = MapContact(partnerOnboarding.Contact);
            company.CreateDate = DateTime.Now;

            return company;
        }

        private static StorageContact MapContact(Contact contact)
        {
            return new StorageContact
                   {
                       Title = contact.Title,
                       FirstName = contact.FirstName,
                       LastName = contact.LastName,
                       WorkEmail = contact.WorkEmail,
                       WorkTelephone = contact.WorkPhone
                   };
        }
    }
}