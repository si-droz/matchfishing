(function () {
  'use strict';

  var instrumentationKey = '448cb21d-292f-4722-8d58-dc78429055f5';

  var module = angular.module('pm.management', [
    'ApplicationInsightsModule', 'ngRoute', 'AdalAngular', 'ui.bootstrap'
  ]);

  module.constant('envConfig', {
    partnerApi: 'https://localhost:44300',
    administratorGroupId: 'a855950d-5070-4b33-84f2-fec09646f7b7'
  });

  module.config(['$routeProvider', '$httpProvider', '$locationProvider', 'applicationInsightsServiceProvider', 'adalAuthenticationServiceProvider', 'envConfig', function ($routeProvider, $httpProvider, $locationProvider, aiProvider, adalProvider, envConfig) {

    $routeProvider.when('/', {
      controller: 'homeCtrl',
      controllerAs: 'model',
      templateUrl: '/home/home.html',
      requireADLogin: true
    }).when('/Partners', {
      controller: 'partnersCtrl',
      controllerAs: 'model',
      templateUrl: '/partners/partners.html',
      requireADLogin: true
    }).when('/PartnerDetail/:id', {
      controller: 'partnerDetailCtrl',
      controllerAs: 'model',
      templateUrl: '/partnerDetail/partnerDetail.html',
      requireADLogin: true
    }).when('/Tasks', {
      controller: 'tasksCtrl',
      controllerAs: 'model',
      templateUrl: '/tasks/tasks.html',
      requireADLogin: true
    }).when('/PartnerDetail/:id/Association', {
      controller: 'associationDetailCtrl',
      controllerAs: 'model',
      templateUrl: 'associations/associationDetail.html',
      requireAdLogin: true
    }).when('/PartnerDetail/:id/ManageAssociation/:associationId', {
      controller: 'manageAssociationCtrl',
      controllerAs: 'model',
      templateUrl: '/associations/manageAssociation.html',
      requireADLogin: true
    }).otherwise({ redirectTo: '/' });

    $locationProvider.hashPrefix('');

    var options = {
      // applicationName: used as a 'friendly name' prefix to url paths
      applicationName: 'pm.management.web',
      // autoPageViewTracking: enables the sending a event to Application Insights when 
      // ever the $locationChangeSuccess event is fired on the rootScope
      autoPageViewTracking: true,
      // autoLogTracking: enables the interception of calls to the $log service and have the trace 
      // data sent to Application Insights.
      autoLogTracking: true,
      // autoExceptionTracking: enables calls to the $exceptionHandler service, usually unhandled exceptions, to have the error and stack data sent to Application Insights.
      autoExceptionTracking: true
      // sessionInactivityTimeout: The time (in milliseconds) that a user session can be inactive, before a new session will be created (on the next api call). Default is 30mins.
      //sessionInactivityTimeout: 1800000
    };

    aiProvider.configure(instrumentationKey, options);

    var endpoints = {
      // Map the location of a request to an API to a the identifier of the associated resource
      'https://localhost:44300': 'https://localhost:44300'
    };

    adalProvider.init(
      {
        instance: 'https://login.microsoftonline.com/',
        tenant: 'ad0672ef-a8d0-4206-a165-3eba144eceb1',
        clientId: '7e830865-0373-4813-82aa-5a52d127b966',
        extraQueryParameter: 'nux=1',
        endpoints: endpoints,
        //cacheLocation: 'localStorage', // enable this for IE, as sessionStorage does not work for localhost.  
        // Also, token acquisition for the To Go API will fail in IE when running on localhost, due to IE security restrictions.
      },
      $httpProvider
    );

  }]);
}());