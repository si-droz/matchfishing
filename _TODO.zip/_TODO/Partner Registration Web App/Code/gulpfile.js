'use strict';

const gulp = require('gulp');
const gulpSequence = require('gulp-sequence');
const requireDir = require('require-dir');

global.CONFIG = {
    IsLocal: false,
    DIST: './dist',
    Manifest: './dist/rev-manifest.json'
};

requireDir('./gulp-tasks');
