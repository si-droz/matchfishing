angular.module("partners.onboarding.config", [])
.constant("EnvironmentConfig", {"serviceApi":"https://localhost:44338","siteKey":"6Lec9wwUAAAAAMjZPWTARYMRftWgfxqhG2DvoVSx","guidanceStorage":"https://pmapis.azure-api.net/guidance/","pmpUrl":"https://localhost:44324"});
