'use strict';

function loadingService($rootScope) {
    const self = this;
    self.setLoading = (loading) => {
        $rootScope.loadingView = loading;
    };
}

angular.module('partners.onboarding').service('LoadingService', loadingService);
