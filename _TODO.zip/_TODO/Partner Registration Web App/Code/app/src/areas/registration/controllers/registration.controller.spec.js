'use strict';

describe('registration.controller.js', () => {
  let controller, registrationService, vcRecaptchaService, EnvironmentConfig, $q, $scope, $httpBackend;

  beforeEach(angular.mock.inject(($rootScope, _$httpBackend_, _$q_, $location, $log) => {
      $q = _$q_;
      $scope = $rootScope.$new();
      $httpBackend = _$httpBackend_;

      registrationService = jasmine.createSpyObj('registrationService', ['create']);
      registrationService.create.and.returnValue($q.defer().promise);

      vcRecaptchaService = jasmine.createSpyObj('vcRecaptchaService', ['getResponse', 'reload'])

      EnvironmentConfig = jasmine.createSpyObj('EnvironmentConfig', ['siteKey']);

      controller = new registrationController(registrationService, vcRecaptchaService, EnvironmentConfig, null);
      $scope.$apply();
  }));

  afterEach(() => {
      $httpBackend.verifyNoOutstandingExpectation();
      $httpBackend.verifyNoOutstandingRequest();
  });

  describe('initialization', () => {
      it('should not throw errors', () => {
          expect(controller).toBeDefined();
      });

      it('should have a registration service defined', () => {
          expect(controller.registrationService).toBeDefined();
      });
  });

  describe('createPartner', () => {
    it('should do nothing when the model is not valid', () => {
      //Arrange
      spyOn(controller, 'validate').and.returnValue(false);

      //Act
      controller.createPartner({});

      //Assert
      expect(registrationService.create).not.toHaveBeenCalled();
    });

    it('should open modal window after successful registration', () => {
      //Arrange
      const partner = {};
      spyOn(controller, 'validate').and.returnValue(true);
      spyOn(controller, 'openModal');
      registrationService.create.and.returnValue($q.resolve({}));

      //Act
      controller.createPartner(partner);
      $scope.$apply();

      //Assert
      expect(registrationService.create).toHaveBeenCalled();
      expect(controller.openModal).toHaveBeenCalled();
    });

    it('should present error response after not successful registration', () => {
      //Arrange
      const partner = {};
      spyOn(controller, 'validate').and.returnValue(true);
      registrationService.create.and.returnValue($q.reject({}));

      //Act
      controller.createPartner(partner);
      $scope.$apply();

      //Assert
      expect(registrationService.create).toHaveBeenCalled();
      expect(controller.isError).toBe(true);
    });

  });

});
