'use strict';

class acknowledgmentController {
    constructor($window, EnvironmentConfig) {
        this.$window = $window;
        this.pmpUrl = EnvironmentConfig.pmpUrl;
    }

    ok() {
        this.$window.location.href = this.pmpUrl;
    }
}

angular.module('areas.registration').controller('acknowledgmentController', acknowledgmentController);
