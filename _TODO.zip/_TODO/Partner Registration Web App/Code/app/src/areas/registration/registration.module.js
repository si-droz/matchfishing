'use strict';

angular.module('areas.registration', ['templates']);
