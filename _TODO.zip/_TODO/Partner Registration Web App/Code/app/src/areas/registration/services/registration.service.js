'use strict';

function registrationService($http, $httpParamSerializer, EnvironmentConfig) {
    'ngInject';
    let service;

    const registrationUrl = `${EnvironmentConfig.serviceApi}/v1/onboarding`;

    service = {
        create: (partner, captchaResponse) => {
                return $http({
                    method: 'POST',
                    url: registrationUrl,
                    data: JSON.stringify(partner),
                        headers: {
                            'Content-Type': 'application/json',
                            'g-captcha-response': captchaResponse
                        }
                });
        }
    };

    return service;
}

angular.module('areas.registration').factory('registrationService', registrationService);
