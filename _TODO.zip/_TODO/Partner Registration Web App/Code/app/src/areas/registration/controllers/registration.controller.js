'use strict';

class registrationController {
    constructor(registrationService, vcRecaptchaService, EnvironmentConfig, $uibModal) {
        'ngInject';
        this.registrationService = registrationService;
        this.vcRecaptchaService = vcRecaptchaService;
        this.$uibModal = $uibModal;

        this.siteKey = EnvironmentConfig.siteKey;
        this.guidanceStorageUrl = EnvironmentConfig.guidanceStorage;

        this.isError = false;
        this.isSuccess = false;
        this.captchaErrorText = '';
        this.TCRead = false;
        this.tcNotReadText = ''
    }

    setTCRead(){
        this.TCRead = true;
        this.tcNotReadText = '';
    }

    createPartner(partner) {
        const self = this;
        const captchaResponse = this.vcRecaptchaService.getResponse();
        const isValid = this.validate(captchaResponse);
        if(isValid) {
                    this.registrationService.create(partner, captchaResponse)
                        .then((response) => {
                            this.isSuccess = true;
                            self.openModal();
                        })
                        .catch((error) => {
                            self.isError = true;
                            self.vcRecaptchaService.reload();
                        });
        }
    }

    openModal () {
      this.$uibModal.open({
        animation: true,
        ariaLabelledBy: 'modal-title',
        ariaDescribedBy: 'modal-body',
        templateUrl: 'src/areas/registration/tmpl/acknowledgment.html',
        backdrop: 'static',
        controller: 'acknowledgmentController',
        controllerAs: '$ctrl',
        keyboard: false
      });
    }

    isRequestAccepted() {
        return this.isSuccess;
    }

    isRequestDenied() {
        return this.isError;
    }

    validate(captchaResponse) {
        angular.forEach(this.form.$error, (fields) => {
            angular.forEach(fields, (field) => {
                if(field === undefined) return;
                field.$setTouched();
                field.$setDirty();
            });
        });
        
        if(captchaResponse === '') {
            this.captchaErrorText = 'Please accept the reCAPTCHA.';
            return false;
        }

        if(!this.TCRead) {
            this.tcNotReadText = "Please read the terms and conditions.";
            return false;
        }

        return this.form.$valid;
    }

    OnCaptchaSuccess() {
        this.captchaErrorText = '';
    }
}

angular.module('areas.registration').controller('registrationController', registrationController);
