'use strict';

function loadingInterceptor($q, LoadingService) {
    const loadingInterceptor = {
        request: (config) => {
            if(config.url.indexOf('modal') === -1) {
                LoadingService.setLoading(true);
            }
            return config;
        },
        requestError: (rejection) => {
            LoadingService.setLoading(false);
            return $q.reject(rejection);
        },
        response: (response) => {
            LoadingService.setLoading(false);
            return response;
        },
        responseError: (rejection) => {
            LoadingService.setLoading(false);
            return $q.reject(rejection);
        }
    };
    return loadingInterceptor;
}

angular.module('partners.onboarding').factory('LoadingInterceptor', loadingInterceptor);
