'use strict';

// vendor scripts
import angular from '../bower_components/angular/angular.min.js';
import '../bower_components/angular-route/angular-route.min.js';

import '../bower_components/angularLocalStorage/dist/angularLocalStorage.min.js';
import '../bower_components/angular-animate/angular-animate.min.js';
import '../bower_components/angular-cookies/angular-cookies.min.js';
import '../bower_components/angular-resource/angular-resource.min.js';
import '../bower_components/angular-sanitize/angular-sanitize.min.js';
import '../bower_components/angular-touch/angular-touch.min.js';
import '../bower_components/angular-messages/angular-messages.min.js';
import '../bower_components/angular-md5/angular-md5.min.js';
import '../bower_components/angular-route/angular-route.min.js';
import '../bower_components/angular-recaptcha/release/angular-recaptcha.min.js';
import '../bower_components/angular-bootstrap/ui-bootstrap-tpls.min.js';

// app scripts
import './app.templates.js';

// home
import './areas/registration/registration.module.js';
import './areas/registration/services/registration.service.js';
import './areas/registration/controllers/registration.controller.js';
import './areas/registration/controllers/acknowledgment.controller.js';

// main
import './app.module.js';

import './directives/focusOnInvalidElement.directive.js';
import './directives/pmMessageLogger.directive.js';

import './interceptors/loading.interceptor.js';
import './services/loading.service.js';

import './env.config.js';
import './app.config.js';
