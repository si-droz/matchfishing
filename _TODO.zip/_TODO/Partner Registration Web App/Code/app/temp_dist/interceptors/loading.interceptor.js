'use strict';

loadingInterceptor.$inject = ["$q", "LoadingService"];
function loadingInterceptor($q, LoadingService) {
    var loadingInterceptor = {
        request: function request(config) {
            if (config.url.indexOf('modal') === -1) {
                LoadingService.setLoading(true);
            }
            return config;
        },
        requestError: function requestError(rejection) {
            LoadingService.setLoading(false);
            return $q.reject(rejection);
        },
        response: function response(_response) {
            LoadingService.setLoading(false);
            return _response;
        },
        responseError: function responseError(rejection) {
            LoadingService.setLoading(false);
            return $q.reject(rejection);
        }
    };
    return loadingInterceptor;
}

angular.module('partners.onboarding').factory('LoadingInterceptor', loadingInterceptor);