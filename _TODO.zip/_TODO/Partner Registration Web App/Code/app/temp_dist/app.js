'use strict';

// vendor scripts

var _angularMin = require('../bower_components/angular/angular.min.js');

var _angularMin2 = _interopRequireDefault(_angularMin);

require('../bower_components/angular-route/angular-route.min.js');

require('../bower_components/angularLocalStorage/dist/angularLocalStorage.min.js');

require('../bower_components/angular-animate/angular-animate.min.js');

require('../bower_components/angular-cookies/angular-cookies.min.js');

require('../bower_components/angular-resource/angular-resource.min.js');

require('../bower_components/angular-sanitize/angular-sanitize.min.js');

require('../bower_components/angular-touch/angular-touch.min.js');

require('../bower_components/angular-messages/angular-messages.min.js');

require('../bower_components/angular-md5/angular-md5.min.js');

require('../bower_components/angular-recaptcha/release/angular-recaptcha.min.js');

require('../bower_components/angular-bootstrap/ui-bootstrap-tpls.min.js');

require('./app.templates.js');

require('./areas/registration/registration.module.js');

require('./areas/registration/services/registration.service.js');

require('./areas/registration/controllers/registration.controller.js');

require('./areas/registration/controllers/acknowledgment.controller.js');

require('./app.module.js');

require('./directives/focusOnInvalidElement.directive.js');

require('./directives/pmMessageLogger.directive.js');

require('./interceptors/loading.interceptor.js');

require('./services/loading.service.js');

require('./env.config.js');

require('./app.config.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }