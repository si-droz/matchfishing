'use strict';

angular.module('partners.onboarding', ['partners.onboarding.config', 'ngAnimate', 'ngCookies', 'ngResource', 'angularLocalStorage', 'ngRoute', 'ngSanitize', 'ngTouch', 'ngMessages', 'vcRecaptcha', 'ui.bootstrap', 'areas.registration']);