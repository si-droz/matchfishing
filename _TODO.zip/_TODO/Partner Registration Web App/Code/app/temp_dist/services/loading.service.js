'use strict';

loadingService.$inject = ["$rootScope"];
function loadingService($rootScope) {
    var self = this;
    self.setLoading = function (loading) {
        $rootScope.loadingView = loading;
    };
}

angular.module('partners.onboarding').service('LoadingService', loadingService);