'use strict';

angular.module('partners.onboarding').config(["$locationProvider", "$routeProvider", "$compileProvider", "$httpProvider", function ($locationProvider, $routeProvider, $compileProvider, $httpProvider) {
  'ngInject';
  //  $compileProvider.debugInfoEnabled(true); // change it in production to boost performance

  $httpProvider.interceptors.push('LoadingInterceptor');

  $routeProvider.when('/', {
    templateUrl: 'src/areas/registration/tmpl/registration.html',
    controller: 'registrationController',
    controllerAs: 'vm'
  }).otherwise({ redirectTo: '/' });

  $locationProvider.html5Mode(true);
}]);