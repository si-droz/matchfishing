'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var registrationController = function () {
    registrationController.$inject = ["registrationService", "vcRecaptchaService", "EnvironmentConfig", "$uibModal"];
    function registrationController(registrationService, vcRecaptchaService, EnvironmentConfig, $uibModal) {
        'ngInject';

        _classCallCheck(this, registrationController);

        this.registrationService = registrationService;
        this.vcRecaptchaService = vcRecaptchaService;
        this.$uibModal = $uibModal;

        this.siteKey = EnvironmentConfig.siteKey;
        this.guidanceStorageUrl = EnvironmentConfig.guidanceStorage;

        this.isError = false;
        this.isSuccess = false;
        this.captchaErrorText = '';
        this.TCRead = false;
        this.tcNotReadText = '';
    }

    _createClass(registrationController, [{
        key: 'setTCRead',
        value: function setTCRead() {
            this.TCRead = true;
            this.tcNotReadText = '';
        }
    }, {
        key: 'createPartner',
        value: function createPartner(partner) {
            var _this = this;

            var self = this;
            var captchaResponse = this.vcRecaptchaService.getResponse();
            var isValid = this.validate(captchaResponse);
            if (isValid) {
                this.registrationService.create(partner, captchaResponse).then(function (response) {
                    _this.isSuccess = true;
                    self.openModal();
                }).catch(function (error) {
                    self.isError = true;
                    self.vcRecaptchaService.reload();
                });
            }
        }
    }, {
        key: 'openModal',
        value: function openModal() {
            this.$uibModal.open({
                animation: true,
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl: 'src/areas/registration/tmpl/acknowledgment.html',
                backdrop: 'static',
                controller: 'acknowledgmentController',
                controllerAs: '$ctrl',
                keyboard: false
            });
        }
    }, {
        key: 'isRequestAccepted',
        value: function isRequestAccepted() {
            return this.isSuccess;
        }
    }, {
        key: 'isRequestDenied',
        value: function isRequestDenied() {
            return this.isError;
        }
    }, {
        key: 'validate',
        value: function validate(captchaResponse) {
            angular.forEach(this.form.$error, function (fields) {
                angular.forEach(fields, function (field) {
                    if (field === undefined) return;
                    field.$setTouched();
                    field.$setDirty();
                });
            });

            if (captchaResponse === '') {
                this.captchaErrorText = 'Please accept the reCAPTCHA.';
                return false;
            }

            if (!this.TCRead) {
                this.tcNotReadText = "Please read the terms and conditions.";
                return false;
            }

            return this.form.$valid;
        }
    }, {
        key: 'OnCaptchaSuccess',
        value: function OnCaptchaSuccess() {
            this.captchaErrorText = '';
        }
    }]);

    return registrationController;
}();

angular.module('areas.registration').controller('registrationController', registrationController);