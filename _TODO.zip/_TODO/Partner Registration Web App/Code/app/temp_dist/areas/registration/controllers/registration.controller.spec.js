'use strict';

describe('registration.controller.js', function () {
      var controller = void 0,
          registrationService = void 0,
          vcRecaptchaService = void 0,
          EnvironmentConfig = void 0,
          $q = void 0,
          $scope = void 0,
          $httpBackend = void 0;

      beforeEach(angular.mock.inject(function ($rootScope, _$httpBackend_, _$q_, $location, $log) {
            $q = _$q_;
            $scope = $rootScope.$new();
            $httpBackend = _$httpBackend_;

            registrationService = jasmine.createSpyObj('registrationService', ['create']);
            registrationService.create.and.returnValue($q.defer().promise);

            vcRecaptchaService = jasmine.createSpyObj('vcRecaptchaService', ['getResponse', 'reload']);

            EnvironmentConfig = jasmine.createSpyObj('EnvironmentConfig', ['siteKey']);

            controller = new registrationController(registrationService, vcRecaptchaService, EnvironmentConfig, null);
            $scope.$apply();
      }));

      afterEach(function () {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
      });

      describe('initialization', function () {
            it('should not throw errors', function () {
                  expect(controller).toBeDefined();
            });

            it('should have a registration service defined', function () {
                  expect(controller.registrationService).toBeDefined();
            });
      });

      describe('createPartner', function () {
            it('should do nothing when the model is not valid', function () {
                  //Arrange
                  spyOn(controller, 'validate').and.returnValue(false);

                  //Act
                  controller.createPartner({});

                  //Assert
                  expect(registrationService.create).not.toHaveBeenCalled();
            });

            it('should open modal window after successful registration', function () {
                  //Arrange
                  var partner = {};
                  spyOn(controller, 'validate').and.returnValue(true);
                  spyOn(controller, 'openModal');
                  registrationService.create.and.returnValue($q.resolve({}));

                  //Act
                  controller.createPartner(partner);
                  $scope.$apply();

                  //Assert
                  expect(registrationService.create).toHaveBeenCalled();
                  expect(controller.openModal).toHaveBeenCalled();
            });

            it('should present error response after not successful registration', function () {
                  //Arrange
                  var partner = {};
                  spyOn(controller, 'validate').and.returnValue(true);
                  registrationService.create.and.returnValue($q.reject({}));

                  //Act
                  controller.createPartner(partner);
                  $scope.$apply();

                  //Assert
                  expect(registrationService.create).toHaveBeenCalled();
                  expect(controller.isError).toBe(true);
            });
      });
});