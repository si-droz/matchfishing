'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var acknowledgmentController = function () {
    acknowledgmentController.$inject = ["$window", "EnvironmentConfig"];
    function acknowledgmentController($window, EnvironmentConfig) {
        _classCallCheck(this, acknowledgmentController);

        this.$window = $window;
        this.pmpUrl = EnvironmentConfig.pmpUrl;
    }

    _createClass(acknowledgmentController, [{
        key: 'ok',
        value: function ok() {
            this.$window.location.href = this.pmpUrl;
        }
    }]);

    return acknowledgmentController;
}();

angular.module('areas.registration').controller('acknowledgmentController', acknowledgmentController);