//jshint strict: false
module.exports = function(config) {
  config.set({

    basePath: '../',

    files: [
      'bower_components/angular/angular.js',
      'bower_components/angular-route/angular-route.js',
      'bower_components/angular-mocks/angular-mocks.js',
      'src/app.templates.js',
      'src/**/*.module.js',
      'src/areas/**/*.js',
      'src/areas/**/*.spec.js'
      // 'tests/unit/**/*.spec.js'
    ],

    // autoWatch: false,
    // singleRun: true,
    // colors: true,

    frameworks: ['jasmine'],

    browsers: ['PhantomJS'],

    // reporters: ['junit'],

    plugins: [
      'karma-chrome-launcher',
      'karma-babel-preprocessor',
      'karma-ie-launcher',
      'karma-firefox-launcher',
      'karma-jasmine',
      'karma-junit-reporter',
      'karma-phantomjs-launcher'
    ],

    preprocessors: {
      'src/**/!(*spec).js': ['babel'],
      'src/**/*.module.js': ['babel'],
      'src/areas/**/*.js': ['babel'],
      'tests/unit/**/*.js': ['babel']
    },

    // browserify: {
    //   debug: true,
    //   transform: ['brfs' ]
    // },

    babelPreprocessor: {
      options: {
        presets: ['es2015']
      }
    },

    junitReporter: {
      outputFile: 'test_out/unit.xml',
      suite: 'unit'
     },

     browserNoActivityTimeout: 80000

  });
};
