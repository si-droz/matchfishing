# Partner Onboarding Portal

This document is a developer documentation for Partner Onboarding Portal.

## Environment setup

### Installing dependencies

Install latest stable version of [git](https://git-scm.com/)

Install latest stable version of [node.js](https://nodejs.org/en/)

Install latest stable version of [Visual Studio](https://www.visualstudio.com/en-us/downloads/download-visual-studio-vs.aspx)

Install latest stable version of [SQL Server](https://www.microsoft.com/en-us/cloud-platform/sql-server-editions-developers)

Install latest stable version of [gulp](http://gulpjs.com/)
    check whether your node.js and node package manager is correctly installed using commands: `node -v` and `npm -v`    
    run command: `npm install gulp -g`  
    check that gulp is correctly installed using the command: `gulp -v` - if this does not give you the gulp versions, reinstall nodejs and try again

### Cloning repositories

Clone Partner Registration Portal
    `git clone https://capita-sims-satellites.visualstudio.com/Partner%20API/_git/Partner%20Registration%20Web%20App`


### Running Partner Onboarding Portal

#### Portal first-time setup

Navigate to the Code folder of Partner Onboarding Portal

Install node dependencies
    run command: `npm install`

Install localhost certificate
    `ca.crt`

Add installed certificate to trusted root certification authorities

Install bower components
    run command: `bower install`

#### Run Portal

Navigate to the Code folder of Partner Onboarding Portal

Run Partner Onboarding Portal
    check whether port 44323 is available
    run command: `gulp local`
