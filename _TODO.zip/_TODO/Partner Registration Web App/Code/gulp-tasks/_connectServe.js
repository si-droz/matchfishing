'use strict';

const gulp = require('gulp');
const connect = require('gulp-connect');

gulp.task('connect-serve', () => {
	connect.server({
		root: 'app/dist',
		port: 44323
	});
});
