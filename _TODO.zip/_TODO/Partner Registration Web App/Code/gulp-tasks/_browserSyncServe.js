'use strict';

const gulp = require('gulp');
const browserSync = require('browser-sync').create();
const gulpSequence = require('gulp-sequence');

// Static Server + watching scss/html files
gulp.task('browsersync-serve', () => {
    browserSync.init({
        server: "./app/dist",
        https: {
            key: 'testCertificate.key',
            cert: 'testCertificate.crt'
        },
        port: 44323
    });

    gulp.watch('app/src/**/*.js').on('change', () => {
        gulpSequence('js-transpile', 'js-bundle', browserSync.reload);
    });
    gulp.watch('app/src/**/*.css').on('change', () => {
        gulpSequence('img-copy', 'css-bundle', browserSync.reload);
    });
    gulp.watch('app/src/**/*.html').on('change', () => {
        gulpSequence('html-copy', 'html-templatecache', 'js-transpile', 'js-bundle', browserSync.reload);
    });

});
