'use strict';

const gulp = require('gulp');

gulp.task('environment-set-local', () => {
    global.CONFIG.Env = 'local';
});

gulp.task('environment-set-dev', () => {
    global.CONFIG.Env = 'dev';
});

gulp.task('environment-set-test', () => {
    global.CONFIG.Env = 'test';
});

gulp.task('environment-set-integration', () => {
    global.CONFIG.Env = 'integration';
});

gulp.task('environment-set-live', () => {
    global.CONFIG.Env = 'live';
});
