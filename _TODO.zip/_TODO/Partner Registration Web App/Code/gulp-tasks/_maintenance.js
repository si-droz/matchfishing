'use strict';

const gulp = require('gulp');
const gulpSequence = require('gulp-sequence');
const clean = require('gulp-clean');

gulp.task('distribution-clean', () => {
    return gulp.src(['app/dist/*', 'app/temp_dist/*'])
      .pipe(clean({force: true, read:false}));
});
