'use strict';

const gulp = require('gulp');
const Server = require('karma').Server;

gulp.task('unit-tests', (done) => {
  new Server({
    configFile: __dirname + '/../app/tests/karma.conf.js',
  }, done).start();
});

gulp.task('unit-tests:singleRun', (done) => {
  new Server({
    configFile: __dirname + '/../app/tests/karma.conf.js',
    port: 9576,
    autoWatch: false,
    singleRun: true,
  }, done).start();
});

gulp.task('unit-tests:watch', (done) => {
  new Server({
    configFile: __dirname + '/../app/tests/karma.conf.js',
    port: 9876,
    autoWatch: true,
    singleRun: false,
  }, done).start();
});
