'use strict';

const gulp = require('gulp');
const gulpSequence = require('gulp-sequence');

gulp.task('dev', gulpSequence(
  'distribution-clean',
  'environment-set-dev',
  'bower-components-copy',
  'copy-iis-deployment-parameters',
  'copy-web-config',
  'css-bundle-minify',
  'img-minify',
  'html-transform',
  'html-templatecache',
  'js-config-angular-transform',
  'js-transpile',
  'js-parse',
  'js-bundle-minify'
));

gulp.task('test', gulpSequence(
  'distribution-clean',
  'environment-set-test',
  'bower-components-copy',
  'copy-iis-deployment-parameters',
  'copy-web-config',
  'css-bundle-minify',
  'img-minify',
  'html-transform',
  'html-templatecache',
  'js-config-angular-transform',
  'js-transpile',
  'js-parse',
  'js-bundle-minify'
));

gulp.task('integration', gulpSequence(
  'distribution-clean',
  'environment-set-integration',
  'bower-components-copy',
  'copy-iis-deployment-parameters',
  'copy-web-config',
  'css-bundle-minify',
  'img-minify',
  'html-transform',
  'html-templatecache',
  'js-config-angular-transform',
  'js-transpile',
  'js-parse',
  'js-bundle-minify'
));

gulp.task('live', gulpSequence(
  'distribution-clean',
  'environment-set-live',
  'bower-components-copy',
  'copy-iis-deployment-parameters',
  'copy-web-config',
  'css-bundle-minify',
  'img-minify',
  'html-transform',
  'html-templatecache',
  'js-config-angular-transform',
  'js-transpile',
  'js-parse',
  'js-bundle-minify'
));
