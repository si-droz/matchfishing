'use strict';

const gulp = require('gulp');
const gulpSequence = require('gulp-sequence');

gulp.task('local', gulpSequence(
    'distribution-clean',
    'environment-set-local',
    'bower-components-copy',
    'css-bundle',
    'img-copy',
    'html-transform',
    'html-templatecache',
    'js-config-angular-transform',
    'js-transpile',
    'js-parse',
    'js-bundle',
    'unit-tests:singleRun',
    'browsersync-serve'
));

gulp.task('local:no-tests', gulpSequence(
    'distribution-clean',
    'environment-set-local',
    'bower-components-copy',
    'css-bundle',
    'img-copy',
    'html-transform',
    'html-templatecache',
    'js-config-angular-transform',
    'js-transpile',
    'js-parse',
    'js-bundle',
    'browsersync-serve'
));

gulp.task('local:build', gulpSequence(
    'distribution-clean',
    'environment-set-local',
    'bower-components-copy',
    'css-bundle',
    'img-copy',
    'html-transform',
    'html-templatecache',
    'js-config-angular-transform',
    'js-transpile',
    'js-parse',
    'js-bundle'
));

gulp.task('local:dev-like', gulpSequence(
    'distribution-clean',
    'environment-set-local',
    'bower-components-copy',
    'css-bundle',
    'img-minify',
    'html-transform',
    'html-templatecache',
    'js-config-angular-transform',
    'js-transpile',
    'js-parse',
    'js-bundle-minify',
    'js-config-angular-transform',
    'browsersync-serve'
));
