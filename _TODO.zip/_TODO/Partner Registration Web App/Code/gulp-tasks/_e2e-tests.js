'use strict';

const gulp = require('gulp');
const protractor = require("gulp-protractor").protractor;

gulp.task('e2e-tests', (done) => {
  // var args = ['--baseUrl', 'http://127.0.0.1:8888'];
  gulp.src([__dirname + '/../app/tests/e2e/**/*.spec.js'])
    .pipe(protractor({
      configFile: __dirname + '/../app/tests/protractor.conf.js'
      // args: args
    }))
    .on('error', (e) => { throw e; });
});
