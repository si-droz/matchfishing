'use strict';

const gulp = require('gulp');

gulp.task('bower-components-copy', () => {
  gulp.src('app/bower_components/**')
    .pipe(gulp.dest('app/dist/bower_components'));
});
