'use strict';

const gulp = require('gulp');
const fs = require('fs');
const data = require('gulp-data');
const template = require('gulp-template');
const ngTemplates = require('gulp-ng-templates');

gulp.task('html-templatecache', () => {
      return gulp.src('app/**/tmpl/**/*.html')
          .pipe(ngTemplates({
              filename: 'app.templates.js',
              module: 'templates',
          }))
          .pipe(gulp.dest('app/src'));
});

gulp.task('html-transform', () => {
  let settings = JSON.parse(fs.readFileSync('env.config.json', 'utf8'));
  const env = global.CONFIG.Env;
  process.stdout.write(`html-transform, environment: ${env} \n`);

  gulp.src('app/*.html')
    .pipe(gulp.dest('app/dist'));

  return gulp.src('web.config')
    .pipe(data(() =>
        ({
          serviceApi: settings[env].EnvironmentConfig.serviceApi,
        })))
    .pipe(template())
    .pipe(gulp.dest('app/dist'));
});
