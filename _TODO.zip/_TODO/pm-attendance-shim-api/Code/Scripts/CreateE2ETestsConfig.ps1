param(
    [Parameter(Mandatory=$true)][string]$configFilePathTemplate,
    [Parameter(Mandatory=$true)][string]$configFilePath,
    [Parameter(Mandatory=$true)][string]$clientSecret,
    [Parameter(Mandatory=$true)][string]$subscriptionKey
)

# .\CreateE2ETestsConfig.ps1 -configFilePathTemplate 'C:\Repos\RQA05\Code\PartnerAccess.RunQueryAdapter.Web.Tests.E2E\Configs\ProductionSlot_StagingEnv\PartnerAccess.RunQueryAdapter.Web.Tests.E2E.dll.config' -configFilePath 'C:\Repos\RQA05\Code\PartnerAccess.RunQueryAdapter.Web.Tests.E2E\Configs\ProductionSlot_StagingEnv\PartnerAccess.RunQueryAdapter.Web.Tests.E2E.dll2.config' -clientSecret 'secretValue' -subscriptionKey 'subscriptionKey'

Write-Host 'Parameters used:'
Write-Host 'configFilePathTemplate: ' $configFilePathTemplate
Write-Host 'configFilePath: ' $configFilePath
Write-Host 'clientSecret: ' $clientSecret
Write-Host 'subscriptionKey: ' $subscriptionKey

$content = [System.IO.File]::ReadAllText($configFilePathTemplate).Replace("{clientSecret}",$clientSecret).Replace("{subscriptionKey}",$subscriptionKey)
[System.IO.File]::WriteAllText($configFilePath, $content)