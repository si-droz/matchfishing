﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;

namespace Attendance
{
    public class AttendanceRecord
    {
        [JsonIgnore]
        [NotMapped]
        public Guid ID { get; set; }

        public bool IsDeleted { get; set; } = false;

        [Key]
        public Guid ExternalID { get; set; }

        public bool? Present { get; set; }
        public bool? Absent { get; set; }
        public Guid SchoolAttendanceCode { get; set; }
        public Guid Learner { get; set; }
        public Guid? AttendableEvent { get; set; }
        public int? MinutesLate { get; set; }
        public string Comment { get; set; }
        public Guid? RecordedBy { get; set; }
        public DateTimeOffset? RecordedOn { get; set; }
        public string ChangeProcessName { get; set; }
        public DateTimeOffset? AttendableEventStart { get; set; }
        public List<AttendanceHistory> AttendanceHistorys { get; set; }
    }

    public class AttendanceHistory
    {
        public Guid? MarkChangedBy { get; set; }
        public DateTimeOffset? MarkChangedDateTime { get; set; }
        public Guid? MarkChangedFrom { get; set; }
        public Guid? MarkChangedTo { get; set; }
        public Guid? InitialMarkRecordedBy { get; set; }
        public DateTimeOffset? InitialMarkRecordedDateTime { get; set; }
        public string ChangeProcessName { get; set; }
        public Guid? AttendanceMarkChangeReason { get; set; }
        public Guid? ExternalID { get; set; }
    }
}