﻿using System.Configuration;

namespace PM.Attendance.Shim.Api.OData.Configuration
{
    public class ODataConfiguration
    {
        public static readonly int AllowedDateRangeInDays = int.Parse(ConfigurationManager.AppSettings["OData:AllowedDateRangeInDays"]);
    }
}