﻿using System;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using System.Web.OData;
using System.Web.OData.Query;
using Microsoft.OData;
using PM.Attendance.Shim.Api.OData.Configuration;

namespace PM.Attendance.Shim.Api.OData.CustomAttributes
{
    public class ValidateODataQueryDatesAttribute : EnableQueryAttribute
    {
        private const string FilterMatchText = "$filter";
        private const string GreaterThanDateMatchText = "AttendableEventStart gt ";
        private const string LessThanDateMatchText = "AttendableEventStart lt ";
        private const string FilterQueryOrConditionNotSupportedText = "'or' operators are not allowed in filter expressions for AttendanceRecords";
        private const string FilterQueryOrConditionMatchText = " or ";
        private const string FilterValidationErrorMessage = "The request is too large. Please add the following filter conditions $filter=AttendableEventStart gt {date} and AttendableEventStart lt {date}";
        private const string InvalidDateErrorMessage = "Invalid date found at ";

        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            NameValueCollection queryStringItems = HttpUtility.ParseQueryString(actionContext.Request.RequestUri.Query);
            string filterQuery = queryStringItems[FilterMatchText];

            if(string.IsNullOrEmpty(filterQuery)) throw new ODataException(FilterValidationErrorMessage);

            if(filterQuery.Contains(FilterQueryOrConditionMatchText)) throw new ODataException(FilterQueryOrConditionNotSupportedText);

            if(!filterQuery.Contains(GreaterThanDateMatchText)) throw new ODataException(FilterValidationErrorMessage);

            if(!filterQuery.Contains(LessThanDateMatchText)) throw new ODataException(FilterValidationErrorMessage);

            DateTimeOffset startDate = GetDate(filterQuery, GreaterThanDateMatchText);

            DateTimeOffset endDate = GetDate(filterQuery, LessThanDateMatchText);

            if((endDate - startDate).Days > ODataConfiguration.AllowedDateRangeInDays) throw new ODataException($"Date range search cannot be a greater than {ODataConfiguration.AllowedDateRangeInDays} days.");

            base.OnActionExecuting(actionContext);
        }

        /// <inheritdoc />
        /// <summary>
        /// override to stop a second validation of the query
        /// </summary>
        /// <param name="request"></param>
        /// <param name="queryOptions"></param>
        public override void ValidateQuery(HttpRequestMessage request, ODataQueryOptions queryOptions)
        {
        }

        /// <inheritdoc />
        /// <summary>
        /// override stop validation of the odata query on the response
        /// </summary>
        /// <param name="actionExecutedContext"></param>
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
        }

        private static DateTimeOffset GetDate(string filterQuery, string indexMatchText)
        {
            int dateIndex = filterQuery.IndexOf(indexMatchText, StringComparison.Ordinal);
            string dateString = filterQuery.Substring(dateIndex + indexMatchText.Length)
                                           .Split(' ')
                                           .First();

            if(!DateTimeOffset.TryParse(dateString, out var date)) throw new ODataException($"{InvalidDateErrorMessage}{indexMatchText}{dateString}");

            return date;
        }
    }
}