﻿using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;
using PM.Service.Shim.Pipeline;
using PM.Service.Shim.Swashbuckle;
using Swashbuckle.Swagger.Annotations;

namespace PM.Attendance.Shim.Api.Controllers.V2
{
    public class AttendanceBatchV2Controller : ApiController
    {
        private readonly IPipelineFactory _pipelineFactory;

        // NOTE: Whilst V1 looks wrong here, it is correct because we're mapping to V1 of the SIMS Primary "micro-service"
        private const string EndpointAddressFragment = "OData/V1/";

        private const string BatchEndPointName = "$batch";

        public AttendanceBatchV2Controller(IPipelineFactory pipelineFactory)
        {
            _pipelineFactory = pipelineFactory;
        }

        [HttpPost]
        [Route("Attendance/V2/$batch")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.BadRequest)]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.Forbidden)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        [SwaggerOperation(Tags = new[] {"AttendanceRecords"})]
        [SwaggerCustomPathName("/$batch")]
        public async Task<IHttpActionResult> Post()
        {
            PipelineTaskBase<CallForwardContext> pipelineTask = _pipelineFactory.GetBatchPipeline();
            var context = new CallForwardContext(Request, EndpointAddressFragment, BatchEndPointName);

            await pipelineTask.ExecuteAsync(context);

            return new ResponseMessageResult(context.ResponseMessage);
        }
    }
}