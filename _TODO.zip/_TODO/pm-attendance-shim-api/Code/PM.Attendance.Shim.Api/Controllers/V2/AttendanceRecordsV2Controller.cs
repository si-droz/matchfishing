﻿using System;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Results;
using System.Web.OData;
using Attendance;
using PM.Attendance.Shim.Api.OData.CustomAttributes;
using PM.Service.Shim.Factories;
using PM.Service.Shim.Pipeline;
using PM.Service.Shim.Swashbuckle;
using Swashbuckle.Swagger.Annotations;

namespace PM.Attendance.Shim.Api.Controllers.V2
{
    public class AttendanceRecordsV2Controller : ODataController
    {
        private readonly IPipelineFactory _pipelineFactory;
        private readonly IResponseMessageResultFactory _responseMessageResultFactory;

        // NOTE: Whilst V1 looks wrong here, it is correct because we're mapping to V1 of the SIMS Primary "micro-service"
        private const string EndpointAddressFragment = "OData/V1/";

        private readonly string _entityName = $"{nameof(AttendanceRecord)}s";

        public AttendanceRecordsV2Controller(IPipelineFactory pipelineFactory, IResponseMessageResultFactory responseMessageResultFactory)
        {
            _pipelineFactory = pipelineFactory;
            _responseMessageResultFactory = responseMessageResultFactory;
        }

        [HttpPost]
        [SwaggerResponse(HttpStatusCode.Created)]
        [SwaggerResponse(HttpStatusCode.BadRequest)]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.Forbidden)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        [SwaggerOperation(Tags = new[] {"AttendanceRecords"})]
        [SwaggerCustomPathName("/AttendanceRecords")]
        public async Task<IHttpActionResult> Post()
        {
            PipelineTaskBase<CallForwardContext> pipelineTask = _pipelineFactory.GetWritePipeline();
            var context = new CallForwardContext(Request, EndpointAddressFragment, _entityName);
            await pipelineTask.ExecuteAsync(context);
            return new ResponseMessageResult(context.ResponseMessage);
        }

        [HttpPut]
        [SwaggerResponse(HttpStatusCode.NoContent)]
        [SwaggerResponse(HttpStatusCode.BadRequest)]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.Forbidden)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        [SwaggerOperation(Tags = new[] {"AttendanceRecords"})]
        [SwaggerCustomPathName("/AttendanceRecords")]
        public async Task<IHttpActionResult> Put()
        {
            ResponseMessageResult result = _responseMessageResultFactory.GetErrorResponseMessageResult(HttpStatusCode.MethodNotAllowed, "PUT method not allowed.");

            return await Task.FromResult(result);
        }

        [HttpGet]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.BadRequest)]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.Forbidden)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        [SwaggerOperation(Tags = new[] {"AttendanceRecords"})]
        [SwaggerCustomPathName("/AttendanceRecords")]
        [SwaggerImplementationNotes("Add the following filter conditions $filter=AttendableEventStart gt {date} and AttendableEventStart lt {date}")]
        [ValidateODataQueryDates]
        public async Task<IHttpActionResult> Get()
        {
            PipelineTaskBase<CallForwardContext> pipelineTask = _pipelineFactory.GetReadPipeline();
            var context = new CallForwardContext(Request, EndpointAddressFragment, _entityName);
            await pipelineTask.ExecuteAsync(context);
            return new ResponseMessageResult(context.ResponseMessage);
        }

        [HttpGet]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.BadRequest)]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.Forbidden)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        [SwaggerOperation(Tags = new[] {"AttendanceRecords"})]
        [SwaggerCustomPathName("/AttendanceRecords")]
        public async Task<IHttpActionResult> Get([FromODataUri] Guid key)
        {
            PipelineTaskBase<CallForwardContext> pipelineTask = _pipelineFactory.GetReadPipeline();
            var context = new CallForwardContext(Request, EndpointAddressFragment, _entityName);
            await pipelineTask.ExecuteAsync(context);
            return new ResponseMessageResult(context.ResponseMessage);
        }

        [HttpGet]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.BadRequest)]
        [SwaggerResponse(HttpStatusCode.Unauthorized)]
        [SwaggerResponse(HttpStatusCode.Forbidden)]
        [SwaggerResponse(HttpStatusCode.InternalServerError)]
        [SwaggerOperation(Tags = new[] {"AttendanceRecords"})]
        [SwaggerCustomPathName("/AttendanceRecords")]
        public async Task<IHttpActionResult> GetChanges([FromODataUri] DateTimeOffset startDate, [FromODataUri] DateTimeOffset endDate)
        {
            PipelineTaskBase<CallForwardContext> pipelineTask = _pipelineFactory.GetReadPipeline();
            var context = new CallForwardContext(Request, EndpointAddressFragment, _entityName);
            await pipelineTask.ExecuteAsync(context);
            return new ResponseMessageResult(context.ResponseMessage);
        }
    }
}