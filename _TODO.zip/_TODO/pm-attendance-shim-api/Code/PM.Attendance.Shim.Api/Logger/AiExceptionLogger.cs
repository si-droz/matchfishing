﻿using System.Web.Http.ExceptionHandling;
using Microsoft.ApplicationInsights;

namespace PM.Attendance.Shim.Api.Logger
{
    public class AiExceptionLogger : ExceptionLogger
    {
        public override void Log(ExceptionLoggerContext context)
        {
            if(context?.Exception != null)
            {
                Serilog.Log.Logger.Debug($"An error has occurred:\n\n{context.Exception}");
                var ai = new TelemetryClient();
                ai.TrackException(context.Exception);
            }
        }
    }
}