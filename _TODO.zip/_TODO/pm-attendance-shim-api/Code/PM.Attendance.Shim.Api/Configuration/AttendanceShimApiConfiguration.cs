﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace PM.Attendance.Shim.Api.Configuration
{
    public class AttendanceShimApiConfiguration
    {
        private static readonly string RequiredScopesString =
            ConfigurationManager.AppSettings["AttendanceShimApiConfiguration:RequiredScopes"];

        public static readonly IList<string> RequiredScopes = string.IsNullOrEmpty(RequiredScopesString)
                                                                  ? new List<string>()
                                                                  : RequiredScopesString.Split(';').ToList();
    }
}