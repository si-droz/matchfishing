﻿using System;
using System.Collections.Generic;
using System.Net.Http.Formatting;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;
using System.Web.OData.Extensions;
using Attendance;
using IdentityServer3.AccessTokenValidation;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Owin.Cors;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.WebApi;
using Owin;
using PM.Attendance.Shim.Api.Configuration;
using PM.Attendance.Shim.Api.Logger;
using PM.Audit.V2;
using PM.Service.Shim.ApiVersioning;
using PM.Service.Shim.Extensions;
using PM.Service.Shim.MediaTypeFormatter;
using PM.Service.Shim.OData.Path;
using PM.Service.Shim.Services.Configuration;
using PM.Service.Shim.Swashbuckle;
using Serilog;
using Swashbuckle.Application;

namespace PM.Attendance.Shim.Api
{
    public class Startup
    {
        private static ODataApiServiceRouteMapper _oDataApiServiceRouteMapper;
        private const string ODataRouteName = "Partner API Attendance Info Domain";
        private const string Namespace = "Attendance";
        private const string RoutePrefix = "Attendance";
        private const string BatchEndpointSegment = "$batch";
        private const bool IsBatch = true;
        private const string DateTimeZoneId = "UTC";
        private readonly IEnumerable<string> _versions = new[] {"V2"};

        public void Configuration(IAppBuilder app)
        {
            Log.Logger = new LoggerConfiguration().ReadFrom.AppSettings()
                                                  .WriteTo.Trace()
                                                  .CreateLogger();

            TelemetryConfiguration.Active.InstrumentationKey =
                WebConfigurationManager.AppSettings["ApplicationInsights:InstrumentationKey"];

            // Thought: is there a better way to do this.
            app.MapWhen(owinContext => owinContext.Request.Path.ToUriComponent().EndsWith(BatchEndpointSegment), ConfigureBatchModelBuilder)
               .MapWhen(owinContext => !owinContext.Request.Path.ToUriComponent().EndsWith(BatchEndpointSegment), ConfigureSingleOperationModelBuilder);
        }

        private void ConfigureSingleOperationModelBuilder(IAppBuilder app)
        {
            HttpConfiguration httpConfiguration = GetHttpConfiguration();
            httpConfiguration.Formatters.Add(new JsonMediaTypeFormatter());

            _oDataApiServiceRouteMapper.CreateODataConventionModelBuilder();
            _oDataApiServiceRouteMapper.AddEntityToODataConventionModel<AttendanceRecord>($"{nameof(AttendanceRecord)}s", true);
            _oDataApiServiceRouteMapper.AddDateRangeFunctionToODataConventionModel<AttendanceRecord>($"{nameof(AttendanceRecord)}s", "Get", "ByDateRange");
            _oDataApiServiceRouteMapper.MapODataServiceRoutes();

            ConfigureAppSecurity(app, httpConfiguration);
        }

        private void ConfigureBatchModelBuilder(IAppBuilder app)
        {
            HttpConfiguration httpConfiguration = GetHttpConfiguration();
            httpConfiguration.Formatters.Add(new BatchFormatter());

            _oDataApiServiceRouteMapper.CreateODataConventionModelBuilder();
            _oDataApiServiceRouteMapper.MapODataServiceRoutes(IsBatch);

            ConfigureAppSecurity(app, httpConfiguration);
        }

        private HttpConfiguration GetHttpConfiguration()
        {
            var httpConfiguration = new HttpConfiguration();

            IUnityContainer unityContainer = new UnityContainer().RegisterWebDependencies();
            httpConfiguration.DependencyResolver = new UnityDependencyResolver(unityContainer);

            // Add exception handler to work around issue https://github.com/OData/WebApi/issues/142
            httpConfiguration.Services.Replace(typeof(IExceptionHandler), new ODataPathExceptionHandler(unityContainer));
            httpConfiguration.Services.Replace(typeof(IExceptionLogger), new AiExceptionLogger());

            httpConfiguration.MessageHandlers.Add(new AuditingMessageHandler("Shim - Attendance"));
            httpConfiguration.MapHttpAttributeRoutes();

            // Make sure that exception stack trace is not exposed by the API when a 500 error is raised
            // Outside of the local machine
            httpConfiguration.IncludeErrorDetailPolicy = IncludeErrorDetailPolicy.LocalOnly;

            // Ensure DateTimeOffset values presented by the json serialiser are always with a zero offset
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(DateTimeZoneId);
            httpConfiguration.SetTimeZoneInfo(timeZoneInfo);

            httpConfiguration.Formatters.Clear();
            httpConfiguration.Filter().OrderBy().Expand().Select();

            _oDataApiServiceRouteMapper = new ODataApiServiceRouteMapper(new ODataVersioningRouteConfiguration
                                                                         {
                                                                             HttpConfiguration = httpConfiguration,
                                                                             RouteName = ODataRouteName,
                                                                             RoutePrefix = RoutePrefix,
                                                                             Namespace = Namespace,
                                                                             Versions = _versions
                                                                         });

            return httpConfiguration;
        }

        private static void ConfigureAppSecurity(IAppBuilder app, HttpConfiguration httpConfiguration)
        {
            var swaggerExclusionPathFilters = new List<string>();
            httpConfiguration.EnableSwagger(swaggerConfiguration =>
                                            {
                                                swaggerConfiguration.UseFullTypeNameInSchemaIds();
                                                swaggerConfiguration.MultipleApiVersions(SwaggerVersionHelper.ResolveVersionSupportByRouteTemplate,
                                                                                         versionBuilderInfo => { versionBuilderInfo.Version("V2", "Partner API Write Back"); });
                                                swaggerConfiguration.CustomProvider(customProviderFactory => new CachedODataSwaggerProvider(customProviderFactory, swaggerConfiguration, httpConfiguration, swaggerExclusionPathFilters).Configure(odataConfig => { odataConfig.IncludeNavigationProperties(); }));
                                                swaggerConfiguration.OperationFilter<OperationFilter>();
                                                swaggerConfiguration.DocumentFilter<RewriteGetChangesDocumentFilter>();
                                                swaggerConfiguration.DocumentFilter<HideInSwaggerFilter>();
                                                swaggerConfiguration.DocumentFilter<SwaggerCustomPathNameFilter>();
                                                swaggerConfiguration.OperationFilter<SwaggerImplementationNotesFilter>();
                                            })
                             .EnableSwaggerUi();

            app.UseIdentityServerBearerTokenAuthentication(new IdentityServerBearerTokenAuthenticationOptions
                                                           {
                                                               Authority = SimsPrimaryConfiguration.IdentityProviderAuthority,
                                                               RequiredScopes = AttendanceShimApiConfiguration.RequiredScopes
                                                           })
               .UserHeaderSecurity(SimsPrimaryConfiguration.AzureApiManagementSharedSecret)
#if DEBUG
               .UseCors(CorsOptions.AllowAll)
#endif
               .UseWebApi(httpConfiguration);
        }
    }
}