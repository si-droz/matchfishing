﻿using Microsoft.Practices.Unity;
using PM.Attendance.Shim.Api.Controllers.V2;
using PM.Service.Shim;

namespace PM.Attendance.Shim.Api
{
    public static class WebBootstrapper
    {
        public static IUnityContainer RegisterWebDependencies(this IUnityContainer unityContainer)
        {
            return unityContainer
                .RegisterServiceShimDependencies()
                .RegisterType<AttendanceRecordsV2Controller>()
                .RegisterType<AttendanceBatchV2Controller>();
        }
    }
}