﻿namespace PM.Attendance.Shim.Api.Tests.Integration
{
    internal class JsonError
    {
        public Error error { get; set; }
    }

    internal class Error
    {
        public int code { get; set; }
        public string message { get; set; }
    }
}