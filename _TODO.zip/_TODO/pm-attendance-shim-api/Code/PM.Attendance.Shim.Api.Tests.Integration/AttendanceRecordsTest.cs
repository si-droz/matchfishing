﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using IdentityModel.Client;
using Newtonsoft.Json;
using NUnit.Framework;
using Shouldly;

namespace PM.Attendance.Shim.Api.Tests.Integration
{
    [TestFixture]
    public class AttendanceRecordsTest
    {
        private readonly string _endpointUrl = ConfigurationManager.AppSettings["PartnerAccess:EndpointUrl"];
        private readonly string _identityServerUrl = ConfigurationManager.AppSettings["PartnerAccess:IdentityServerUrl"];
        private readonly string _clientId = ConfigurationManager.AppSettings["PartnerAccess:ClientId"];
        private readonly string _secret = ConfigurationManager.AppSettings["PartnerAccess:Secret"];
        private readonly string _scope = ConfigurationManager.AppSettings["PartnerAccess:Scope"];
        private readonly string _subscriptionKey = ConfigurationManager.AppSettings["PartnerAccess:SubscriptionKey"];
        private readonly string _organisationId = ConfigurationManager.AppSettings["PartnerAccess:OrganisationId"];
        private readonly string _endpointSuffix = ConfigurationManager.AppSettings["PartnerAccess:EndpointSuffix"];
        private readonly string _apiPrefix = ConfigurationManager.AppSettings["PartnerAccess:ApiPrefix"];
        private readonly int _retries = int.Parse(ConfigurationManager.AppSettings["PartnerAccess:Retries"]);
        private readonly int _allowedDateRangeInDays = int.Parse(ConfigurationManager.AppSettings["OData:AllowedDateRangeInDays"]);
        private const string DateFormat = "yyyy-MM-ddTHH:mm:ssZ";

        private HttpClient _client;

        [SetUp]
        public async Task SetUp()
        {
            var tokenClient = new TokenClient(_identityServerUrl, _clientId, _secret);

            var extraParameters = new Dictionary<string, string>
                                  {
                                      {
                                          "acr_values",
                                          $"orgselected:{_organisationId}"
                                      }
                                  };

            var tokenResponse = await tokenClient.RequestClientCredentialsAsync(_scope, extraParameters);

            _client = new HttpClient();

            _client.DefaultRequestHeaders.Accept.Clear();
            _client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _subscriptionKey);
            _client.DefaultRequestHeaders.Add("Accept", "application/json");
            _client.BaseAddress = new Uri(_endpointUrl);
            _client.SetBearerToken(tokenResponse.AccessToken);
        }

        [TearDown]
        public void TearDown()
        {
            if(_client != null) _client.Dispose();
        }

        [TestCase("?$filter=AttendableEventStart gt {startDate} and AttendableEventStart lt {endDate}")]
        [TestCase("?$filter=AttendableEventStart lt {endDate} and AttendableEventStart gt {startDate}")]
        [TestCase("?$filter=AttendableEventStart gt {startDate} and AttendableEventStart lt {endDate}&$top=1")]
        [TestCase("?$filter=AttendableEventStart gt {startDate} and AttendableEventStart lt {endDate} and Present eq true")]
        [TestCase("?$filter=AttendableEventStart gt {startDate} and AttendableEventStart lt {endDate} and Present eq true&$top=1")]
        [TestCase("?$top=1&$filter=AttendableEventStart gt {startDate} and AttendableEventStart lt {endDate} and Present eq true")]
        public async Task AttendanceRecords_Should_Return_Ok_When_Filtered_By_AttendableEventStart(string filterQuery)
        {
            // Arrange
            filterQuery = filterQuery.Replace("{startDate}", DateTimeOffset.UtcNow.ToString(DateFormat))
                                     .Replace("{endDate}", DateTimeOffset.UtcNow.AddDays(1).ToString(DateFormat));

            string endPointPathAndQuery = $"{_apiPrefix}/V2/Attendance{_endpointSuffix}/AttendanceRecords{filterQuery}";

            TestContext.Out.WriteLine($"Calling Url: {_endpointUrl}/{endPointPathAndQuery}");

            // Act 
            HttpResponseMessage response = await RetryHelpers.GetRetryPolicy(_retries)
                                                             .ExecuteAsync(() => _client.GetAsync(endPointPathAndQuery));

            // Assert
            var content = await response.Content.ReadAsStringAsync();
            TestContext.Out.WriteLine($"Response status code: '{response.StatusCode}', Content: '{content}'");
            response.IsSuccessStatusCode.ShouldBeTrue();
            response.StatusCode.ShouldBe(HttpStatusCode.OK);
            content.ShouldNotBeNullOrEmpty();
        }

        [Test]
        public async Task AttendanceRecords_Get_Changes_Should_Return_Ok_When_Calling_GetChanges_Function()
        {
            var startDate = HttpUtility.UrlEncode(DateTimeOffset.UtcNow.ToString(DateFormat));
            var endDate = HttpUtility.UrlEncode(DateTimeOffset.UtcNow.AddDays(1).ToString(DateFormat));

            // Arrange
            string endPointPathAndQuery = $"{_apiPrefix}/V2/Attendance{_endpointSuffix}/AttendanceRecords/ChangeTracking.GetChanges(startDate=@startDate,endDate=@endDate)?@startDate={startDate}&@endDate={endDate}";

            TestContext.Out.WriteLine($"Calling Url: {_endpointUrl}/{endPointPathAndQuery}");

            // Act 
            HttpResponseMessage response = await RetryHelpers.GetRetryPolicy(_retries)
                                                             .ExecuteAsync(() => _client.GetAsync(endPointPathAndQuery));

            // Assert
            var content = await response.Content.ReadAsStringAsync();
            TestContext.Out.WriteLine($"Response status code: '{response.StatusCode}', Content: '{content}'");
            response.IsSuccessStatusCode.ShouldBeTrue();
            response.StatusCode.ShouldBe(HttpStatusCode.OK);
            content.ShouldNotBeNullOrEmpty();
        }

        [TestCase("", 0, "The request is too large. Please add the following filter conditions $filter=AttendableEventStart gt {date} and AttendableEventStart lt {date}")]
        [TestCase("?$filter=", 0, "The request is too large. Please add the following filter conditions $filter=AttendableEventStart gt {date} and AttendableEventStart lt {date}")]
        [TestCase("?$filter=AttendableEventStart eq ", 0, "The request is too large. Please add the following filter conditions $filter=AttendableEventStart gt {date} and AttendableEventStart lt {date}")]
        [TestCase("?$filter=AttendableEventStart gt {startDate}", 0, "The request is too large. Please add the following filter conditions $filter=AttendableEventStart gt {date} and AttendableEventStart lt {date}")]
        [TestCase("?$filter=AttendableEventStart gt {startDate} and AttendableEventStart eq {endDate}", 0, "The request is too large. Please add the following filter conditions $filter=AttendableEventStart gt {date} and AttendableEventStart lt {date}")]
        [TestCase("?$filter=AttendableEventStart gt {startDate} or AttendableEventStart lt {endDate}", 0, "'or' operators are not allowed in filter expressions for AttendanceRecords")]
        [TestCase("?$filter=AttendableEventStart gt {startDate} and AttendableEventStart lt {endDate}", 91, "Date range search cannot be a greater than {_allowedDateRangeInDays} days.")]
        public async Task AttendanceRecords_Should_Return_Bad_Request(string filterQuery, int daysOffSet, string errorMessage)
        {
            // Arrange
            if(!string.IsNullOrEmpty(filterQuery))
            {
                string startDate = DateTimeOffset.UtcNow.ToString(DateFormat);
                string endDate = DateTimeOffset.UtcNow.AddDays(daysOffSet).ToString(DateFormat);

                filterQuery = filterQuery.Replace("{startDate}", startDate)
                                         .Replace("{endDate}", endDate);
            }

            errorMessage = errorMessage.Replace("{_allowedDateRangeInDays}", _allowedDateRangeInDays.ToString());

            string endPointPathAndQuery = $"{_apiPrefix}/V2/Attendance{_endpointSuffix}/AttendanceRecords{filterQuery}";

            TestContext.Out.WriteLine($"Calling Url: {_endpointUrl}/{endPointPathAndQuery}");

            // Act
            HttpResponseMessage response = await RetryHelpers.GetRetryPolicy(_retries)
                                                             .ExecuteAsync(() => _client.GetAsync(endPointPathAndQuery));

            // Assert
            var content = await response.Content.ReadAsStringAsync();
            TestContext.Out.WriteLine($"Response status code: '{response.StatusCode}', Content: '{content}'");
            response.IsSuccessStatusCode.ShouldBeFalse();
            content.ShouldNotBeNullOrEmpty();
            JsonError jsonError = JsonConvert.DeserializeObject<JsonError>(content);
            jsonError.error.code.ShouldBe(400);
            jsonError.error.message.ShouldBe(errorMessage);
        }

        [TestCase("?$filter=AttendableEventStart gt {invalidDate} and AttendableEventStart lt {endDate}", "Invalid date found at AttendableEventStart gt {invalidDate}")]
        [TestCase("?$filter=AttendableEventStart gt {startDate} and AttendableEventStart lt {invalidDate}", "Invalid date found at AttendableEventStart lt {invalidDate}")]
        public async Task AttendanceRecords_Should_Return_Bad_Request_When_StartDate_Or_EndDate_Is_Invalid(string filterQuery, string errorMessage)
        {
            // Arrange
            const string invalidDateString = "2017-20-50T00:00:00Z";
            filterQuery = filterQuery.Replace("{invalidDate}", invalidDateString)
                                     .Replace("{startDate}", DateTimeOffset.UtcNow.ToString(DateFormat))
                                     .Replace("{endDate}", DateTimeOffset.UtcNow.ToString(DateFormat));

            errorMessage = errorMessage.Replace("{invalidDate}", invalidDateString);

            string endPointPathAndQuery = $"{_apiPrefix}/V2/Attendance{_endpointSuffix}/AttendanceRecords{filterQuery}";

            TestContext.Out.WriteLine($"Calling Url: {_endpointUrl}/{endPointPathAndQuery}");

            // Act
            HttpResponseMessage response = await RetryHelpers.GetRetryPolicy(_retries)
                                                             .ExecuteAsync(() => _client.GetAsync(endPointPathAndQuery));

            // Assert
            var content = await response.Content.ReadAsStringAsync();
            TestContext.Out.WriteLine($"Response status code: '{response.StatusCode}', Content: '{content}'");
            response.IsSuccessStatusCode.ShouldBeFalse();
            content.ShouldNotBeNullOrEmpty();
            JsonError jsonError = JsonConvert.DeserializeObject<JsonError>(content);
            jsonError.error.code.ShouldBe(400);
            jsonError.error.message.ShouldBe(errorMessage);
        }
    }
}