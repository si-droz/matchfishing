﻿using System;
using System.Net.Http;
using Polly;
using Polly.Retry;

namespace PM.Attendance.Shim.Api.Tests.Integration
{
    public static class RetryHelpers
    {
        public static RetryPolicy<HttpResponseMessage> GetRetryPolicy(int retries)
        {
            return Policy
                .Handle<Exception>()
                .OrResult<HttpResponseMessage>(message => !message.IsSuccessStatusCode)
                .WaitAndRetryAsync(retries, retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)));
        }
    }
}