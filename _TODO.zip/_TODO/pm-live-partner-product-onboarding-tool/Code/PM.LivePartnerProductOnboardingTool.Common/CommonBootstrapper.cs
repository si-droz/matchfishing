﻿using PM.LivePartnerProductOnboardingTool.Common.Implementation;
using Unity;
using Unity.Lifetime;

namespace PM.LivePartnerProductOnboardingTool.Common
{
    public static class CommonBootstrapper
    {
        public static IUnityContainer RegisterCommonDependencies(this IUnityContainer unityContainer)
        {
            return unityContainer.RegisterType<ISettingsProvider, AzureKeyVaultFallbackSettingsProvider>(new ContainerControlledLifetimeManager())
                                 .RegisterType<ISecurityProvider, AzureAdSecurityProvider>(new ContainerControlledLifetimeManager());
        }
    }
}