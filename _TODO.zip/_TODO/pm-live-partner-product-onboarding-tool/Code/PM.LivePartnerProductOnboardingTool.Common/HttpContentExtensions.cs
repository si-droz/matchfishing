﻿using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace PM.LivePartnerProductOnboardingTool.Common
{
    public static class HttpContentExtensions
    {
        public static async Task<T> ReadAsAsync<T>(this HttpContent httpContent)
        {
            string contentAsString = await httpContent.ReadAsStringAsync();
            return JsonConvert.DeserializeObject<T>(contentAsString);
        }
    }
}