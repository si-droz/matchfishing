﻿using System.Threading.Tasks;

namespace PM.LivePartnerProductOnboardingTool.Common
{
    public interface ISettingsProvider
    {
        Task<string> GetSettingValueAsync(string name);
    }
}