﻿using System;
using System.Configuration;
using System.Runtime.Caching;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Clients.ActiveDirectory;

namespace PM.LivePartnerProductOnboardingTool.Common.Implementation
{
    internal class AzureAdSecurityProvider : ISecurityProvider
    {
        private const string AccessTokenKey = "AcccessTokenKey";

        private readonly MemoryCache _accessTokenCache;

        public AzureAdSecurityProvider()
        {
            _accessTokenCache = new MemoryCache("AccessTokenMemoryCache");
        }

        public async Task<string> SignInAsync()
        {
            string azureAdAuthority = ConfigurationManager.AppSettings["AzureAD-Authority"];

            AuthenticationResult authenticationResult = await GetAzureAdAuthenticationResultAsync(azureAdAuthority, "https://vault.azure.net");

            string username = authenticationResult.UserInfo.DisplayableId;
            return username;
        }

        public async Task<string> GetAuthenticationResultAsync(string authority, string resource, string scope)
        {
            var accessToken = _accessTokenCache.Get(AccessTokenKey) as string;
            if(!string.IsNullOrWhiteSpace(accessToken)) return accessToken;

            AuthenticationResult authenticationResult = await GetAzureAdAuthenticationResultAsync(authority, resource);
            return authenticationResult.AccessToken;
        }

        private async Task<AuthenticationResult> GetAzureAdAuthenticationResultAsync(string authority, string resource)
        {
            string azureAppClientId = ConfigurationManager.AppSettings["AzureAD-KeyVaultApp-ClientId"];
            string azureAppRedirectUri = ConfigurationManager.AppSettings["AzureAD-KeyVaultApp-RedirectUri"];

            var authenticationContext = new AuthenticationContext(authority);
            AuthenticationResult authenticationResult = await authenticationContext.AcquireTokenAsync(resource,
                                                                                                      azureAppClientId,
                                                                                                      new Uri(azureAppRedirectUri),
                                                                                                      new PlatformParameters(PromptBehavior.SelectAccount));

            _accessTokenCache.Add(new CacheItem(AccessTokenKey, authenticationResult.AccessToken),
                                  new CacheItemPolicy
                                  {
                                      AbsoluteExpiration = authenticationResult.ExpiresOn.AddMinutes(-5)
                                  });
            return authenticationResult;
        }
    }
}