﻿using System.Configuration;
using System.Threading.Tasks;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.KeyVault.Models;

namespace PM.LivePartnerProductOnboardingTool.Common.Implementation
{
    internal class AzureKeyVaultFallbackSettingsProvider : ISettingsProvider
    {
        private readonly ISecurityProvider _securityProvider;

        public AzureKeyVaultFallbackSettingsProvider(ISecurityProvider securityProvider)
        {
            _securityProvider = securityProvider;
        }

        public async Task<string> GetSettingValueAsync(string name)
        {
            string appSetting = ConfigurationManager.AppSettings[name];
            if(string.IsNullOrWhiteSpace(appSetting))
            {
                var keyVaultClient = new KeyVaultClient(_securityProvider.GetAuthenticationResultAsync);
                string vaultBaseUrl = ConfigurationManager.AppSettings["KeyVault-BaseAddress"];
                SecretBundle secretBundle = await keyVaultClient.GetSecretAsync(vaultBaseUrl, name);
                appSetting = secretBundle.Value;
            }

            return appSetting;
        }
    }
}