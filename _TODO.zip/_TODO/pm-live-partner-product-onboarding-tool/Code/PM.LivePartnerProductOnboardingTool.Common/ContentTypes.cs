﻿namespace PM.LivePartnerProductOnboardingTool.Common
{
    public static class ContentTypes
    {
        public const string JsonContentType = "application/json";
    }
}