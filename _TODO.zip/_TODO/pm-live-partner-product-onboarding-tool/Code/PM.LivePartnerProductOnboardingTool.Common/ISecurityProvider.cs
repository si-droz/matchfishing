﻿using System.Threading.Tasks;

namespace PM.LivePartnerProductOnboardingTool.Common
{
    public interface ISecurityProvider
    {
        /// <summary>
        ///     Signs in and caches the security token
        /// </summary>
        /// <returns>The user name</returns>
        Task<string> SignInAsync();

        /// <summary>
        ///     Gets an Access Token.
        /// </summary>
        /// <returns>The Access Token</returns>
        Task<string> GetAuthenticationResultAsync(string authority, string resource, string scope);
    }
}