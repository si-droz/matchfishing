﻿using System.Threading.Tasks;

namespace PM.LivePartnerProductOnboardingTool.Storage.Table
{
    public interface ITableStore<T>
    {
        Task InitStorageAsync();

        Task<T> GetAsync(string key);
    }
}