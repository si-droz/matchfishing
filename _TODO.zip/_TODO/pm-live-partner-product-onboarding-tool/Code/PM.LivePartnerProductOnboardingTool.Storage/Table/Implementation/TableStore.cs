﻿using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Storage.Table.Implementation
{
    internal class TableStore : ITableStore<StorageConfigurationSetting>
    {
        private readonly ISettingsProvider _settingsProvider;
        private string _partitionKey;
        private string _connectionString;
        private CloudTable _table;

        public TableStore(ISettingsProvider settingsProvider)
        {
            _settingsProvider = settingsProvider;
        }

        public async Task InitStorageAsync()
        {
            _connectionString = await _settingsProvider.GetSettingValueAsync("Config-Storage-Connection-String");
            _partitionKey = await _settingsProvider.GetSettingValueAsync("Config-Partition-Key");
            string tableName = await _settingsProvider.GetSettingValueAsync("Config-Table-Name");

            CloudStorageAccount account = CloudStorageAccount.Parse(_connectionString);
            CloudTableClient client = account.CreateCloudTableClient();
            _table = client.GetTableReference(tableName);
        }

        public async Task<StorageConfigurationSetting> GetAsync(string key)
        {
            TableOperation get = TableOperation.Retrieve<StorageConfigurationSetting>(_partitionKey, key);
            TableResult result = await _table.ExecuteAsync(get);
            return (StorageConfigurationSetting) result.Result;
        }
    }
}