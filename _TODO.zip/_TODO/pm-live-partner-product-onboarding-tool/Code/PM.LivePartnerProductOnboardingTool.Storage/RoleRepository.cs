﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Storage
{
    public class RoleRepository
    {
        private readonly ISettingsProvider _settingsProvider;

        private Uri _serviceEndpoint;
        private string _resourceToken;
        private string _databaseId;
        private string _partnerApiRoleCollectionId;

        public RoleRepository(ISettingsProvider settingsProvider)
        {
            _settingsProvider = settingsProvider;
        }

        public async Task InitStorageAsync()
        {
            _serviceEndpoint = new Uri(await _settingsProvider.GetSettingValueAsync("CosmoDb-ServiceEndpoint"));
            _resourceToken = await _settingsProvider.GetSettingValueAsync("CosmoDb-ResourceToken");
            _databaseId = await _settingsProvider.GetSettingValueAsync("CosmoDb-DatabaseId");
            _partnerApiRoleCollectionId = await _settingsProvider.GetSettingValueAsync("CosmoDb-PartnerApiRoleCollectionId");

            using(DocumentClient documentClient = GetDocumentClient())
            {
                var collection = new DocumentCollection {Id = _partnerApiRoleCollectionId};
                await documentClient.CreateDatabaseIfNotExistsAsync(new Database {Id = _databaseId});
                await documentClient.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(_databaseId),
                                                                              collection,
                                                                              new RequestOptions {OfferThroughput = 400});
            }
        }

        private DocumentClient GetDocumentClient()
        {
            var documentClient = new DocumentClient(_serviceEndpoint, _resourceToken);
            return documentClient;
        }

        private Uri GetDocumentCollectionUri()
        {
            return UriFactory.CreateDocumentCollectionUri(_databaseId, _partnerApiRoleCollectionId);
        }

        public async Task<ApiRoleDefinition> GetApiRoleDefinition(string serviceName)
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                Uri documentUri = UriFactory.CreateDocumentUri(_databaseId, _partnerApiRoleCollectionId, serviceName);
                DocumentResponse<ApiRoleDefinition> documentResponse = await documentClient.ReadDocumentAsync<ApiRoleDefinition>(documentUri);
                return documentResponse.Document;
            }
        }

        public async Task SaveRolesAsync(string serviceName, IEnumerable<string> scopes, IEnumerable<string> roles)
        {
            var apiRoleDefinitions = new ApiRoleDefinition
                                     {
                                         ApiName = serviceName,
                                         Scopes = scopes,
                                         Roles = roles
                                     };

            using(DocumentClient documentClient = GetDocumentClient())
            {
                Uri documentCollectionUri = UriFactory.CreateDocumentCollectionUri(_databaseId, _partnerApiRoleCollectionId);
                await documentClient.CreateDocumentAsync(documentCollectionUri, apiRoleDefinitions);
            }
        }

        public async Task DeleteStorageAsync()
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                Uri documentCollectionUri = GetDocumentCollectionUri();
                await documentClient.DeleteDocumentCollectionAsync(documentCollectionUri);
            }
        }

        public async Task<IList<string>> GetApisAsync()
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                Uri collectionUri = GetDocumentCollectionUri();
                IDocumentQuery<ApiRoleDefinition> allPartnersDocumentQuery = documentClient.CreateDocumentQuery<ApiRoleDefinition>(collectionUri, new FeedOptions())
                                                                                           .AsDocumentQuery();
                var apis = new List<string>();
                while(allPartnersDocumentQuery.HasMoreResults)
                {
                    var apiRoleDefinitions = await allPartnersDocumentQuery.ExecuteNextAsync<ApiRoleDefinition>();
                    apis.AddRange(apiRoleDefinitions.Select(apiRole => apiRole.ApiName));
                }

                return apis;
            }
        }
    }
}