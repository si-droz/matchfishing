﻿using System.Collections.Generic;

namespace PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1
{
    public class SimsIdClientDetails
    {
        public string ClientId { get; set; }
        public string ClientType { get; set; }
        public IEnumerable<string> SharedSecrets { get; set; }
        public IEnumerable<string> Scopes { get; set; }
        public string VendorId { get; set; }
        public string VendorName { get; set; }
        public string ApplicationId { get; set; }
        public string ApplicationName { get; set; }
    }
}