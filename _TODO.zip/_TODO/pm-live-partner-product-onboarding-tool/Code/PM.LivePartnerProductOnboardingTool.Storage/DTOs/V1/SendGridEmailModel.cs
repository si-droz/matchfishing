﻿namespace PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1
{
    public class SendGridEmailModel
    {
        public SendGridEmailModel(string htmlText, string plainText, string subject, string to)
        {
            HtmlText = htmlText;
            PlainText = plainText;
            Subject = subject;
            To = to;
        }

        public string HtmlText { get; }
        public string PlainText { get; }
        public string Subject { get; }
        public string To { get; }
    }
}