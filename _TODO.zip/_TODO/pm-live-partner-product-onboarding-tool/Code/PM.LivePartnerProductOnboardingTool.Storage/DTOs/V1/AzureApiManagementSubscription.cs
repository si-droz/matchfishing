﻿namespace PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1
{
    public class AzureApiManagementSubscription
    {
        public string Id { get; set; }
        public string UserId { get; set; }
        public string ProductId { get; set; }
        public string Name { get; set; }
        public string PrimaryKey { get; set; }
    }
}