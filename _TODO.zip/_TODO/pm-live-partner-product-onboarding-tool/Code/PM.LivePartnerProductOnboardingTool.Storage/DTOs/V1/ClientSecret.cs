﻿using System.Collections.Generic;

namespace PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1
{
    public class ClientSecret
    {
        public ClientSecret(string clientId, string clientFriendlyName, string clientType, IEnumerable<string> scopes, IEnumerable<string> secrets)
        {
            ClientId = clientId;
            ClientFriendlyName = clientFriendlyName;
            ClientType = clientType;
            Scopes = scopes;
            Secrets = secrets;
        }

        public string ClientId { get; }
        public string ClientFriendlyName { get; }
        public string ClientType { get; }
        public IEnumerable<string> Secrets { get; }
        public IEnumerable<string> Scopes { get; }
    }
}