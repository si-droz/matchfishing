﻿using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;
using PM.LivePartnerProductOnboardingTool.Storage.Table.Implementation;
using Unity;
using Unity.Lifetime;

namespace PM.LivePartnerProductOnboardingTool.Storage
{
    public static class StorageBootstrapper
    {
        public static IUnityContainer RegisterStorageDependencies(this IUnityContainer unityContainer)
        {
            return unityContainer.RegisterType<PartnerRepository>(new ContainerControlledLifetimeManager())
                                 .RegisterType<RoleRepository>(new ContainerControlledLifetimeManager())
                                 .RegisterType<ITableStore<StorageConfigurationSetting>, TableStore>();
        }
    }
}