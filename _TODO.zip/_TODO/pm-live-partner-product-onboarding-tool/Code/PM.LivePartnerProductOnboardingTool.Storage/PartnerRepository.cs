﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Storage
{
    public class PartnerRepository
    {
        private readonly ISettingsProvider _settingsProvider;
        private Uri _serviceEndpoint;
        private string _resourceToken;
        private string _databaseId;
        private string _partnerProductCollectionId;

        public PartnerRepository(ISettingsProvider settingsProvider)
        {
            _settingsProvider = settingsProvider;
        }

        public async Task InitStorageAsync()
        {
            _serviceEndpoint = new Uri(await _settingsProvider.GetSettingValueAsync("CosmoDb-ServiceEndpoint"));
            _resourceToken = await _settingsProvider.GetSettingValueAsync("CosmoDb-ResourceToken");
            _databaseId = await _settingsProvider.GetSettingValueAsync("CosmoDb-DatabaseId");
            _partnerProductCollectionId = await _settingsProvider.GetSettingValueAsync("CosmoDb-PartnerProductCollectionId");

            using(DocumentClient documentClient = GetDocumentClient())
            {
                var collection = new DocumentCollection { Id = _partnerProductCollectionId };
                await documentClient.CreateDatabaseIfNotExistsAsync(new Database { Id = _databaseId });
                await documentClient.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(_databaseId),
                                                                              collection,
                                                                              new RequestOptions { OfferThroughput = 400 });
            }
        }

        public async Task<IEnumerable<Partner>> GetPartnersAsync()
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                Uri collectionUri = GetDocumentCollectionUri();
                IDocumentQuery<Partner> allPartnersDocumentQuery = documentClient.CreateDocumentQuery<Partner>(collectionUri, new FeedOptions())
                                                                                 .AsDocumentQuery();
                var partners = new List<Partner>();
                while(allPartnersDocumentQuery.HasMoreResults)
                {
                    partners.AddRange(await allPartnersDocumentQuery.ExecuteNextAsync<Partner>());
                }

                return partners;
            }
        }

        public async Task CreatePartnerAsync(Partner partner)
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                await documentClient.CreateDocumentAsync(GetDocumentCollectionUri(),
                                                         partner);
            }
        }

        public async Task<Partner> GetPartnerAsync(string partnerId)
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                Uri documentUri = UriFactory.CreateDocumentUri(_databaseId, _partnerProductCollectionId, partnerId);
                DocumentResponse<Partner> documentResponse = await documentClient.ReadDocumentAsync<Partner>(documentUri);
                return documentResponse.Document;
            }
        }

        public async Task UpdatePartnerAsync(Partner partner)
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                await documentClient.ReplaceDocumentAsync(UriFactory.CreateDocumentUri(_databaseId, _partnerProductCollectionId, partner.Id), partner, new RequestOptions
                                                                                                                                                       {
                                                                                                                                                           AccessCondition = new AccessCondition
                                                                                                                                                                             {
                                                                                                                                                                                 Condition = partner.ETag,
                                                                                                                                                                                 Type = AccessConditionType.IfMatch
                                                                                                                                                                             }
                                                                                                                                                       });
            }
        }

        public async Task DeleteStorageAsync()
        {
            using(DocumentClient documentClient = GetDocumentClient())
            {
                Uri documentCollectionUri = GetDocumentCollectionUri();
                await documentClient.DeleteDocumentCollectionAsync(documentCollectionUri);
            }
        }

        private DocumentClient GetDocumentClient()
        {
            var documentClient = new DocumentClient(_serviceEndpoint, _resourceToken);
            return documentClient;
        }

        private Uri GetDocumentCollectionUri()
        {
            return UriFactory.CreateDocumentCollectionUri(_databaseId, _partnerProductCollectionId);
        }
    }
}