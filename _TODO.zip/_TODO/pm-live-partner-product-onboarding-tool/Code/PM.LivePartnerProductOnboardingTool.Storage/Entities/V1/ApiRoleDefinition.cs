﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace PM.LivePartnerProductOnboardingTool.Storage.Entities.V1
{
    public class ApiRoleDefinition
    {
        [JsonProperty("id")]
        public string ApiName { get; set; }

        public IEnumerable<string> Scopes { get; set; }

        public IEnumerable<string> Roles { get; set; }
    }
}