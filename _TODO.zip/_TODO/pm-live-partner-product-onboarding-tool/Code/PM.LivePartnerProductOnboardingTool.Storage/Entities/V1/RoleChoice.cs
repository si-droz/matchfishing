﻿namespace PM.LivePartnerProductOnboardingTool.Storage.Entities.V1
{
    public class RoleChoice
    {
        public bool Selected { get; set; }
        public string Value { get; set; }
    }
}