﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace PM.LivePartnerProductOnboardingTool.Storage.Entities.V1
{
    public class Partner
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        public string Name { get; set; }
        public DateTime Created { get; set; }

        public Contact Contact { get; set; }

        public List<Product> Products { get; set; }

        [JsonProperty("_etag")]
        public string ETag { get; set; }
    }

    public class Contact
    {
        public string Title { get; set; }
        public string Forename { get; set; }
        public string Surname { get; set; }
        public string WorkEmail { get; set; }
    }

    public class Product
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public DateTime Created { get; set; }
        public List<ClientTemplate> ClientTemplates { get; set; }
        public List<ProductInstance> ProductInstances { get; set; }
    }

    public class ClientTemplate
    {
        public string Id { get; set; }
        public string FriendlyName { get; set; }
        public DateTime Created { get; set; }
        public ClientType ClientType { get; set; }
        public string ApiType { get; set; }
        public List<string> AccessibleScopes { get; set; }
        public IEnumerable<string> AssociatedSecurityPrinciples { get; set; }
    }

    public class ProductInstance
    {
        public DateTime Created { get; set; }
        public string Name { get; set; }
        public List<ClientInstance> ClientInstances { get; set; }
        public List<AssociatedOrganisation> AssociatedOrganisations { get; set; }
    }

    public class AssociatedOrganisation
    {
        public DateTime Created { get; set; }
        public string Name { get; set; }
        public string Id { get; set; }
        public string OrganisationId { get; set; }
        public bool IsActive { get; set; }
    }

    public class ClientInstance
    {
        public DateTime Created { get; set; }
        public string ClientId { get; set; }
        public string CreatedFromTemplateId { get; set; }
        public string AzureApiManagementUserId { get; set; }
        public string AzureApiManagementSubscriptionId { get; set; }
    }

    public enum ClientType
    {
        ClientCredential
    }
}