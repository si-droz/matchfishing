﻿using Microsoft.WindowsAzure.Storage.Table;

namespace PM.LivePartnerProductOnboardingTool.Storage.Entities.V1
{
    public class StorageConfigurationSetting : TableEntity
    {
        public string Value { get; set; }
    }
}