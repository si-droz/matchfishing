﻿using System.Configuration;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration
{
    internal static class AzureApiManagementService
    {
        private static readonly string ManagementApiBaseUri = ConfigurationManager.AppSettings["AzureApiManagement-ManagementApi-BaseUri"];

        public static async Task CreateUser(IHttpClientFactory httpClientFactory, AzureApiUser user, string userId)
        {
            var userUri = string.Format(ManagementApiBaseUri, $"/users/{userId}");
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                string newUserAsJson = JsonConvert.SerializeObject(user);
                HttpResponseMessage response = await httpClient.PutAsync(userUri, new StringContent(newUserAsJson,
                                                                                                    Encoding.UTF8,
                                                                                                    ContentTypes.JsonContentType));
                response.EnsureSuccessStatusCode();
            }
        }

        public static async Task DeleteUserAndAssociatedSubscriptions(IHttpClientFactory httpClientFactory, string userId)
        {
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                var userUri = string.Format($"{ManagementApiBaseUri}&deleteSubscriptions=true", $"/users/{userId}");
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("if-match", "*");
                await httpClient.DeleteAsync(userUri);
            }
        }

        public static async Task<HttpResponseMessage> GetUser(IHttpClientFactory httpClientFactory, string userId)
        {
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                var userUri = string.Format(ManagementApiBaseUri, $"/users/{userId}");
                HttpResponseMessage response = await httpClient.GetAsync(userUri);
                return response;
            }
        }

        public static async Task CreateSubscription(IHttpClientFactory httpClientFactory, AzureApiSubscription subscription, string subscriptionId)
        {
            var userUri = string.Format(ManagementApiBaseUri, $"/subscriptions/{subscriptionId}");
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                string newUserAsJson = JsonConvert.SerializeObject(subscription);
                HttpResponseMessage response = await httpClient.PutAsync(userUri, new StringContent(newUserAsJson,
                                                                                                    Encoding.UTF8,
                                                                                                    ContentTypes.JsonContentType));
                response.EnsureSuccessStatusCode();
            }
        }

        public static async Task DeleteSubscription(IHttpClientFactory httpClientFactory, string subscriptionId)
        {
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                var subscriptionUri = string.Format(ManagementApiBaseUri, $"/subscriptions/{subscriptionId}");
                httpClient.DefaultRequestHeaders.TryAddWithoutValidation("if-match", "*");
                await httpClient.DeleteAsync(subscriptionUri);
            }
        }

        public static async Task<HttpResponseMessage> GetSubscription(IHttpClientFactory httpClientFactory, string subscriptionId)
        {
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                var subscriptionUri = string.Format(ManagementApiBaseUri, $"/subscriptions/{subscriptionId}");
                HttpResponseMessage response = await httpClient.GetAsync(subscriptionUri);
                return response;
            }
        }

        public static async Task<HttpResponseMessage> GetAllSubscriptions(IHttpClientFactory httpClientFactory)
        {
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                var subscriptionUri = string.Format(ManagementApiBaseUri, "/subscriptions");
                HttpResponseMessage response = await httpClient.GetAsync(subscriptionUri);
                return response;
            }
        }
    }
}