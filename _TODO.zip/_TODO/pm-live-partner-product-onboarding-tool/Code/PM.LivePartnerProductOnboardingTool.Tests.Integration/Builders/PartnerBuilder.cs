﻿using System;
using System.Collections.Generic;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders
{
    internal class PartnerBuilder
    {
        private string _partnerName = "Test Partner";
        private string _productName = "Test Product";
        private string _productInstanceName = "Test Product Instance";
        private string _partnerId = Guid.NewGuid().ToString();
        private string _organisationName = TestingIdentities.OrganisationName;
        private string _organisationId = TestingIdentities.OrganisationId;
        private string _clientId = Guid.NewGuid().ToString();
        private string _contactForename = "Test Partner Contact Forename";
        private string _contactSurname = "Test Partner Contact Surname";
        private string _contactTitle = "Test Partner Contact Title";
        private string _contactEmail = "test.partner@email.com";
        private string _clientTemplateId = Guid.NewGuid().ToString();
        private bool _associatedOrganisationIsActive = true;
        private DateTime _createdOn;

        public PartnerBuilder WithPartnerName(string name)
        {
            _partnerName = name;
            return this;
        }

        public PartnerBuilder WithProductName(string name)
        {
            _productName = name;
            return this;
        }

        public PartnerBuilder WithProductInstanceName(string name)
        {
            _productInstanceName = name;
            return this;
        }

        public PartnerBuilder WithPartnerId(string id)
        {
            _partnerId = id;
            return this;
        }

        public PartnerBuilder WithOrganisationId(string id)
        {
            _organisationId = id;
            return this;
        }

        public PartnerBuilder WithOrganisationName(string name)
        {
            _organisationName = name;
            return this;
        }

        public PartnerBuilder WithClientId(string id)
        {
            _clientId = id;
            return this;
        }

        public PartnerBuilder WithAssociatedOrganisationIsActive(bool isActive)
        {
            _associatedOrganisationIsActive = isActive;
            return this;
        }

        public PartnerBuilder WithContact(string title, string forename, string surname, string email)
        {
            _contactTitle = title;
            _contactForename = forename;
            _contactSurname = surname;
            _contactEmail = email;
            return this;
        }

        public PartnerBuilder WithClientTemplateId(string clientTemplateId)
        {
            _clientTemplateId = clientTemplateId;
            return this;
        }

        public Partner Build()
        {
            _createdOn = DateTime.UtcNow;

            var associatedOrganisations = CreateAssociatedOrganisations();

            var clientInstance = CreateClientInstance();

            var productInstances = CreateProductInstances(associatedOrganisations, clientInstance);

            var clientTemplates = CreateClientTemplate();

            var products = CreateProducts(productInstances, clientTemplates);

            var partner = CreatePartner(products);

            return partner;
        }

        private List<ClientInstance> CreateClientInstance()
        {
            var clientInstance = new List<ClientInstance>
                                 {
                                     new ClientInstance
                                     {
                                         Created = _createdOn,
                                         AzureApiManagementSubscriptionId = "Subscription Id",
                                         AzureApiManagementUserId = "User Id",
                                         ClientId = _clientId,
                                         CreatedFromTemplateId = _clientTemplateId
                                     }
                                 };

            return clientInstance;
        }

        private List<ClientTemplate> CreateClientTemplate()
        {
            var clientTemplate = new List<ClientTemplate>
                                 {
                                     new ClientTemplate
                                     {
                                         Created = _createdOn,
                                         AccessibleScopes = new List<string> {"partner", "simsserverapplication"},
                                         ClientType = ClientType.ClientCredential,
                                         FriendlyName = "Test Client Friendly Name",
                                         Id = _clientTemplateId
                                     }
                                 };

            return clientTemplate;
        }

        private Partner CreatePartner(List<Product> products)
        {
            var partner = new Partner
                          {
                              Id = _partnerId,
                              Name = _partnerName,
                              Created = _createdOn,
                              Products = products,
                              Contact = new Contact
                                        {
                                            Title = _contactTitle,
                                            Forename = _contactForename,
                                            Surname = _contactSurname,
                                            WorkEmail = _contactEmail
                                        }
                          };
            return partner;
        }

        private List<Product> CreateProducts(List<ProductInstance> productInstances, List<ClientTemplate> clientTemplates)
        {
            var products = new List<Product>
                           {
                               new Product
                               {
                                   Name = _productName,
                                   Created = _createdOn,
                                   ProductInstances = productInstances,
                                   ClientTemplates = clientTemplates
                               }
                           };
            return products;
        }

        private List<ProductInstance> CreateProductInstances(List<AssociatedOrganisation> associatedOrganisations, List<ClientInstance> clientInstances)
        {
            var productInstances = new List<ProductInstance>
                                   {
                                       new ProductInstance
                                       {
                                           Name = _productInstanceName,
                                           Created = _createdOn,
                                           AssociatedOrganisations = associatedOrganisations,
                                           ClientInstances = clientInstances
                                       }
                                   };
            return productInstances;
        }

        private List<AssociatedOrganisation> CreateAssociatedOrganisations()
        {
            var associatedOrganisations = new List<AssociatedOrganisation>
                                          {
                                              new AssociatedOrganisation
                                              {
                                                  Created = _createdOn,
                                                  Name = _organisationName,
                                                  OrganisationId = _organisationId,
                                                  IsActive = _associatedOrganisationIsActive
                                              }
                                          };
            return associatedOrganisations;
        }
    }
}