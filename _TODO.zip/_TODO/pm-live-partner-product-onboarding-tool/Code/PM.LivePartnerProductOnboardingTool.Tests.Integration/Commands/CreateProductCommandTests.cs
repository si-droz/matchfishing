﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Commands
{
    [TestFixture]
    public class CreateProductCommandTests
    {
        private IUnityContainer _unityContainer;
        private Partner _partner;
        private PartnerRepository _partnerRepository;

        [SetUp]
        public async Task Setup()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _partnerRepository = _unityContainer.Resolve<PartnerRepository>();
            await _partnerRepository.InitStorageAsync();

            _partner = new PartnerBuilder().Build();
            _partner.Products.Clear();

            await _partnerRepository.CreatePartnerAsync(_partner);
        }

        [Test]
        public async Task ExecuteAsync_WhenProvidedWithAValidProductName_AssociatesProductToPartner()
        {
            string expectedProductName = $"Product {Guid.NewGuid()}";
            var inputManagerMock = new Mock<IInputOutputManager>();
            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInput(CreateProductCommand.WhatIsTheProductNameQuestion, It.IsAny<Predicate<string>>()))
            .Returns(expectedProductName);

            _unityContainer.RegisterInstance(inputManagerMock.Object);

            var commandFactory = _unityContainer.Resolve<CommandFactory>();
            Command command = commandFactory.GetCreateProductCommand(_partner);
            await command.ExecuteAsync();

            Partner partnerUnderInspection = await _partnerRepository.GetPartnerAsync(_partner.Id);

            partnerUnderInspection.ShouldNotBeNull();
            partnerUnderInspection.Products.ShouldNotBeNull();
            partnerUnderInspection.Products.Count.ShouldBe(1);
            Product selectedPartnerProduct = partnerUnderInspection.Products.First();
            selectedPartnerProduct.Id.ShouldNotBeNullOrWhiteSpace();
            selectedPartnerProduct.Id.ShouldNotBe(Guid.Empty.ToString());
            selectedPartnerProduct.Name.ShouldBe(expectedProductName);
            selectedPartnerProduct.Created.ShouldBeInRange(DateTime.UtcNow.AddSeconds(-10), DateTime.UtcNow);
            selectedPartnerProduct.ClientTemplates.ShouldBeNull();
            selectedPartnerProduct.ProductInstances.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            await _partnerRepository.DeleteStorageAsync();
        }
    }
}