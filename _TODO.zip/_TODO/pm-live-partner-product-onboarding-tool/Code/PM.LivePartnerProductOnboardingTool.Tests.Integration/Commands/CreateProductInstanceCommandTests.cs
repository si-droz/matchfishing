﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Commands
{
    [TestFixture]
    public class CreateProductInstanceCommandTests
    {
        private IUnityContainer _unityContainer;
        private PartnerRepository _partnerRepository;

        [SetUp]
        public async Task Setup()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _partnerRepository = _unityContainer.Resolve<PartnerRepository>();
            await _partnerRepository.InitStorageAsync();
        }

        [Test]
        public async Task WhenExecuted_AndAllActivityTasksExecuteSuccessfully_TheProductIsUpdatedWithTheProductInstanceInformation()
        {
            var firstClientTemplate = new ClientTemplate
                                      {
                                          Id = Guid.NewGuid().ToString(),
                                          Created = DateTime.UtcNow,
                                          ApiType = "SIMS ID API",
                                          AccessibleScopes = new List<string> {"partner"},
                                          AssociatedSecurityPrinciples = new List<string> {"Role1", "Role2", "Role2"},
                                          ClientType = ClientType.ClientCredential,
                                          FriendlyName = "Service 1 Client"
                                      };
            var secondClientTemplate = new ClientTemplate
                                       {
                                           Id = Guid.NewGuid().ToString(),
                                           Created = DateTime.UtcNow,
                                           ApiType = "SIMS ID API",
                                           AccessibleScopes = new List<string> {"partner"},
                                           AssociatedSecurityPrinciples = new List<string> {"Role1", "Role2", "Role2"},
                                           ClientType = ClientType.ClientCredential,
                                           FriendlyName = "Service 2 Client"
                                       };

            var partner = new PartnerBuilder().Build();
            var firstProduct = partner.Products.First();
            firstProduct.ClientTemplates.Clear();

            firstProduct.ClientTemplates.Add(firstClientTemplate);
            firstProduct.ClientTemplates.Add(secondClientTemplate);

            firstProduct.ProductInstances.Clear();

            await _partnerRepository.CreatePartnerAsync(partner);

            var activityTaskFactoryMock = new Mock<IActivityTaskFactory>();
            var firstClientTemplateCreationActivityTaskMock = new MockActivityTask($"1 ClientId{Guid.NewGuid()}", $"1 AzureManagementApiUserId {Guid.NewGuid()}", $"1 AzureManagementApiSubscriptionId {Guid.NewGuid()}");
            var secondClientTemplateCreationActivityTaskMock = new MockActivityTask($"2 ClientId{Guid.NewGuid()}", $"2 AzureManagementApiUserId {Guid.NewGuid()}", $"2 AzureManagementApiSubscriptionId {Guid.NewGuid()}");
            activityTaskFactoryMock.Setup(x => x.GetCreateClientInstanceActivityTasks(firstClientTemplate))
                                   .Returns(new List<ActivityTask<CreateClientTemplateInstanceContext>> {firstClientTemplateCreationActivityTaskMock});
            activityTaskFactoryMock.Setup(x => x.GetCreateClientInstanceActivityTasks(secondClientTemplate))
                                   .Returns(new List<ActivityTask<CreateClientTemplateInstanceContext>> {secondClientTemplateCreationActivityTaskMock});
            _unityContainer.RegisterInstance(activityTaskFactoryMock.Object);

            var inputManagerMock = new Mock<IInputOutputManager>();
            string expectedProductInstanceName = $"Tests Instance {Guid.NewGuid()}";
            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInput(CreateProductInstanceCommand.WhatIsTheNameOfThisProductInstanceQuestion, It.IsAny<Predicate<string>>()))
                            .Returns(expectedProductInstanceName);

            _unityContainer.RegisterInstance(inputManagerMock.Object);

            var commandFactory = _unityContainer.Resolve<CommandFactory>();
            Command createProductInstanceCommand = commandFactory.GetCreateProductInstanceCommand(partner, partner.Products.First());
            await createProductInstanceCommand.ExecuteAsync();

            Partner updatedPartner = await _partnerRepository.GetPartnerAsync(partner.Id);
            Product updatedProduct = updatedPartner.Products.First();
            updatedProduct.ProductInstances.Count.ShouldBe(1);
            ProductInstance productInstance = updatedProduct.ProductInstances.First();
            productInstance.Name.ShouldBe(expectedProductInstanceName);
            productInstance.ClientInstances.Count.ShouldBe(2);

            ClientInstance firstClientInstance = productInstance.ClientInstances[0];
            firstClientInstance.Created.ShouldBeInRange(DateTime.UtcNow.AddSeconds(-10), DateTime.UtcNow);
            firstClientInstance.ClientId.ShouldBe(firstClientTemplateCreationActivityTaskMock.ClientId);
            firstClientInstance.AzureApiManagementUserId.ShouldBe(firstClientTemplateCreationActivityTaskMock.AzureManagementApiUserId);
            firstClientInstance.AzureApiManagementSubscriptionId.ShouldBe(firstClientTemplateCreationActivityTaskMock.AzureManagementApiSubscriptionId);
            firstClientInstance.CreatedFromTemplateId.ShouldBe(firstClientTemplate.Id);

            ClientInstance secondClientInstance = productInstance.ClientInstances[1];
            secondClientInstance.Created.ShouldBeInRange(DateTime.UtcNow.AddSeconds(-10), DateTime.UtcNow);
            secondClientInstance.ClientId.ShouldBe(secondClientTemplateCreationActivityTaskMock.ClientId);
            secondClientInstance.AzureApiManagementUserId.ShouldBe(secondClientTemplateCreationActivityTaskMock.AzureManagementApiUserId);
            secondClientInstance.AzureApiManagementSubscriptionId.ShouldBe(secondClientTemplateCreationActivityTaskMock.AzureManagementApiSubscriptionId);
            secondClientInstance.CreatedFromTemplateId.ShouldBe(secondClientTemplate.Id);
        }

        private class MockActivityTask : ActivityTask<CreateClientTemplateInstanceContext>
        {
            public string ClientId { get; }
            public string AzureManagementApiUserId { get; }
            public string AzureManagementApiSubscriptionId { get; }

            public MockActivityTask(string clientId,
                                    string azureManagementApiUserId,
                                    string azureManagementApiSubscriptionId) : base("Test task")
            {
                ClientId = clientId;
                AzureManagementApiUserId = azureManagementApiUserId;
                AzureManagementApiSubscriptionId = azureManagementApiSubscriptionId;
            }

            protected override Task<ActivityTaskOutcome> ExecuteAsync(CreateClientTemplateInstanceContext context)
            {
                context.ClientId = ClientId;
                context.AzureManagementApiUserId = AzureManagementApiUserId;
                context.AzureManagementApiSubscriptionId = AzureManagementApiSubscriptionId;
                return Task.FromResult(new ActivityTaskOutcome(true));
            }

            protected override Task<ActivityTaskOutcome> CompensateAsync(CreateClientTemplateInstanceContext context)
            {
                throw new NotImplementedException();
            }
        }

        [TearDown]
        public async Task TearDown()
        {
            await _partnerRepository.DeleteStorageAsync();
        }
    }
}