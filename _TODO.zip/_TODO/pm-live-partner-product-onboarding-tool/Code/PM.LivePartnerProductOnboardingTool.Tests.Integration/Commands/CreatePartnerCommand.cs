﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Commands
{
    [TestFixture]
    public class CreatePartnerCommandTests
    {
        private IUnityContainer _unityContainer;
        private PartnerRepository _partnerRepository;

        [SetUp]
        public async Task Setup()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();


            _partnerRepository = _unityContainer.Resolve<PartnerRepository>();
            await _partnerRepository.InitStorageAsync();
        }

        [Test]
        public async Task Execute_WhenSuppliedWithAValidPartnerName_WritesPartnerToStorage()
        {
            string expectedPartnerName = $"Partner {Guid.NewGuid()}";
            string expectedContactTitle = "Test Title";
            string expectedContactForename = "Test Forename";
            string expectedContactSurname = "Test Surname";
            string expectedContactWorkEmail = "test.email@domain.com";

            var inputManagerMock = new Mock<IInputOutputManager>();
            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInputAsync(CreatePartnerCommand.WhatIsThePartnersNameQuestion, It.IsAny<AsyncPredicate<string>>()))
                            .ReturnsAsync(expectedPartnerName);

            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInput(CreatePartnerCommand.WhatIsThePartnersContactTitleQuestion, It.IsAny<Predicate<string>>()))
                            .Returns(expectedContactTitle);

            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInput(CreatePartnerCommand.WhatIsThePartnersContactForenameQuestion, It.IsAny<Predicate<string>>()))
                            .Returns(expectedContactForename);

            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInput(CreatePartnerCommand.WhatIsThePartnersContactSurnameQuestion, It.IsAny<Predicate<string>>()))
                            .Returns(expectedContactSurname);

            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInput(CreatePartnerCommand.WhatIsThePartnersContactWorkEmailQuestion, It.IsAny<Predicate<string>>()))
                            .Returns(expectedContactWorkEmail);

            _unityContainer.RegisterInstance(inputManagerMock.Object);

            var command = _unityContainer.Resolve<CreatePartnerCommand>();
            await command.ExecuteAsync();

            IEnumerable<Partner> returnedPartners = await _partnerRepository.GetPartnersAsync();

            returnedPartners.ShouldNotBeNull();
            var returnedPartnersAsList = new List<Partner>(returnedPartners);
            returnedPartnersAsList.Count.ShouldBe(1);
            Partner partnerUnderInspection = returnedPartnersAsList[0];
            partnerUnderInspection.Id.ShouldNotBeNullOrWhiteSpace();
            partnerUnderInspection.Id.ShouldNotBe(Guid.Empty.ToString());
            partnerUnderInspection.Created.ShouldBeInRange(DateTime.UtcNow.AddSeconds(-10), DateTime.UtcNow);
            partnerUnderInspection.Name.ShouldBe(expectedPartnerName);
            partnerUnderInspection.Contact.ShouldNotBeNull();
            partnerUnderInspection.Contact.Title.ShouldBe(expectedContactTitle);
            partnerUnderInspection.Contact.Forename.ShouldBe(expectedContactForename);
            partnerUnderInspection.Contact.Surname.ShouldBe(expectedContactSurname);
            partnerUnderInspection.Contact.WorkEmail.ShouldBe(expectedContactWorkEmail);
            partnerUnderInspection.Products.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            await _partnerRepository.DeleteStorageAsync();
        }
    }
}