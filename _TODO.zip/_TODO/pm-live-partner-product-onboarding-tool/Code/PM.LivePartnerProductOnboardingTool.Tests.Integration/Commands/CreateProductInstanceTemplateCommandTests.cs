﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Moq;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Commands
{
    [TestFixture]
    public class CreateProductInstanceTemplateCommandTests
    {
        private IUnityContainer _unityContainer;
        private PartnerRepository _partnerRepository;
        private Partner _partner;
        private RoleRepository _roleRepository;
        private ReadOnlyCollection<string> _roles;
        private ReadOnlyCollection<string> _scopes;

        [SetUp]
        public async Task Setup()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _partnerRepository = _unityContainer.Resolve<PartnerRepository>();
            await _partnerRepository.InitStorageAsync();

            _partner = new PartnerBuilder().Build();
            _partner.Products.First().ClientTemplates.Clear();

            await _partnerRepository.CreatePartnerAsync(_partner);

            _roleRepository = _unityContainer.Resolve<RoleRepository>();
            await _roleRepository.InitStorageAsync();

            _roles = new List<string> {"Role1", "Role2", "Role3"}.AsReadOnly();
            _scopes = new List<string> {"partner", "simsserverapplication"}.AsReadOnly();
            await _roleRepository.SaveRolesAsync(ApiTypes.SimsPrimaryApi, _scopes, _roles);
        }

        [Test]
        public async Task ExecuteAsync_WhenProvidedWithAValidNumberOfClients_CreatesProductInstanceTemplateWithTheCorrectNumberOfClientCredentials()
        {
            const int clientCredentialTemplateCount = 1;

            string clientCredentialCount = clientCredentialTemplateCount.ToString();
            var inputManagerMock = new Mock<IInputOutputManager>();
            inputManagerMock.Setup(mock => mock.AskQuestionAndWaitForStringInput(CreateClientTemplateCommand.HowManyClientCredentialTypeClientsAreRequiredQuestion))
                            .Returns(clientCredentialCount);

            inputManagerMock.Setup(mock => mock.DisplayListAndWaitForSingleSelection(It.IsAny<string>(), It.IsAny<IList<string>>()))
                            .Returns(ApiTypes.SimsPrimaryApi);

            inputManagerMock.Setup(mock => mock.DisplayListAndWaitForConfirmation(It.IsAny<string>(), _roles))
                            .Returns(_roles);

            _unityContainer.RegisterInstance(inputManagerMock.Object);

            var commandFactory = _unityContainer.Resolve<CommandFactory>();
            Command command = commandFactory.GetCreateProductInstanceTemplateCommand(_partner, _partner.Products.First());

            await command.ExecuteAsync();

            Partner partnerUnderInspection = await _partnerRepository.GetPartnerAsync(_partner.Id);
            Product productUnderInspection = partnerUnderInspection.Products.FirstOrDefault();
            productUnderInspection.ShouldNotBeNull();
            productUnderInspection.ClientTemplates.Count.ShouldBe(clientCredentialTemplateCount);
            foreach(ClientTemplate clientTemplate in productUnderInspection.ClientTemplates)
            {
                clientTemplate.Id.ShouldNotBeNullOrWhiteSpace();
                clientTemplate.Id.ShouldNotBe(Guid.Empty.ToString());
                clientTemplate.ClientType.ShouldBe(ClientType.ClientCredential);
                clientTemplate.AccessibleScopes.ShouldContain(scope => scope == "partner");
                clientTemplate.AccessibleScopes.ShouldContain(scope => scope == "simsserverapplication");
                clientTemplate.Created.ShouldBeInRange(DateTime.UtcNow.AddSeconds(-10), DateTime.UtcNow);
                clientTemplate.AssociatedSecurityPrinciples.ShouldContain(role => _roles.Contains(role));
                clientTemplate.ApiType.ShouldBe(ApiTypes.SimsPrimaryApi);
            }
        }

        [TearDown]
        public async Task TearDown()
        {
            await _partnerRepository.DeleteStorageAsync();
            await _roleRepository.DeleteStorageAsync();
        }
    }
}