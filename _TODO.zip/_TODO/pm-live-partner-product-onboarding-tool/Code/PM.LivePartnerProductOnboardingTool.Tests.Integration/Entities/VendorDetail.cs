﻿namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities
{
    internal class VendorDetail
    {
        public string VendorId { get; set; }
        public string VendorName { get; set; }
        public string ApplicationId { get; set; }
        public string ApplicationName { get; set; }
    }
}