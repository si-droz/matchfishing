﻿namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities
{
    internal class AzureApiSubscription
    {
        public string UserId { get; set; }
        public string ProductId { get; set; }
        public string State { get; set; }
        public string PrimaryKey { get; set; }
    }
}