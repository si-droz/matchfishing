﻿using PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities
{
    internal class SimsIdClient
    {
        public string ClientId { get; set; }
        public string GrantedScopes { get; set; }
        public string Flow { get; set; }
        public bool GenerateSecrets { get; set; }
        public VendorDetail VendorDetail { get; set; }
    }
}