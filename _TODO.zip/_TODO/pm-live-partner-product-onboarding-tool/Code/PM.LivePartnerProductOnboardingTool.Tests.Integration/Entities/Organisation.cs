﻿namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities
{
    internal class Organisation
    {
        public string OrganisationId { get; set; }
    }
}