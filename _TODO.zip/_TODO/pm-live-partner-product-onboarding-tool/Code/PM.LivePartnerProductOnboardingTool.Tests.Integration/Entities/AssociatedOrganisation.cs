﻿namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities
{
    internal class AssociatedOrganisation
    {
        public string ClientId { get; set; }
        public Organisation Organisation { get; set; }
    }
}