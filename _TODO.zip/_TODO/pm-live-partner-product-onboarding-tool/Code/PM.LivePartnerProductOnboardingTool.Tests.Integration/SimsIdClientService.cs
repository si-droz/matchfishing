﻿using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration
{
    internal static class SimsIdClientService
    {
        public static async Task CreateAsync(IHttpClientFactory httpClientFactory, SimsIdClient simsIdClient)
        {
            string testSimsIdClientAsJson = JsonConvert.SerializeObject(simsIdClient);

            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("v2/Client/Create", new StringContent(testSimsIdClientAsJson,
                                                                                                                           Encoding.UTF8,
                                                                                                                           ContentTypes.JsonContentType));
                httpResponseMessage.EnsureSuccessStatusCode();
            }
        }

        public static async Task DeleteAsync(IHttpClientFactory httpClientFactory, string clientId)
        {
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                string deleteClientUri = $"v1/Client/Delete?clientId={clientId}";
                HttpResponseMessage httpResponseMessage = await httpClient.GetAsync(deleteClientUri);
                httpResponseMessage.EnsureSuccessStatusCode();
            }
        }

        public static async Task<List<string>> GetOrganisationsAsync(IHttpClientFactory httpClientFactory, string clientId)
        {
            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                HttpResponseMessage httpResponseMessage = await httpClient.GetAsync($"v2/Client/Organisations?clientId={clientId}");
                httpResponseMessage.EnsureSuccessStatusCode();

                List<string> result = await httpResponseMessage.Content.ReadAsAsync<List<string>>();

                return result;
            }
        }

        public static async Task AddOrganisationAsync(IHttpClientFactory httpClientFactory, AssociatedOrganisation associatedOrganisation)
        {
            string contentAsJson = JsonConvert.SerializeObject(associatedOrganisation);

            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("v2/Client/AddOrganisation", new StringContent(contentAsJson,
                                                                                                                                    Encoding.UTF8,
                                                                                                                                    ContentTypes.JsonContentType));
                httpResponseMessage.EnsureSuccessStatusCode();
            }
        }

        public static async Task RemoveOrganisationAsync(IHttpClientFactory httpClientFactory, AssociatedOrganisation associatedOrganisation)
        {
            string contentAsJson = JsonConvert.SerializeObject(associatedOrganisation);

            using(HttpClient httpClient = await httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                HttpResponseMessage httpResponseMessage = await httpClient.PostAsync("v2/Client/RemoveOrganisation", new StringContent(contentAsJson,
                                                                                                                                       Encoding.UTF8,
                                                                                                                                       ContentTypes.JsonContentType));
                httpResponseMessage.EnsureSuccessStatusCode();
            }
        }
    }
}