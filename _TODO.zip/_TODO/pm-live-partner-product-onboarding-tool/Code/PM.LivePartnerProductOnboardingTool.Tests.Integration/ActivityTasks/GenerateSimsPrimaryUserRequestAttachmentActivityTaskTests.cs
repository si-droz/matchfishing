﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class GenerateSimsPrimaryUserRequestAttachmentActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;

        public GenerateSimsPrimaryUserRequestAttachmentActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterCommonDependencies()
                                                  .RegisterStorageDependencies();
        }

        [Test]
        public async Task ExecuteAsync_GeneratesBaseSimsPrimaryUserRequestAttachment()
        {
            // Arrange
            var partner = new Partner();
            var clientTemplate = new ClientTemplate
                                 {
                                     Id = Guid.NewGuid().ToString(),
                                     AssociatedSecurityPrinciples = new List<string>()
                                 };
            var product = new Product
                          {
                              ClientTemplates = new List<ClientTemplate>
                                                {
                                                    clientTemplate
                                                }
                          };
            var clientInstance = new ClientInstance
                                 {
                                     ClientId = Guid.NewGuid().ToString(),
                                     CreatedFromTemplateId = clientTemplate.Id
                                 };

            var activityTaskUnderTest = _unityContainer.Resolve<GenerateSimsPrimaryUserRequestAttachmentActivityTask>();
            var context = new AssociateProductInstanceClientToOrganisationContext(partner,
                                                                                  product,
                                                                                  clientInstance,
                                                                                  TestingIdentities.OrganisationId);

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            context.SimsPrimaryUserRequestAttachment.ShouldNotBeNull();
            context.SimsPrimaryUserRequestAttachment.ServiceId.ShouldBe(clientInstance.ClientId);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [Test]
        public async Task ExecuteAsync_AddsReadSecurityDomains()
        {
            var partner = new Partner();

            var expectedSecurityPrinciples = new List<string> {"One", "Two", "Three"};
            var associatedSecurityPrinciples = expectedSecurityPrinciples.Select(securityPrinciple => $"Read:{securityPrinciple}");

            var clientTemplate = new ClientTemplate
                                 {
                                     Id = "ClientTemplate1",
                                     AssociatedSecurityPrinciples = associatedSecurityPrinciples
                                 };

            var product = new Product
                          {
                              ClientTemplates = new List<ClientTemplate> {clientTemplate}
                          };

            var clientInstance = new ClientInstance
                                 {
                                     ClientId = Guid.NewGuid().ToString(),
                                     CreatedFromTemplateId = clientTemplate.Id
                                 };

            var activityTaskUnderTest = _unityContainer.Resolve<GenerateSimsPrimaryUserRequestAttachmentActivityTask>();
            var context = new AssociateProductInstanceClientToOrganisationContext(partner,
                                                                                  product,
                                                                                  clientInstance,
                                                                                  TestingIdentities.OrganisationId);

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            context.SimsPrimaryUserRequestAttachment.ShouldNotBeNull();
            context.SimsPrimaryUserRequestAttachment.SecurityDomainsForWrite.ShouldBeEmpty();
            context.SimsPrimaryUserRequestAttachment.SecurityDomainsForRead.ShouldBe(expectedSecurityPrinciples);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [Test]
        public async Task ExecuteAsync_AddsWriteSecurityDomains()
        {
            // Arrange
            var partner = new Partner();

            var expectedSecurityPrinciples = new List<string> {"One", "Two", "Three"};
            var associatedSecurityPrinciples = expectedSecurityPrinciples.Select(securityPrinciple => $"Write:{securityPrinciple}");

            var clientTemplate = new ClientTemplate
                                 {
                                     Id = "ClientTemplate1",
                                     AssociatedSecurityPrinciples = associatedSecurityPrinciples
                                 };

            var product = new Product
                          {
                              ClientTemplates = new List<ClientTemplate> {clientTemplate}
                          };

            var clientInstance = new ClientInstance
                                 {
                                     ClientId = Guid.NewGuid().ToString(),
                                     CreatedFromTemplateId = clientTemplate.Id
                                 };

            var activityTaskUnderTest = _unityContainer.Resolve<GenerateSimsPrimaryUserRequestAttachmentActivityTask>();
            var context = new AssociateProductInstanceClientToOrganisationContext(partner,
                                                                                  product,
                                                                                  clientInstance,
                                                                                  TestingIdentities.OrganisationId);

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            context.SimsPrimaryUserRequestAttachment.ShouldNotBeNull();
            context.SimsPrimaryUserRequestAttachment.SecurityDomainsForRead.ShouldBeEmpty();
            context.SimsPrimaryUserRequestAttachment.SecurityDomainsForWrite.ShouldBe(expectedSecurityPrinciples);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }
    }
}