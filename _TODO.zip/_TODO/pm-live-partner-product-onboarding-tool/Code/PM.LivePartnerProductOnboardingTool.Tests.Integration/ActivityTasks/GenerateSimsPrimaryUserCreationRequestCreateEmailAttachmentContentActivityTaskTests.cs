﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using SendGrid.Helpers.Mail;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class GenerateSimsPrimaryUserCreationRequestCreateEmailAttachmentContentActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private Partner _partner;
        private AssociateProductInstanceClientToOrganisationContext _context;

        public GenerateSimsPrimaryUserCreationRequestCreateEmailAttachmentContentActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();
        }

        [SetUp]
        public async Task Setup()
        {
            string clientId = Guid.NewGuid().ToString("N");

            _partner = new PartnerBuilder().WithClientId(clientId)
                                           .WithOrganisationId(TestingIdentities.OrganisationId)
                                           .Build();

            var tableStore = _unityContainer.Resolve<ITableStore<StorageConfigurationSetting>>();
            await tableStore.InitStorageAsync();

            _context = new AssociateProductInstanceClientToOrganisationContext(_partner,
                                                                               _partner.Products.First(),
                                                                               _partner.Products.First().ProductInstances.First().ClientInstances.First(),
                                                                               TestingIdentities.OrganisationId)
                       {
                           SimsPrimaryUserRequestAttachment = new SimsPrimaryUserRequest
                                                              {
                                                                  SecurityDomainsForRead = new[] {"MealManagement.Configuration", "MealManagement.Meal"},
                                                                  SecurityDomainsForWrite = new[] {"MealManagement.Configuration", "MealManagement.Meal"},
                                                                  ServiceId = clientId
                                                              }
                       };
        }

        [Test]
        public async Task WhenExecuted_AddsAttachmentToContext()
        {
            // Arrange
            var activityTaskUnderTest = _unityContainer.Resolve<GenerateSimsPrimaryUserCreationRequestCreateEmailAttachmentContentActivityTask>();

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(_context);

            // Assert
            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();

            _context.EmailAttachments.ShouldNotBeNull();
            Attachment emailAttachment = _context.EmailAttachments.First();
            emailAttachment.Content.ShouldNotBeNullOrEmpty();
            emailAttachment.ContentId.ShouldBeNullOrEmpty();
            emailAttachment.Disposition.ShouldBe("attachment");
            emailAttachment.Type.ShouldBe("application/json");
            emailAttachment.Filename.ShouldBe($"security_domains_for_{_context.SimsPrimaryUserRequestAttachment.ServiceId}.json");
        }
    }
}