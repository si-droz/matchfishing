﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class CreateEmailContentActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private ITableStore<StorageConfigurationSetting> _tableStore;
        private Partner _partner;
        private SendProductInstanceDetailsEmailToPartnerContext _context;

        public CreateEmailContentActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();
        }

        [SetUp]
        public async Task Setup()
        {
            string clientId = Guid.NewGuid().ToString("N");

            _partner = new PartnerBuilder().WithClientId(clientId)
                                           .Build();

            _tableStore = _unityContainer.Resolve<ITableStore<StorageConfigurationSetting>>();
            await _tableStore.InitStorageAsync();

            _context = new SendProductInstanceDetailsEmailToPartnerContext(_partner,
                                                                           _partner.Products.First(),
                                                                           _partner.Products.First().ProductInstances.First())
                       {
                           EmailHtmlTemplateText = (await _tableStore.GetAsync(GetEmailBodyFromTableStorageActivityTask.ProductInstanceEmailHtmlBody)).Value,
                           EmailPlainTextTemplateText = (await _tableStore.GetAsync(GetEmailBodyFromTableStorageActivityTask.ProductInstanceEmailPlainTextBody)).Value,
                           ClientSecrets = new List<ClientSecret>
                                           {
                                               new ClientSecret(clientId, "Test Client Friendly Name 1", "ClientCredential", new[] {"simsserverapplication", "partner"}, new[] {Guid.NewGuid().ToString(), Guid.NewGuid().ToString()}),
                                               new ClientSecret(Guid.NewGuid().ToString(), "Test Client Friendly Name 2", "ClientCredential", new[] {"simsserverapplication", "partner"}, new[] {Guid.NewGuid().ToString(), Guid.NewGuid().ToString()})
                                           },
                           ClientOcpApimKeys = new Dictionary<string, string>
                                               {
                                                   {clientId, Guid.NewGuid().ToString()},
                                                   {Guid.NewGuid().ToString(), Guid.NewGuid().ToString()}
                                               }
                       };
        }

        [Test]
        public async Task WhenExecuted_ReplacesPlaceHoldersWithCorrectData()
        {
            // Arrange
            var activityTaskUnderTest = _unityContainer.Resolve<CreateEmailContentActivityTask>();

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(_context);

            // Assert
            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();

            _context.EmailHtmlText.ShouldNotBeNullOrEmpty();
            _context.EmailHtmlText.ShouldNotContain(CreateEmailContentActivityTask.PartnerContactTitlePlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(CreateEmailContentActivityTask.PartnerContactForenamePlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(CreateEmailContentActivityTask.PartnerContactSurnamePlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(CreateEmailContentActivityTask.ProductInstanceNamePlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(CreateEmailContentActivityTask.ProductNamePlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(CreateEmailContentActivityTask.ClientInstancesPlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(CreateEmailContentActivityTask.AssociatedOrganisationsPlaceHolder);

            _context.EmailPlainText.ShouldNotBeNullOrEmpty();
            _context.EmailPlainText.ShouldNotContain(CreateEmailContentActivityTask.PartnerContactTitlePlaceHolder);
            _context.EmailPlainText.ShouldNotContain(CreateEmailContentActivityTask.PartnerContactForenamePlaceHolder);
            _context.EmailPlainText.ShouldNotContain(CreateEmailContentActivityTask.PartnerContactSurnamePlaceHolder);
            _context.EmailPlainText.ShouldNotContain(CreateEmailContentActivityTask.ProductInstanceNamePlaceHolder);
            _context.EmailPlainText.ShouldNotContain(CreateEmailContentActivityTask.ProductNamePlaceHolder);
            _context.EmailPlainText.ShouldNotContain(CreateEmailContentActivityTask.ClientInstancesPlaceHolder);
            _context.EmailPlainText.ShouldNotContain(CreateEmailContentActivityTask.AssociatedOrganisationsPlaceHolder);
        }
    }
}