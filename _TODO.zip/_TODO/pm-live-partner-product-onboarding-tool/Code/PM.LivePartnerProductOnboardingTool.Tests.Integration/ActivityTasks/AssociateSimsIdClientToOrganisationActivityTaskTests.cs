﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class AssociateSimsIdClientToOrganisationActivityTaskTests
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IUnityContainer _unityContainer;
        private SimsIdClient _testSimsIdClient;

        public AssociateSimsIdClientToOrganisationActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterCommonDependencies()
                                                  .RegisterStorageDependencies();

            _httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
        }

        [SetUp]
        public async Task SetUp()
        {
            _testSimsIdClient = new SimsIdClient
                                {
                                    ClientId = Guid.NewGuid().ToString(),
                                    GrantedScopes = "partner simsserverapplication",
                                    Flow = "clientcredential",
                                    GenerateSecrets = true,
                                    VendorDetail = new VendorDetail
                                                   {
                                                       VendorId = "integration-test-vendor-id-" + Guid.NewGuid(),
                                                       VendorName = "integration-test-vendor-name-" + Guid.NewGuid(),
                                                       ApplicationId = "integration-test-application-id-" + Guid.NewGuid(),
                                                       ApplicationName = "integration-test-application-name-" + Guid.NewGuid()
                                                   }
                                };

            await SimsIdClientService.CreateAsync(_httpClientFactory, _testSimsIdClient);
        }

        [Test]
        public async Task ExecuteAsync_AssociatesTheSpecifiedOrganisationToTheSpecifiedClient()
        {
            var partner = new Partner();
            var product = new Product();
            var clientInstance = new ClientInstance
                                 {
                                     ClientId = _testSimsIdClient.ClientId
                                 };

            var context = new AssociateProductInstanceClientToOrganisationContext(partner,
                                                                                  product,
                                                                                  clientInstance,
                                                                                  TestingIdentities.OrganisationId);

            var activityTask = _unityContainer.Resolve<AssociateSimsIdClientToOrganisationActivityTask>();
            await activityTask.ExecuteCoreAsync(context);

            activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);

            List<string> associatedOrganisations = await SimsIdClientService.GetOrganisationsAsync(_httpClientFactory, _testSimsIdClient.ClientId);
            associatedOrganisations.ShouldNotBe(null);
            associatedOrganisations.Count.ShouldBe(1);
            associatedOrganisations.First().ShouldBe(TestingIdentities.OrganisationId, StringCompareShould.IgnoreCase);
        }

        [TearDown]
        public async Task TearDown()
        {
            await SimsIdClientService.DeleteAsync(_httpClientFactory, _testSimsIdClient.ClientId);
        }
    }
}