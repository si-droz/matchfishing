﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class GenerateSimsPrimaryUserCreationRequestActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;

        public GenerateSimsPrimaryUserCreationRequestActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterCommonDependencies()
                                                  .RegisterStorageDependencies();
        }

        [Test]
        public async Task ExecuteAsync_SendsSimsPrimaryUserCreationRequestEmail()
        {
            // Arrange
            var partner = new Partner();
            var clientTemplate = new ClientTemplate
                                 {
                                     Id = Guid.NewGuid().ToString(),
                                     AssociatedSecurityPrinciples = new List<string>()
                                 };
            var product = new Product
                          {
                              ClientTemplates = new List<ClientTemplate>
                                                {
                                                    clientTemplate
                                                }
                          };

            var clientId = Guid.NewGuid().ToString();

            var clientInstance = new ClientInstance
                                 {
                                     ClientId = clientId,
                                     CreatedFromTemplateId = clientTemplate.Id
                                 };

            var tableStore = _unityContainer.Resolve<ITableStore<StorageConfigurationSetting>>();
            await tableStore.InitStorageAsync();

            var context = new AssociateProductInstanceClientToOrganisationContext(partner,
                                                                                  product,
                                                                                  clientInstance,
                                                                                  TestingIdentities.OrganisationId)
                          {
                              EmailHtmlTemplateText = (await tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailHtmlBody)).Value,
                              EmailPlainTextTemplateText = (await tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailPlainTextBody)).Value,
                              EmailSubject = (await tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailSubject)).Value,
                              SimsPrimaryUserRequestAttachment = new SimsPrimaryUserRequest
                                                                 {
                                                                     SecurityDomainsForRead = new[] {"Admissions.Application", "Admissions.Configuration", "Agency.Detail", "Agent.Detail", "Assessment.Configuration"},
                                                                     SecurityDomainsForWrite = new[] {"Learner.Attendance", "Learner.Assessment", "MealManagement.Configuration", "MealManagement.Meal", "Conduct.AchievementEvent", "Conduct.BehaviourEvent", "Conduct.ReportCard.Results"},
                                                                     ServiceId = clientId
                                                                 }
                          };

            var createEmailContent = _unityContainer.Resolve<GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask>();
            await createEmailContent.ExecuteCoreAsync(context);

            var activityTaskUnderTest = _unityContainer.Resolve<GenerateSimsPrimaryUserCreationRequestActivityTask>();
            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }
    }
}