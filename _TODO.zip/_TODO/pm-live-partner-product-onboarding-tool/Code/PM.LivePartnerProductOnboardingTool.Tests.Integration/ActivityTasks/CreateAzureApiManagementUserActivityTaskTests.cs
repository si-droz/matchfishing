﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class CreateAzureApiManagementUserActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private readonly IHttpClientFactory _httpClientFactory;

        private string _userId;

        public CreateAzureApiManagementUserActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
        }

        [Test]
        public async Task ExecuteAsync_CreatesAzureApiManagementUser_UsingTheSuppliedValues()
        {
            string testSuffix = Guid.NewGuid().ToString().Substring(0, 5);
            var partner = new Partner {Name = "Partner 1"};
            var product = new Product {Name = $"Product 1 {testSuffix}"};

            var activityTaskUnderTest = _unityContainer.Resolve<CreateAzureApiManagementUserActivityTask>();

            var createClientTemplateInstanceContext = new CreateClientTemplateInstanceContext(partner, product, new ClientTemplate());
            await activityTaskUnderTest.ExecuteCoreAsync(createClientTemplateInstanceContext);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            _userId = createClientTemplateInstanceContext.AzureManagementApiUserId;
            HttpResponseMessage response = await AzureApiManagementService.GetUser(_httpClientFactory, _userId);
            response.StatusCode.ShouldBe(HttpStatusCode.OK);
            AzureApiUser azureApiUser = await response.Content.ReadAsAsync<AzureApiUser>();
            azureApiUser.FirstName.ShouldBe(partner.Name);
            azureApiUser.LastName.ShouldBe(product.Name);
        }

        [TearDown]
        public async Task TearDown()
        {
            await AzureApiManagementService.DeleteUserAndAssociatedSubscriptions(_httpClientFactory, _userId);
        }
    }
}