﻿using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private ITableStore<StorageConfigurationSetting> _tableStore;
        private Partner _partner;

        public GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();
        }

        [SetUp]
        public void Setup()
        {
            _partner = new PartnerBuilder().Build();

            _tableStore = _unityContainer.Resolve<ITableStore<StorageConfigurationSetting>>();
        }

        [Test]
        public async Task WhenExecuted_GetsEmailBodyTextFromTableStorage()
        {
            // Arrange
            var context = new AssociateProductInstanceClientToOrganisationContext(_partner,
                                                                                  _partner.Products.First(),
                                                                                  _partner.Products.First().ProductInstances.First().ClientInstances.First(),
                                                                                  TestingIdentities.OrganisationId);

            var activityTaskUnderTest = _unityContainer.Resolve<GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask>();

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            await _tableStore.InitStorageAsync();

            context.EmailSubject.ShouldNotBeNullOrEmpty();
            string emailSubject = (await _tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailSubject)).Value;
            context.EmailSubject.ShouldBe(emailSubject);

            context.EmailHtmlTemplateText.ShouldNotBeNullOrEmpty();
            string emailHtml = (await _tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailHtmlBody)).Value;
            context.EmailHtmlTemplateText.ShouldBe(emailHtml);

            context.EmailPlainTextTemplateText.ShouldNotBeNullOrEmpty();
            string emailPlainText = (await _tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailPlainTextBody)).Value;
            context.EmailPlainTextTemplateText.ShouldBe(emailPlainText);
        }
    }
}