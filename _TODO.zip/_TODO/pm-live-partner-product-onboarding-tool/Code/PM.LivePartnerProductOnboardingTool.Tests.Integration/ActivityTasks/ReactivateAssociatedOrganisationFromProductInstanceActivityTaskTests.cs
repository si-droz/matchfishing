﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class ReactivateAssociatedOrganisationFromProductInstanceActivityTaskTests
    {
        private readonly PartnerRepository _partnerRepository;
        private Partner _partner;
        private readonly string _partnerId = Guid.NewGuid().ToString();
        private readonly string _organisationId = Guid.NewGuid().ToString();

        public ReactivateAssociatedOrganisationFromProductInstanceActivityTaskTests()
        {
            var unityContainer = new UnityContainer().RegisterClientDependencies()
                                                     .RegisterStorageDependencies()
                                                     .RegisterCommonDependencies();

            _partnerRepository = unityContainer.Resolve<PartnerRepository>();
        }

        [SetUp]
        public async Task Setup()
        {
            await _partnerRepository.InitStorageAsync();

            _partner = new PartnerBuilder().WithOrganisationId(_organisationId)
                                           .WithPartnerId(_partnerId)
                                           .WithAssociatedOrganisationIsActive(false)
                                           .Build();

            await _partnerRepository.CreatePartnerAsync(_partner);
        }

        [Test]
        public async Task WhenExecuted_DeactivatesAssociatedOrganisationFromProductInstance()
        {
            // Arrange
            var context = new ReEnableClientAccessToOrganisationContext(_partner,
                                                                        _partner.Products.First(),
                                                                        _partner.Products.First().ProductInstances.First(),
                                                                        _partner.Products.First().ProductInstances.First().AssociatedOrganisations.First());

            var activityTaskUnderTest = new ReactivateAssociatedOrganisationFromProductInstanceActivityTask(_partnerRepository);

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            var partnerUnderInspection = await _partnerRepository.GetPartnerAsync(_partnerId);

            var productUnderInspection = partnerUnderInspection.Products.FirstOrDefault();
            productUnderInspection.ShouldNotBeNull();

            var productInstanceUnderInspection = productUnderInspection.ProductInstances.FirstOrDefault();
            productInstanceUnderInspection.ShouldNotBeNull();

            var associatedOrganisations = productInstanceUnderInspection.AssociatedOrganisations.FirstOrDefault();
            associatedOrganisations.ShouldNotBeNull();
            associatedOrganisations.IsActive.ShouldBe(true);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            await _partnerRepository.DeleteStorageAsync();
        }
    }
}