﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class GetClientSecretsFromSimsIdActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string _partnerId = Guid.NewGuid().ToString();
        private readonly string _firstClientId = $"Test client 1 {Guid.NewGuid():N}";
        private readonly string _secondClientId = $"Test client 2 {Guid.NewGuid():N}";
        private Partner _partner;
        private SimsIdClient _firstTestSimsIdClient;
        private SimsIdClient _secondTestSimsIdClient;

        public GetClientSecretsFromSimsIdActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
        }

        [SetUp]
        public async Task Setup()
        {
            _partner = new PartnerBuilder().WithPartnerId(_partnerId)
                                           .WithClientId(_firstClientId)
                                           .Build();

            string clientTemplateId = Guid.NewGuid().ToString();

            _partner.Products.First().ClientTemplates.Add(new ClientTemplate
                                                          {
                                                              Created = DateTime.UtcNow,
                                                              AccessibleScopes = new List<string> {"partner", "simsserverapplication"},
                                                              ClientType = ClientType.ClientCredential,
                                                              FriendlyName = "Test Client Friendly Name 2",
                                                              Id = clientTemplateId
                                                          });

            _partner.Products.First().ProductInstances.First().ClientInstances.Add(new ClientInstance
                                                                                   {
                                                                                       ClientId = _secondClientId,
                                                                                       AzureApiManagementSubscriptionId = "Subscription Id 2",
                                                                                       AzureApiManagementUserId = "User Id 2",
                                                                                       CreatedFromTemplateId = clientTemplateId
                                                                                   });

            _firstTestSimsIdClient = new SimsIdClient
                                     {
                                         ClientId = _firstClientId,
                                         GrantedScopes = "partner simsserverapplication",
                                         Flow = "clientcredential",
                                         GenerateSecrets = true,
                                         VendorDetail = new VendorDetail
                                                        {
                                                            VendorId = "integration-test-vendor-id-" + Guid.NewGuid(),
                                                            VendorName = "integration-test-vendor-name-" + Guid.NewGuid(),
                                                            ApplicationId = "integration-test-application-id-" + Guid.NewGuid(),
                                                            ApplicationName = "integration-test-application-name-" + Guid.NewGuid()
                                                        }
                                     };

            await SimsIdClientService.CreateAsync(_httpClientFactory, _firstTestSimsIdClient);

            _secondTestSimsIdClient = new SimsIdClient
                                      {
                                          ClientId = _secondClientId,
                                          GrantedScopes = "partner simsserverapplication",
                                          Flow = "clientcredential",
                                          GenerateSecrets = true,
                                          VendorDetail = new VendorDetail
                                                         {
                                                             VendorId = "integration-test-vendor-id-" + Guid.NewGuid(),
                                                             VendorName = "integration-test-vendor-name-" + Guid.NewGuid(),
                                                             ApplicationId = "integration-test-application-id-" + Guid.NewGuid(),
                                                             ApplicationName = "integration-test-application-name-" + Guid.NewGuid()
                                                         }
                                      };

            await SimsIdClientService.CreateAsync(_httpClientFactory, _secondTestSimsIdClient);
        }

        [Test]
        public async Task WhenExecuted_GetsClientSecretsFromSimsId_ForMultipleClientInstances()
        {
            // Arrange
            var context = new SendProductInstanceDetailsEmailToPartnerContext(_partner,
                                                                              _partner.Products.First(),
                                                                              _partner.Products.First().ProductInstances.First());

            var activityTaskUnderTest = _unityContainer.Resolve<GetClientSecretsFromSimsIdActivityTask>();

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            context.ClientSecrets.ShouldNotBeNull();
            context.ClientSecrets.Count.ShouldBe(2);

            foreach(ClientSecret clientSecret in context.ClientSecrets)
            {
                clientSecret.Secrets.ShouldNotBeNull();
                clientSecret.Secrets.Count().ShouldBe(2);
                clientSecret.Secrets.First().ShouldNotBeNullOrEmpty();
                clientSecret.Secrets.Skip(1).First().ShouldNotBeNullOrEmpty();
            }

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            await SimsIdClientService.DeleteAsync(_httpClientFactory, _firstClientId);
            await SimsIdClientService.DeleteAsync(_httpClientFactory, _secondClientId);
        }
    }
}