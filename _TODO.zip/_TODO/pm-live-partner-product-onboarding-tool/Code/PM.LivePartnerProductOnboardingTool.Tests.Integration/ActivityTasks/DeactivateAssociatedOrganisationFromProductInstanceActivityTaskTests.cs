﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class DeactivateAssociatedOrganisationFromProductInstanceActivityTaskTests
    {
        private readonly PartnerRepository _partnerRepository;
        private readonly string _partnerId = Guid.NewGuid().ToString();
        private readonly string _organisationId = Guid.NewGuid().ToString();
        private Partner _partner;

        public DeactivateAssociatedOrganisationFromProductInstanceActivityTaskTests()
        {
            var unityContainer = new UnityContainer().RegisterClientDependencies()
                                                     .RegisterStorageDependencies()
                                                     .RegisterCommonDependencies();

            _partnerRepository = unityContainer.Resolve<PartnerRepository>();
        }

        [SetUp]
        public async Task Setup()
        {
            await _partnerRepository.InitStorageAsync();

            _partner = new PartnerBuilder().WithOrganisationId(_organisationId)
                                           .WithPartnerId(_partnerId)
                                           .Build();

            await _partnerRepository.CreatePartnerAsync(_partner);
        }

        [Test]
        public async Task WhenExecuted_DeactivatesAssociatedOrganisationFromProductInstance()
        {
            // Arrange
            var context = new RevokeClientAccessToOrganisationContext(_partner,
                                                                      _partner.Products.First(),
                                                                      _partner.Products.First().ProductInstances.First(),
                                                                      _partner.Products.First().ProductInstances.First().AssociatedOrganisations.First());

            var activityTaskUnderTest = new DeactivateAssociatedOrganisationFromProductInstanceActivityTask(_partnerRepository);

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            var partnerUnderInspection = await _partnerRepository.GetPartnerAsync(_partnerId);
            Product productUnderInspection = partnerUnderInspection.Products.FirstOrDefault();
            productUnderInspection.ShouldNotBeNull();

            ProductInstance productInstanceUnderInspection = productUnderInspection.ProductInstances.FirstOrDefault();
            productInstanceUnderInspection.ShouldNotBeNull();

            AssociatedOrganisation associatedOrganisationUnderInspection = productInstanceUnderInspection.AssociatedOrganisations.FirstOrDefault();
            associatedOrganisationUnderInspection.ShouldNotBeNull();

            associatedOrganisationUnderInspection.IsActive.ShouldBe(false);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            await _partnerRepository.DeleteStorageAsync();
        }
    }
}