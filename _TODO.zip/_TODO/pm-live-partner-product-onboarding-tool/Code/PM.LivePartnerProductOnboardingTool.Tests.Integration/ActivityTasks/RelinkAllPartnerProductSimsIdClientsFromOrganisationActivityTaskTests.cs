﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;
using Shouldly;
using Unity;
using AssociatedOrganisation = PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities.AssociatedOrganisation;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class RelinkAllPartnerProductSimsIdClientsFromOrganisationActivityTaskTests
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private Partner _partner;
        private SimsIdClient _testSimsIdClient;
        private readonly string _partnerId = Guid.NewGuid().ToString();
        private string _clientId;

        public RelinkAllPartnerProductSimsIdClientsFromOrganisationActivityTaskTests()
        {
            var unityContainer = new UnityContainer().RegisterClientDependencies()
                                                     .RegisterStorageDependencies()
                                                     .RegisterCommonDependencies();

            _httpClientFactory = unityContainer.Resolve<IHttpClientFactory>();
        }

        [SetUp]
        public async Task SetUp()
        {
            _clientId = Guid.NewGuid().ToString();

            _testSimsIdClient = new SimsIdClient
                                {
                                    ClientId = _clientId,
                                    GrantedScopes = "partner simsserverapplication",
                                    Flow = "clientcredential",
                                    GenerateSecrets = true,
                                    VendorDetail = new VendorDetail
                                                   {
                                                       VendorId = "integration-test-vendor-id-" + Guid.NewGuid(),
                                                       VendorName = "integration-test-vendor-name-" + Guid.NewGuid(),
                                                       ApplicationId = "integration-test-application-id-" + Guid.NewGuid(),
                                                       ApplicationName = "integration-test-application-name-" + Guid.NewGuid()
                                                   }
                                };

            await SimsIdClientService.CreateAsync(_httpClientFactory, _testSimsIdClient);

            _partner = new PartnerBuilder().WithOrganisationId(TestingIdentities.OrganisationId)
                                           .WithPartnerId(_partnerId)
                                           .WithClientId(_clientId)
                                           .Build();
        }

        [Test]
        public async Task WhenExecuted_UnlinkAllPartnerProductSimsIdClientsFromOrganisation()
        {
            // Arrange
            var context = new ReEnableClientAccessToOrganisationContext(_partner,
                                                                        _partner.Products.First(),
                                                                        _partner.Products.First().ProductInstances.First(),
                                                                        _partner.Products.First().ProductInstances.First().AssociatedOrganisations.First());

            var activityTaskUnderTest = new RelinkAllPartnerProductSimsIdClientsFromOrganisationActivityTask(_httpClientFactory);

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            List<string> organisations = await SimsIdClientService.GetOrganisationsAsync(_httpClientFactory, _clientId);
            organisations.ShouldNotBeNull();
            organisations.Count.ShouldBe(1);
            organisations.First().ShouldBe(TestingIdentities.OrganisationId, StringCompareShould.IgnoreCase);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            var associatedOrganisation = new AssociatedOrganisation
                                         {
                                             ClientId = _clientId,
                                             Organisation = new Organisation
                                                            {
                                                                OrganisationId = TestingIdentities.OrganisationId
                                                            }
                                         };

            await SimsIdClientService.RemoveOrganisationAsync(_httpClientFactory, associatedOrganisation);

            await SimsIdClientService.DeleteAsync(_httpClientFactory, _clientId);
        }
    }
}