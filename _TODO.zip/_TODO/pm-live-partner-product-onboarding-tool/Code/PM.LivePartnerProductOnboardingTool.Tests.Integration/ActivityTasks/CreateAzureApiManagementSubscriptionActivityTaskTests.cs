﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class CreateAzureApiManagementSubscriptionActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private readonly IHttpClientFactory _httpClientFactory;
        private string _userId;
        private string _subscriptionId;

        public CreateAzureApiManagementSubscriptionActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
        }

        [SetUp]
        public async Task Setup()
        {
            _userId = Guid.NewGuid().ToString();
            var azureApiUser = new AzureApiUser
                               {
                                   FirstName = "Integration Test",
                                   LastName = Guid.NewGuid().ToString(),
                                   Email = $"{Guid.NewGuid()}@sims-partners.com",
                                   Password = Guid.NewGuid().ToString()
                               };
            await AzureApiManagementService.CreateUser(_httpClientFactory, azureApiUser, _userId);
        }

        [Test]
        public async Task WhenExecuted_CreatesAzureApiManagementSubscriptionForUser()
        {
            string testSuffix = Guid.NewGuid().ToString().Substring(0, 5);
            var partner = new Partner {Name = "Partner 1"};
            var product = new Product {Name = $"Product 1 {testSuffix}"};

            var activityTaskUnderTest = _unityContainer.Resolve<CreateAzureApiManagementSubscriptionActivityTask>();
            var context = new CreateClientTemplateInstanceContext(partner, product, new ClientTemplate())
                          {
                              AzureManagementApiUserId = _userId,
                              FormattedIdentifier = Guid.NewGuid().ToString()
                          };
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            _subscriptionId = context.AzureManagementApiSubscriptionId;
            HttpResponseMessage response = await AzureApiManagementService.GetSubscription(_httpClientFactory, _subscriptionId);
            response.StatusCode.ShouldBe(HttpStatusCode.OK);
        }

        [TearDown]
        public async Task TearDown()
        {
            await AzureApiManagementService.DeleteUserAndAssociatedSubscriptions(_httpClientFactory, _userId);
        }
    }
}