﻿using System;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private Partner _partner;
        private AssociateProductInstanceClientToOrganisationContext _context;

        public GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();
        }

        [SetUp]
        public async Task Setup()
        {
            string clientId = Guid.NewGuid().ToString("N");

            _partner = new PartnerBuilder().WithClientId(clientId)
                                           .WithOrganisationId(TestingIdentities.OrganisationId)
                                           .Build();

            var tableStore = _unityContainer.Resolve<ITableStore<StorageConfigurationSetting>>();
            await tableStore.InitStorageAsync();

            _context = new AssociateProductInstanceClientToOrganisationContext(_partner,
                                                                               _partner.Products.First(),
                                                                               _partner.Products.First().ProductInstances.First().ClientInstances.First(),
                                                                               TestingIdentities.OrganisationId)
                       {
                           EmailHtmlTemplateText = (await tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailHtmlBody)).Value,
                           EmailPlainTextTemplateText = (await tableStore.GetAsync(GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask.SimsPrimaryUserCreationRequestEmailPlainTextBody)).Value
                       };
        }

        [Test]
        public async Task WhenExecuted_ReplacesPlaceHoldersWithCorrectData()
        {
            // Arrange
            var activityTaskUnderTest = _unityContainer.Resolve<GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask>();

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(_context);

            // Assert
            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();

            _context.EmailHtmlText.ShouldNotBeNullOrEmpty();
            _context.EmailHtmlText.ShouldNotContain(GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask.PartnerNamePlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask.OrganisationIdPlaceHolder);
            _context.EmailHtmlText.ShouldNotContain(GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask.ClientIdPlaceHolder);

            _context.EmailPlainText.ShouldNotBeNullOrEmpty();
            _context.EmailPlainText.ShouldNotContain(GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask.PartnerNamePlaceHolder);
            _context.EmailPlainText.ShouldNotContain(GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask.OrganisationIdPlaceHolder);
            _context.EmailPlainText.ShouldNotContain(GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask.ClientIdPlaceHolder);
        }
    }
}