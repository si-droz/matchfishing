﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class CreateSimsIdClientActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private readonly IHttpClientFactory _httpClientFactory;
        private string _clientId;

        public CreateSimsIdClientActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
        }

        [Test]
        public async Task WhenExecuted_CreatesTheClientInSimsId()
        {
            var clientTemplate = new ClientTemplate
                                 {
                                     Created = DateTime.UtcNow,
                                     AccessibleScopes = new List<string> {"partner"},
                                     ClientType = ClientType.ClientCredential
                                 };
            var product = new Product
                          {
                              Name = "Partner Product 1",
                              ClientTemplates = new List<ClientTemplate>
                                                {
                                                    clientTemplate
                                                }
                          };
            var partner = new Partner
                          {
                              Name = "Test Partner 1",
                              Products = new List<Product>
                                         {
                                             product
                                         }
                          };

            var context = new CreateClientTemplateInstanceContext(partner, product, clientTemplate);
            var activityTaskUnderTest = _unityContainer.Resolve<CreateSimsIdClientActivityTask>();
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            _clientId = context.ClientId;

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            await SimsIdClientService.DeleteAsync(_httpClientFactory, _clientId);
        }
    }
}