﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Builders;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;
using Shouldly;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class GetOcpApimKeyFromAzureApiManagementActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string _partnerId = Guid.NewGuid().ToString();
        private Partner _partner;
        private string _userId;

        public GetOcpApimKeyFromAzureApiManagementActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterStorageDependencies()
                                                  .RegisterCommonDependencies();

            _httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
        }

        [SetUp]
        public async Task Setup()
        {
            _userId = Guid.NewGuid().ToString();
            string firstSubscriptionId = Guid.NewGuid().ToString();
            string secondSubscriptionId = Guid.NewGuid().ToString();

            _partner = new PartnerBuilder().WithPartnerId(_partnerId)
                                           .Build();

            ClientInstance clientInstance = _partner.Products.First().ProductInstances.First().ClientInstances.First();
            clientInstance.AzureApiManagementSubscriptionId = firstSubscriptionId;
            clientInstance.AzureApiManagementUserId = _userId;

            _partner.Products.First().ProductInstances.First().ClientInstances.Add(new ClientInstance
                                                                                   {
                                                                                       ClientId = secondSubscriptionId,
                                                                                       AzureApiManagementSubscriptionId = secondSubscriptionId,
                                                                                       AzureApiManagementUserId = _userId
                                                                                   });

            var azureApiUser = new AzureApiUser
                               {
                                   FirstName = "Integration Test",
                                   LastName = Guid.NewGuid().ToString(),
                                   Email = $"{Guid.NewGuid()}@sims-partners.com",
                                   Password = Guid.NewGuid().ToString()
                               };

            await AzureApiManagementService.CreateUser(_httpClientFactory, azureApiUser, _userId);
            string azureApiManagementProductIdToSubscribeTo = ConfigurationManager.AppSettings["AzureApiManagement-ManagementApi-ProductIdToSubscribeTo"];

            var azureApiSubscription = new AzureApiSubscription
                                       {
                                           UserId = $"/users/{_userId}",
                                           ProductId = azureApiManagementProductIdToSubscribeTo,
                                           State = "active"
                                       };

            await AzureApiManagementService.CreateSubscription(_httpClientFactory, azureApiSubscription, firstSubscriptionId);

            await AzureApiManagementService.CreateSubscription(_httpClientFactory, azureApiSubscription, secondSubscriptionId);
        }

        [Test]
        public async Task WhenExecuted_GetsAzureApiManagementSubscription_ForMultipleClientInstances()
        {
            // Arrange
            var context = new SendProductInstanceDetailsEmailToPartnerContext(_partner,
                                                                              _partner.Products.First(),
                                                                              _partner.Products.First().ProductInstances.First());

            var activityTaskUnderTest = _unityContainer.Resolve<GetOcpApimKeyFromAzureApiManagementActivityTask>();

            // Act
            await activityTaskUnderTest.ExecuteCoreAsync(context);

            // Assert
            context.ClientOcpApimKeys.ShouldNotBeNull();
            context.ClientOcpApimKeys.Count.ShouldBe(2);

            foreach(KeyValuePair<string, string> clientOcpApimKey in context.ClientOcpApimKeys)
            {
                clientOcpApimKey.Value.ShouldNotBeNullOrEmpty();
            }

            context.ClientOcpApimKeys.Values.ShouldBeUnique();

            activityTaskUnderTest.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTaskUnderTest.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.ExecutionException.ShouldBeNull();
            activityTaskUnderTest.CompensationStatus.ShouldBe(CompensationStatus.NotAttempted);
            activityTaskUnderTest.CompensationMessage.ShouldBeNullOrWhiteSpace();
            activityTaskUnderTest.CompensationException.ShouldBeNull();
        }

        [TearDown]
        public async Task TearDown()
        {
            await AzureApiManagementService.DeleteUserAndAssociatedSubscriptions(_httpClientFactory, _userId);
        }
    }
}