﻿using System;
using System.Threading.Tasks;
using NUnit.Framework;
using PM.LivePartnerProductOnboardingTool.Client;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities;
using Shouldly;
using Unity;
using AssociatedOrganisation = PM.LivePartnerProductOnboardingTool.Tests.Integration.Entities.AssociatedOrganisation;

namespace PM.LivePartnerProductOnboardingTool.Tests.Integration.ActivityTasks
{
    [TestFixture]
    public class ValidateClientHasBeenAssociatedToOrganisationActivityTaskTests
    {
        private readonly IUnityContainer _unityContainer;
        private readonly IHttpClientFactory _httpClientFactory;
        private SimsIdClient _testSimsIdClient;

        public ValidateClientHasBeenAssociatedToOrganisationActivityTaskTests()
        {
            _unityContainer = new UnityContainer().RegisterClientDependencies()
                                                  .RegisterCommonDependencies()
                                                  .RegisterStorageDependencies();

            _httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
        }

        [SetUp]
        public async Task SetUp()
        {
            _testSimsIdClient = new SimsIdClient
                                {
                                    ClientId = Guid.NewGuid().ToString(),
                                    GrantedScopes = "partner simsserverapplication",
                                    Flow = "clientcredential",
                                    GenerateSecrets = true,
                                    VendorDetail = new VendorDetail
                                                   {
                                                       VendorId = "integration-test-vendor-id-" + Guid.NewGuid(),
                                                       VendorName = "integration-test-vendor-name-" + Guid.NewGuid(),
                                                       ApplicationId = "integration-test-application-id-" + Guid.NewGuid(),
                                                       ApplicationName = "integration-test-application-name-" + Guid.NewGuid()
                                                   }
                                };

            await SimsIdClientService.CreateAsync(_httpClientFactory, _testSimsIdClient);
        }

        [Test]
        public async Task ExecuteAsync_WhenSuppliedWithAnAssociatedOrganisationId_CompletesWithASuccessfulExecutionResult()
        {
            // Arrange
            var associatedOrganisation = new AssociatedOrganisation
                                         {
                                             ClientId = _testSimsIdClient.ClientId,
                                             Organisation = new Organisation
                                                            {
                                                                OrganisationId = TestingIdentities.OrganisationId
                                                            }
                                         };
            await SimsIdClientService.AddOrganisationAsync(_httpClientFactory, associatedOrganisation);

            var partner = new Partner();
            var product = new Product();
            var clientInstance = new ClientInstance
                                 {
                                     ClientId = _testSimsIdClient.ClientId
                                 };

            // Act
            var activityTask = _unityContainer.Resolve<ValidateClientHasBeenAssociatedToOrganisationActivityTask>();
            await activityTask.ExecuteCoreAsync(new AssociateProductInstanceClientToOrganisationContext(partner,
                                                                                                        product,
                                                                                                        clientInstance,
                                                                                                        TestingIdentities.OrganisationId));

            // Assert
            activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Successful);
            activityTask.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTask.ExecutionException.ShouldBeNull();
        }

        [Test]
        public async Task ExecuteAsync_WhenSuppliedWithAnNonAssociatedOrganisationId_CompletesWithExceptionExecutionStatus()
        {
            // Arrange
            var partner = new Partner();
            var product = new Product();
            var clientInstance = new ClientInstance
                                 {
                                     ClientId = _testSimsIdClient.ClientId
                                 };

            // Act
            var activityTask = _unityContainer.Resolve<ValidateClientHasBeenAssociatedToOrganisationActivityTask>();
            await activityTask.ExecuteCoreAsync(new AssociateProductInstanceClientToOrganisationContext(partner,
                                                                                                        product,
                                                                                                        clientInstance,
                                                                                                        TestingIdentities.OrganisationId));

            // Assert
            activityTask.ExecutionStatus.ShouldBe(ExecutionStatus.Exception);
            activityTask.ExecutionMessage.ShouldBeNullOrWhiteSpace();
            activityTask.ExecutionException.ShouldBeOfType<InvalidOperationException>();
        }

        [TearDown]
        public async Task TearDown()
        {
            await SimsIdClientService.DeleteAsync(_httpClientFactory, _testSimsIdClient.ClientId);
        }
    }
}