﻿namespace PM.LivePartnerProductOnboardingTool.Tests.Integration
{
    public static class TestingIdentities
    {
        /// <summary>
        /// This is a commonly used Organisation ID that designates a SIMS Primary Instance we use to do our release tests.
        /// </summary>
        public const string OrganisationId = "f9f74ad2-edd7-4f95-b2b3-bf4418a636d4";

        public const string OrganisationName = "End to End Test Organisation";
    }
}