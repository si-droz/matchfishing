﻿namespace PM.LivePartnerProductOnboardingTool.Client.Support
{
    public static class ApiTypes
    {
        public const string SimsPrimaryApi = "SIMS Primary API";
        public const string OneRosterApi = "One Roster API";
        public const string OneRosterWriteApi = "One Roster Write API";
        public const string RegistrationAndProvisioningApi = "Registration and Provisioning API";
    }
}