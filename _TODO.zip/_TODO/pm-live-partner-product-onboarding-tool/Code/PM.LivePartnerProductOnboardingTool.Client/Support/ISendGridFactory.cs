﻿using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace PM.LivePartnerProductOnboardingTool.Client.Support
{
    public interface ISendGridFactory
    {
        Task<SendGridClient> GetSendGridClient();

        SendGridMessage GetSendGridMessage(SendGridEmailModel sendGridEmail);
    }
}