﻿using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace PM.LivePartnerProductOnboardingTool.Client.Support.Implementation
{
    internal class SendGridFactory : ISendGridFactory
    {
        private readonly ISettingsProvider _settingsProvider;
        private const string FromEmail = "noreply@sims-partners.com";

        public SendGridFactory(ISettingsProvider settingsProvider)
        {
            _settingsProvider = settingsProvider;
        }

        public async Task<SendGridClient> GetSendGridClient()
        {
            string sendGridApiKey = await _settingsProvider.GetSettingValueAsync("Send-Grid-Api-Key");

            return new SendGridClient(sendGridApiKey);
        }

        public SendGridMessage GetSendGridMessage(SendGridEmailModel sendGridEmailModel)
        {
            var fromEmailAddress = new EmailAddress(FromEmail);
            var toEmailAddress = new EmailAddress(sendGridEmailModel.To);

            return MailHelper.CreateSingleEmail(fromEmailAddress, toEmailAddress, sendGridEmailModel.Subject, sendGridEmailModel.PlainText, sendGridEmailModel.HtmlText);
        }
    }
}