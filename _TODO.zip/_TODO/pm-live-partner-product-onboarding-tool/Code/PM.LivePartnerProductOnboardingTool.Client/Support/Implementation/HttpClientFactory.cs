﻿using System;
using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using IdentityModel.Client;
using PM.LivePartnerProductOnboardingTool.Common;

namespace PM.LivePartnerProductOnboardingTool.Client.Support.Implementation
{
    internal class HttpClientFactory : IHttpClientFactory
    {
        private readonly ISettingsProvider _settingsProvider;

        public HttpClientFactory(ISettingsProvider settingsProvider)
        {
            _settingsProvider = settingsProvider;
        }

        public async Task<HttpClient> GetHttpClientConfiguredForAzureApiManagementRestApiAsync()
        {
            string apiManagementManagementApiIdentifier = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-Identifier");
            string apiManagementManagementApiKey = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-Key");

            DateTime expiry = DateTime.UtcNow.AddMinutes(10);
            string token;
            using(var encoder = new HMACSHA512(Encoding.UTF8.GetBytes(apiManagementManagementApiKey)))
            {
                string dataToSign = apiManagementManagementApiIdentifier + "\n" + expiry.ToString("O", CultureInfo.InvariantCulture);
                byte[] hash = encoder.ComputeHash(Encoding.UTF8.GetBytes(dataToSign));
                string signature = Convert.ToBase64String(hash);
                token = $"uid={apiManagementManagementApiIdentifier}&ex={expiry:o}&sn={signature}";
            }

            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("SharedAccessSignature", token);
            httpClient.DefaultRequestHeaders.TryAddWithoutValidation("if-match", "*");
            return httpClient;
        }

        public async Task<HttpClient> GetHttpClientConfiguredForSimsIdApiAsync()
        {
            string tokenServerUri = await _settingsProvider.GetSettingValueAsync("SIMSID-AuthenticationServer-TokenServerUri");
            string clientName = await _settingsProvider.GetSettingValueAsync("SIMSID-AuthenticationServer-ClientId");
            string clientSecret = await _settingsProvider.GetSettingValueAsync("SIMSID-AuthenticationServer-Secret");
            string provisioningApiScopes = await _settingsProvider.GetSettingValueAsync("SIMSID-AuthenticationServer-Scopes");
            string provisioningApiBaseUri = await _settingsProvider.GetSettingValueAsync("SIMSID-ProvisioningApi-Base-Uri");

            var tokenClient = new TokenClient(tokenServerUri,
                                              clientName,
                                              clientSecret);

            TokenResponse tokenResponse = await tokenClient.RequestClientCredentialsAsync(provisioningApiScopes);

            string accessToken = tokenResponse.AccessToken;

            var httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", accessToken);
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(ContentTypes.JsonContentType));
            httpClient.BaseAddress = new Uri(provisioningApiBaseUri);
            return httpClient;
        }
    }
}