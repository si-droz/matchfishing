﻿using System.Net.Http;
using System.Threading.Tasks;

namespace PM.LivePartnerProductOnboardingTool.Client.Support
{
    public interface IHttpClientFactory
    {
        Task<HttpClient> GetHttpClientConfiguredForAzureApiManagementRestApiAsync();
        Task<HttpClient> GetHttpClientConfiguredForSimsIdApiAsync();
    }
}