﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using Serilog;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Client
{
    internal class Program
    {
        private static async Task Main()
        {
            IUnityContainer unityContainer = new UnityContainer().RegisterClientDependencies()
                                                                 .RegisterCommonDependencies()
                                                                 .RegisterStorageDependencies();

            var securityProvider = unityContainer.Resolve<ISecurityProvider>();
            string username = await securityProvider.SignInAsync();
            Thread.CurrentPrincipal = new ClaimsPrincipal(new ClaimsIdentity(new List<Claim> {new Claim(ClaimTypes.Name, username)}, "custom"));

            var settingsProvider = unityContainer.Resolve<ISettingsProvider>();
            string auditingStorageAccountConnectionString = await settingsProvider.GetSettingValueAsync("Auditing-StorageAccountConnectionString");
            string auditingStorageTableName = await settingsProvider.GetSettingValueAsync("Auditing-StorageTableName");
            Log.Logger = new LoggerConfiguration().WriteTo.Console()
                                                  .WriteTo.AzureTableStorage(auditingStorageAccountConnectionString, storageTableName: auditingStorageTableName)
                                                  .CreateLogger();

            var partnerRepository = unityContainer.Resolve<PartnerRepository>();
            await partnerRepository.InitStorageAsync();

            var roleRepository = unityContainer.Resolve<RoleRepository>();
            await roleRepository.InitStorageAsync();

            var commandFactory = unityContainer.Resolve<CommandFactory>();
            IReadOnlyCollection<Command> rootCommands = commandFactory.GetRootCommands();

            IReadOnlyCollection<Command> selectionCommands = rootCommands;
            while(selectionCommands != null)
            {
                Command commandToExecute = GetCommandToExecute(selectionCommands);

                selectionCommands = await commandToExecute.ExecuteAsync() ?? rootCommands;
            }
        }

        private static Command GetCommandToExecute(IReadOnlyCollection<Command> commands)
        {
            IReadOnlyList<Command> indexableCommandList = commands.ToList();
            Command selectedCommand = null;
            while(selectedCommand == null)
            {
                Console.Clear();

                for(var index = 0; index < commands.Count; index++)
                {
                    int menuItemNumber = index + 1;
                    Console.WriteLine($"{menuItemNumber}: {indexableCommandList[index].DisplayText}");
                }

                Console.WriteLine("Please select an option.");
                string selectedOption = Console.ReadLine();

                if(int.TryParse(selectedOption, out int selectedOptionNumber) &&
                   selectedOptionNumber > 0 &&
                   selectedOptionNumber <= commands.Count)
                {
                    selectedCommand = indexableCommandList[selectedOptionNumber - 1];
                }
            }

            return selectedCommand;
        }
    }
}