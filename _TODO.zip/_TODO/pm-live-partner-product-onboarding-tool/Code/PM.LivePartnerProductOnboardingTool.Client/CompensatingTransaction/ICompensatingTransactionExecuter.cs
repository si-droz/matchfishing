﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction
{
    public interface ICompensatingTransactionExecuter
    {
        /// <summary>
        /// Executes the provided Activity Tasks synchronously passing the provided context to each one. If an execution failure does occur, all activity tasks including the failing one will be compensated in parallel. Activity tasks that were not executed will not be compensated.
        /// </summary>
        /// <param name="activityTasks">The activity tasks that will be executed synchronously.</param>
        /// <param name="context">The context that is provided to the activity tasks on their execution.</param>
        /// <returns>The execution outcome of the activity tasks provided</returns>
        Task<ActivityOutcome> ExecuteSynchronouslyAsync<T>(IEnumerable<ActivityTask<T>> activityTasks, T context) where T : class;

        /// <summary>
        /// Executes the provided Activity Tasks synchronously passing the provided context to each one. All tasks will continue to be executed regardless of any execution failures.
        /// </summary>
        /// <param name="activityTasks">The activity tasks that will be executed synchronously.</param>
        /// <param name="context">The context that is provided to the activity tasks on their execution.</param>
        /// <returns>The execution outcome of the activity tasks provided</returns>
        Task<ActivityOutcome> ExecuteAllWithoutCompensationSynchronouslyAsync<T>(IEnumerable<ActivityTask<T>> activityTasks, T context) where T : class;
    }
}