﻿using System;
using System.Threading.Tasks;
using Serilog;

namespace PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction
{
    public abstract class ActivityTask<T> where T : class
    {
        protected ActivityTask(string description)
        {
            Description = description;
        }

        public string Description { get; }

        internal async Task ExecuteCoreAsync(T context)
        {
            try
            {
                ActivityTaskOutcome activityTaskOutcome = await ExecuteAsync(context);
                ExecutionStatus = activityTaskOutcome.CompletedSuccessfully ? ExecutionStatus.Successful : ExecutionStatus.Failed;
                Log.Information("The Execution of the Activity Task {Description} completed with the execution status of {ExecutionStatus}.", Description, ExecutionStatus);

                ExecutionMessage = activityTaskOutcome.Message;
            }
            catch(Exception ex)
            {
                ExecutionStatus = ExecutionStatus.Exception;
                ExecutionException = ex;
                Log.Error("The Execution of the Activity Task {Description} raised an unhandled exception. {ex}", Description, ex);
            }
        }

        protected abstract Task<ActivityTaskOutcome> ExecuteAsync(T context);

        internal async Task CompensateCoreAsync(T context)
        {
            try
            {
                ActivityTaskOutcome activityTaskOutcome = await CompensateAsync(context);
                CompensationStatus = activityTaskOutcome.CompletedSuccessfully ? CompensationStatus.Successful : CompensationStatus.Failed;
                Log.Information("The Compensation of the Activity Task {Description} completed with the execution status of {ExecutionStatus}.", Description, ExecutionStatus);

                CompensationMessage = activityTaskOutcome.Message;
            }
            catch(Exception ex)
            {
                CompensationStatus = CompensationStatus.Exception;
                CompensationException = ex;
                Log.Error("The Compensation of the Activity Task {Description} raised an unhandled exception. {ex}", Description, ex);
            }
        }

        protected abstract Task<ActivityTaskOutcome> CompensateAsync(T context);

        public ExecutionStatus ExecutionStatus { get; private set; } = ExecutionStatus.NotAttempted;
        public Exception ExecutionException { get; private set; }
        public CompensationStatus CompensationStatus { get; private set; } = CompensationStatus.NotAttempted;
        public Exception CompensationException { get; private set; }
        public string ExecutionMessage { get; private set; } = string.Empty;
        public string CompensationMessage { get; private set; } = string.Empty;

        public ActivityTaskSummary GetSummary()
        {
            return new ActivityTaskSummary(Description, ExecutionStatus, ExecutionException, CompensationStatus, CompensationException, ExecutionMessage, CompensationMessage);
        }
    }
}