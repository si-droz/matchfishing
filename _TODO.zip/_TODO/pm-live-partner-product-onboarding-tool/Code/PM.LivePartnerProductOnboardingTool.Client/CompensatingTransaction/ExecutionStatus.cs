﻿namespace PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction
{
    public enum ExecutionStatus
    {
        NotAttempted,
        Successful,
        Failed,
        Exception
    }
}