﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction
{
    public class ActivityOutcome
    {
        internal ActivityOutcome(IEnumerable<ActivityTaskSummary> activityTaskOutcomes)
        {
            ActivityTaskSummaries = new ReadOnlyCollection<ActivityTaskSummary>(activityTaskOutcomes.ToList());
        }

        public bool CompletedSuccessfully
        {
            get
            {
                var all = ActivityTaskSummaries.All(activityTaskSummary => activityTaskSummary.ExecutionStatus == ExecutionStatus.Successful);
                return all;
            }
        }

        public ReadOnlyCollection<ActivityTaskSummary> ActivityTaskSummaries { get; }
    }
}