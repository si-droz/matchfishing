﻿namespace PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction
{
    public enum CompensationStatus
    {
        NotAttempted,
        Successful,
        Failed,
        Exception
    }
}