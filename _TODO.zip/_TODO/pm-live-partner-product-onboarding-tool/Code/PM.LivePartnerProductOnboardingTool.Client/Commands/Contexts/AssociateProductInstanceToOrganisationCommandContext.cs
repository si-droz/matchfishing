﻿using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.Contexts
{
    internal class AssociateProductInstanceToOrganisationCommandContext
    {
        public AssociateProductInstanceToOrganisationCommandContext(Partner partner,
                                                                    Product product,
                                                                    ProductInstance productInstance,
                                                                    string organisationId,
                                                                    string organisationName)
        {
            Partner = partner;
            Product = product;
            ProductInstance = productInstance;
            OrganisationId = organisationId;
            OrganisationName = organisationName;
        }

        public Partner Partner { get; }
        public Product Product { get; }
        public ProductInstance ProductInstance { get; }
        public string OrganisationId { get; }
        public string OrganisationName { get; }
    }
}