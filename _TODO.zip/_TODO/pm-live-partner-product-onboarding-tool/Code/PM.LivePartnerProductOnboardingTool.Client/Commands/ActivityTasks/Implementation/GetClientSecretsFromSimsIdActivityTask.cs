using System;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GetClientSecretsFromSimsIdActivityTask : ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public GetClientSecretsFromSimsIdActivityTask(IHttpClientFactory httpClientFactory) : base("Get client secrets from SIMS ID")
        {
            _httpClientFactory = httpClientFactory;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                foreach(var clientInstance in context.ProductInstance.ClientInstances)
                {
                    ClientTemplate clientTemplate = context.Product.ClientTemplates.FirstOrDefault(client => client.Id == clientInstance.CreatedFromTemplateId);
                    if(clientTemplate == null) throw new Exception("Client template not found. Unable to obtain Client Friendly Name");

                    string getClientDetailsUri = $"v1/Client/GetDetails?clientId={clientInstance.ClientId}";
                    HttpResponseMessage httpResponseMessage = await httpClient.GetAsync(getClientDetailsUri);
                    httpResponseMessage.EnsureSuccessStatusCode();
                    SimsIdClientDetails simsIdClientDetails = await httpResponseMessage.Content.ReadAsAsync<SimsIdClientDetails>();

                    context.ClientSecrets.Add(new ClientSecret(clientInstance.ClientId, clientTemplate.FriendlyName, simsIdClientDetails.ClientType, simsIdClientDetails.Scopes, simsIdClientDetails.SharedSecrets));
                }
            }

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            throw new NotImplementedException();
        }
    }
}