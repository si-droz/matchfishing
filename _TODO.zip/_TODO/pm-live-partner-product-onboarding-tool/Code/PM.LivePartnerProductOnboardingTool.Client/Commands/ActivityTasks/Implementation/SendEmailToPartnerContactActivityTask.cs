﻿using System;
using System.Net;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class SendEmailToPartnerContactActivityTask : ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>
    {
        private readonly ISendGridFactory _sendGridFactory;

        public SendEmailToPartnerContactActivityTask(ISendGridFactory sendGridFactory) : base("Send email to partner contact")
        {
            _sendGridFactory = sendGridFactory;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            SendGridEmailModel sendGridEmailModel = new SendGridEmailModel(context.EmailHtmlText,
                                                                           context.EmailPlainText,
                                                                           context.EmailSubject,
                                                                           context.Partner.Contact.WorkEmail);

            SendGridMessage emailMessage = _sendGridFactory.GetSendGridMessage(sendGridEmailModel);
            SendGridClient sendGridClient = await _sendGridFactory.GetSendGridClient();
            Response sendGridResponse = await sendGridClient.SendEmailAsync(emailMessage);

            if(sendGridResponse.StatusCode != HttpStatusCode.Accepted)
            {
                var errorMessage = await sendGridResponse.Body.ReadAsStringAsync();
                throw new Exception(errorMessage);
            }

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            throw new NotImplementedException();
        }
    }
}