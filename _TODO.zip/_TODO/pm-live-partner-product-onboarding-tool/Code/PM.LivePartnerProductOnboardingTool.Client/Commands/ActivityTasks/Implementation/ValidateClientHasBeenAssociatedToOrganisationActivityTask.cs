﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    /// <summary>
    ///     This is in here as the SIMS ID API has an issue where it will accept any Organisation ID but not return a 400
    ///     response if it is not valid. This ActivityTask checks the Organisation ID has been associated with the Client.
    /// </summary>
    internal class ValidateClientHasBeenAssociatedToOrganisationActivityTask : ActivityTask<AssociateProductInstanceClientToOrganisationContext>
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public ValidateClientHasBeenAssociatedToOrganisationActivityTask(IHttpClientFactory httpClientFactory) : base("Validating organisation has been associated with SIMS ID Client")
        {
            _httpClientFactory = httpClientFactory;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                HttpResponseMessage response = await httpClient.GetAsync($"v2/Client/Organisations?clientId={context.ClientInstance.ClientId}");
                response.EnsureSuccessStatusCode();
                IEnumerable<string> organisationIds = await response.Content.ReadAsAsync<IEnumerable<string>>();
                bool containsAssociatedOrganisationId = organisationIds.Contains(context.OrganisationId, StringComparer.CurrentCultureIgnoreCase);
                if(!containsAssociatedOrganisationId) throw new InvalidOperationException($"Check for Organisation association failed. For some reason the organisation {context.OrganisationId} has not been associated withthe client {context.ClientInstance.ClientId}. Please contact SIMS ID.");
            }

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}