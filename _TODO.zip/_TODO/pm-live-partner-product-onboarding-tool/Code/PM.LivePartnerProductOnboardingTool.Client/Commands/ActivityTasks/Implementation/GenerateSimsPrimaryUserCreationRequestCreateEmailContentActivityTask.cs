﻿using System;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask : ActivityTask<AssociateProductInstanceClientToOrganisationContext>
    {
        public const string PartnerNamePlaceHolder = "{partnerName}";
        public const string OrganisationIdPlaceHolder = "{organisationId}";
        public const string ClientIdPlaceHolder = "{clientId}";

        public GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask() : base("Create email content")
        {
        }

        protected override Task<ActivityTaskOutcome> ExecuteAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            // Thought: Would a Strategy or Template pattern work better here?
            context.EmailHtmlText = context.EmailHtmlTemplateText
                                           .Replace(PartnerNamePlaceHolder, context.Partner.Name)
                                           .Replace(OrganisationIdPlaceHolder, context.OrganisationId)
                                           .Replace(ClientIdPlaceHolder, context.ClientInstance.ClientId);

            context.EmailPlainText = context.EmailPlainTextTemplateText
                                            .Replace(PartnerNamePlaceHolder, context.Partner.Name)
                                            .Replace(OrganisationIdPlaceHolder, context.OrganisationId)
                                            .Replace(ClientIdPlaceHolder, context.ClientInstance.ClientId);

            return Task.FromResult(new ActivityTaskOutcome(true));
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}