﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class CreateEmailContentActivityTask : ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>
    {
        public const string PartnerContactTitlePlaceHolder = "{partnerContactTitle}";
        public const string PartnerContactForenamePlaceHolder = "{partnerContactForename}";
        public const string PartnerContactSurnamePlaceHolder = "{partnerContactSurname}";
        public const string ProductNamePlaceHolder = "{productName}";
        public const string ProductInstanceNamePlaceHolder = "{productInstanceName}";
        public const string ClientInstancesPlaceHolder = "{clientInstances}";
        public const string AssociatedOrganisationsPlaceHolder = "{associatedOrganisations}";

        private const string HtmlClientNameRowTemplate = "<tr><td colspan=\"2\"><strong>{0}</strong></td></tr>";
        private const string HtmlRowTemplate = "<tr><td><strong>{0}</strong></td><td>{1}</td></tr>";
        private const string HtmlClientSplitRowTemplate = "<tr><td colspan=\"2\"><hr></td></tr>";
        private const string PlainTextClientNameRowTemplate = "{0}\n";
        private const string PlainTextRowTemplate = "{0}\t{1}\n";
        private const string PlainTextClientSplitRowTemplate = "-----------------------------------\n";
        private const string ClientIdTitleText = "Client ID:";
        private const string GrantTypeTitleText = "Grant Type:";
        private const string ScopesTitleText = "Scopes:";
        private const string SecretsTitleText = "Secrets:";
        private const string OcpApimKeyTitleText = "Ocp-Apim-Subscription-Key:";

        private const string ClientSecretNotFoundError = "Invalid client secret.";
        private const string OcpApimNotFoundError = "Ocp-Apim-Subscription-Key not found in Azure Api Management Service.";

        private const string Delimiter = ", ";

        public CreateEmailContentActivityTask() : base("Create email content")
        {
        }

        protected override Task<ActivityTaskOutcome> ExecuteAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            // Thought: Would a Strategy or Template pattern work better here?
            context.EmailHtmlText = context.EmailHtmlTemplateText
                                           .Replace(PartnerContactTitlePlaceHolder, context.Partner.Contact.Title)
                                           .Replace(PartnerContactForenamePlaceHolder, context.Partner.Contact.Forename)
                                           .Replace(PartnerContactSurnamePlaceHolder, context.Partner.Contact.Surname)
                                           .Replace(ProductNamePlaceHolder, context.Product.Name)
                                           .Replace(ProductInstanceNamePlaceHolder, context.ProductInstance.Name)
                                           .Replace(ClientInstancesPlaceHolder, GetHtmlClientInstances(context))
                                           .Replace(AssociatedOrganisationsPlaceHolder, GetHtmlAssociatedOrganisations(context.ProductInstance.AssociatedOrganisations));

            context.EmailPlainText = context.EmailPlainTextTemplateText
                                            .Replace(PartnerContactTitlePlaceHolder, context.Partner.Contact.Title)
                                            .Replace(PartnerContactForenamePlaceHolder, context.Partner.Contact.Forename)
                                            .Replace(PartnerContactSurnamePlaceHolder, context.Partner.Contact.Surname)
                                            .Replace(ProductNamePlaceHolder, context.Product.Name)
                                            .Replace(ProductInstanceNamePlaceHolder, context.ProductInstance.Name)
                                            .Replace(ClientInstancesPlaceHolder, GetPlainTextClientInstances(context))
                                            .Replace(AssociatedOrganisationsPlaceHolder, GetPlainTextAssociatedOrganisations(context.ProductInstance.AssociatedOrganisations));

            return Task.FromResult(new ActivityTaskOutcome(true));
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            throw new NotImplementedException();
        }

        private string GetHtmlClientInstances(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            var htmlBuilder = new StringBuilder();
            htmlBuilder.Append("<table cellpadding=\"10\">");
            htmlBuilder.Append("<tbody>");
            var clientInstanceTotal = context.ProductInstance.ClientInstances.Count;
            var clientInstanceCounter = 0;
            foreach(ClientInstance clientInstance in context.ProductInstance.ClientInstances)
            {
                ClientSecret clientSecret = context.ClientSecrets.FirstOrDefault(client => client.ClientId == clientInstance.ClientId);
                if(clientSecret == null) throw new Exception(ClientSecretNotFoundError);
                if(!context.ClientOcpApimKeys.TryGetValue(clientInstance.ClientId, out string ocpApiKey)) throw new Exception(OcpApimNotFoundError);
                clientInstanceCounter += 1;

                htmlBuilder.AppendFormat(HtmlClientNameRowTemplate, clientSecret.ClientFriendlyName);
                htmlBuilder.AppendFormat(HtmlRowTemplate, ClientIdTitleText, clientInstance.ClientId);
                htmlBuilder.AppendFormat(HtmlRowTemplate, GrantTypeTitleText, clientSecret.ClientType);
                htmlBuilder.AppendFormat(HtmlRowTemplate, ScopesTitleText, string.Join(Delimiter, clientSecret.Scopes));
                htmlBuilder.AppendFormat(HtmlRowTemplate, SecretsTitleText, string.Join(Delimiter, clientSecret.Secrets));
                htmlBuilder.AppendFormat(HtmlRowTemplate, OcpApimKeyTitleText, ocpApiKey);
                if(clientInstanceCounter < clientInstanceTotal) htmlBuilder.Append(HtmlClientSplitRowTemplate);
            }
            htmlBuilder.Append("</tbody>");
            htmlBuilder.Append("</table>");
            return htmlBuilder.ToString();
        }

        private string GetHtmlAssociatedOrganisations(IEnumerable<AssociatedOrganisation> associatedOrganisations)
        {
            var htmlBuilder = new StringBuilder();
            htmlBuilder.Append("<ul>");
            foreach(AssociatedOrganisation associatedOrganisation in associatedOrganisations)
            {
                htmlBuilder.AppendFormat("<li>{0} ({1})</li>", associatedOrganisation.Name, associatedOrganisation.OrganisationId);
            }
            htmlBuilder.Append("</ul>");

            return htmlBuilder.ToString();
        }

        private string GetPlainTextClientInstances(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            var plainTextBuilder = new StringBuilder();
            var clientInstanceTotal = context.ProductInstance.ClientInstances.Count;
            var clientInstanceCounter = 0;
            foreach(ClientInstance clientInstance in context.ProductInstance.ClientInstances)
            {
                ClientSecret clientSecret = context.ClientSecrets.FirstOrDefault(client => client.ClientId == clientInstance.ClientId);
                if(clientSecret == null) throw new Exception(ClientSecretNotFoundError);
                if(!context.ClientOcpApimKeys.TryGetValue(clientInstance.ClientId, out string ocpApiKey)) throw new Exception(OcpApimNotFoundError);
                clientInstanceCounter += 1;

                plainTextBuilder.AppendFormat(PlainTextClientNameRowTemplate, clientSecret.ClientFriendlyName);
                plainTextBuilder.AppendFormat(PlainTextRowTemplate, ClientIdTitleText, clientInstance.ClientId);
                plainTextBuilder.AppendFormat(PlainTextRowTemplate, GrantTypeTitleText, clientSecret.ClientType);
                plainTextBuilder.AppendFormat(PlainTextRowTemplate, ScopesTitleText, string.Join(Delimiter, clientSecret.Scopes));
                plainTextBuilder.AppendFormat(PlainTextRowTemplate, SecretsTitleText, string.Join(Delimiter, clientSecret.Secrets));
                plainTextBuilder.AppendFormat(PlainTextRowTemplate, OcpApimKeyTitleText, ocpApiKey);
                if(clientInstanceCounter < clientInstanceTotal) plainTextBuilder.Append(PlainTextClientSplitRowTemplate);
            }
            return plainTextBuilder.ToString();
        }

        private string GetPlainTextAssociatedOrganisations(IEnumerable<AssociatedOrganisation> associatedOrganisations)
        {
            var plainTextBuilder = new StringBuilder();
            foreach(var associatedOrganisation in associatedOrganisations)
            {
                plainTextBuilder.AppendFormat("{0} ({1})\n", associatedOrganisation.Name, associatedOrganisation.OrganisationId);
            }
            return plainTextBuilder.ToString();
        }
    }
}