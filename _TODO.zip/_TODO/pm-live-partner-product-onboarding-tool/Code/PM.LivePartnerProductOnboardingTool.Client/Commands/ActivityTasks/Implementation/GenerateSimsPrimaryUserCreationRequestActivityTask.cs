﻿using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GenerateSimsPrimaryUserCreationRequestActivityTask : ActivityTask<AssociateProductInstanceClientToOrganisationContext>
    {
        private readonly ISendGridFactory _sendGridFactory;
        private readonly string _hostedEmailAddress = ConfigurationManager.AppSettings["Hosted-Email-Address"];

        public GenerateSimsPrimaryUserCreationRequestActivityTask(ISendGridFactory sendGridFactory) : base("Generate SIMS Primary User Creation Request")
        {
            _sendGridFactory = sendGridFactory;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            SendGridEmailModel sendGridEmailModel = new SendGridEmailModel(context.EmailHtmlText,
                                                                           context.EmailPlainText,
                                                                           context.EmailSubject,
                                                                           _hostedEmailAddress);

            SendGridMessage emailMessage = _sendGridFactory.GetSendGridMessage(sendGridEmailModel);
            if(context.EmailAttachments.Any()) emailMessage.Attachments = context.EmailAttachments;

            SendGridClient sendGridClient = await _sendGridFactory.GetSendGridClient();
            Response sendGridResponse = await sendGridClient.SendEmailAsync(emailMessage);

            if(sendGridResponse.StatusCode != HttpStatusCode.Accepted)
            {
                var errorMessage = await sendGridResponse.Body.ReadAsStringAsync();
                throw new Exception(errorMessage);
            }

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(AssociateProductInstanceClientToOrganisationContext commandContext)
        {
            throw new NotImplementedException();
        }
    }
}