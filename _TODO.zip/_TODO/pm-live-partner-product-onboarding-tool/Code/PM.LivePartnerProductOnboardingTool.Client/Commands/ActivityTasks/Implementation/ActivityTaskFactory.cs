﻿using System.Collections.Generic;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class ActivityTaskFactory : IActivityTaskFactory
    {
        private readonly IUnityContainer _unityContainer;

        public ActivityTaskFactory(IUnityContainer unityContainer)
        {
            _unityContainer = unityContainer;
        }

        public IEnumerable<ActivityTask<CreateClientTemplateInstanceContext>> GetCreateClientInstanceActivityTasks(ClientTemplate clientTemplate)
        {
            var httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
            var settingsProvider = _unityContainer.Resolve<ISettingsProvider>();
            var activityTasks = new List<ActivityTask<CreateClientTemplateInstanceContext>>
                                {
                                    new CreateSimsIdClientActivityTask(httpClientFactory, settingsProvider),
                                    new CreateAzureApiManagementUserActivityTask(httpClientFactory, settingsProvider),
                                    new CreateAzureApiManagementSubscriptionActivityTask(httpClientFactory, settingsProvider)
                                };

            return activityTasks.AsReadOnly();
        }

        public IEnumerable<ActivityTask<AssociateProductInstanceClientToOrganisationContext>> GetAssociateProductInstanceClientToOrganisationActivityTasks(ClientTemplate clientTemplate)
        {
            var httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
            var activityTasks = new List<ActivityTask<AssociateProductInstanceClientToOrganisationContext>>
                                {
                                    new AssociateSimsIdClientToOrganisationActivityTask(httpClientFactory),
                                    new ValidateClientHasBeenAssociatedToOrganisationActivityTask(httpClientFactory)
                                };

            switch(clientTemplate.ApiType)
            {
                case ApiTypes.SimsPrimaryApi:
                {
                    var tableStorage = _unityContainer.Resolve<ITableStore<StorageConfigurationSetting>>();
                    var sendGridFactory = _unityContainer.Resolve<ISendGridFactory>();
                    activityTasks.Add(new GenerateSimsPrimaryUserRequestAttachmentActivityTask());
                    activityTasks.Add(new GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask(tableStorage));
                    activityTasks.Add(new GenerateSimsPrimaryUserCreationRequestCreateEmailContentActivityTask());
                    activityTasks.Add(new GenerateSimsPrimaryUserCreationRequestCreateEmailAttachmentContentActivityTask());
                    activityTasks.Add(new GenerateSimsPrimaryUserCreationRequestActivityTask(sendGridFactory));
                    break;
                }
            }

            return activityTasks.AsReadOnly();
        }

        public IEnumerable<ActivityTask<RevokeClientAccessToOrganisationContext>> GetUnlinkClientAccessToOrganisationActivityTasks()
        {
            var httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
            var partnerRepository = _unityContainer.Resolve<PartnerRepository>();

            var activityTasks = new List<ActivityTask<RevokeClientAccessToOrganisationContext>>
                                {
                                    new UnlinkAllPartnerProductSimsIdClientsFromOrganisationActivityTask(httpClientFactory),
                                    new DeactivateAssociatedOrganisationFromProductInstanceActivityTask(partnerRepository)
                                };

            return activityTasks;
        }

        public IEnumerable<ActivityTask<ReEnableClientAccessToOrganisationContext>> GetRelinkClientAccessToOrganisationActivityTasks()
        {
            var httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
            var partnerRepository = _unityContainer.Resolve<PartnerRepository>();

            var activityTasks = new List<ActivityTask<ReEnableClientAccessToOrganisationContext>>
                                {
                                    new RelinkAllPartnerProductSimsIdClientsFromOrganisationActivityTask(httpClientFactory),
                                    new ReactivateAssociatedOrganisationFromProductInstanceActivityTask(partnerRepository)
                                };

            return activityTasks;
        }

        public IEnumerable<ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>> GetSendEmailWithProductInstanceDetailsActivityTasks()
        {
            var httpClientFactory = _unityContainer.Resolve<IHttpClientFactory>();
            var settingsProvider = _unityContainer.Resolve<ISettingsProvider>();
            var tableStore = _unityContainer.Resolve<ITableStore<StorageConfigurationSetting>>();
            var sendGridFactory = _unityContainer.Resolve<ISendGridFactory>();

            var activityTasks = new List<ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>>
                                {
                                    new GetClientSecretsFromSimsIdActivityTask(httpClientFactory),
                                    new GetOcpApimKeyFromAzureApiManagementActivityTask(httpClientFactory, settingsProvider),
                                    new GetEmailBodyFromTableStorageActivityTask(tableStore),
                                    new CreateEmailContentActivityTask(),
                                    new SendEmailToPartnerContactActivityTask(sendGridFactory)
                                };

            return activityTasks;
        }
    }
}