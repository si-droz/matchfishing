﻿using System;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using SendGrid.Helpers.Mail;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GenerateSimsPrimaryUserCreationRequestCreateEmailAttachmentContentActivityTask : ActivityTask<AssociateProductInstanceClientToOrganisationContext>
    {
        public GenerateSimsPrimaryUserCreationRequestCreateEmailAttachmentContentActivityTask() : base("Create email security domains attachment")
        {
        }

        protected override Task<ActivityTaskOutcome> ExecuteAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            var rawContent = BuildPermissionsJson(context.SimsPrimaryUserRequestAttachment);

            var contentAsBytes = Encoding.ASCII.GetBytes(rawContent);

            var attachment = new Attachment
                             {
                                 Content = Convert.ToBase64String(contentAsBytes),
                                 Type = "application/json",
                                 Filename = $"security_domains_for_{context.SimsPrimaryUserRequestAttachment.ServiceId}.json",
                                 Disposition = "attachment"
                             };
            context.EmailAttachments.Add(attachment);

            return Task.FromResult(new ActivityTaskOutcome(true));
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            throw new NotImplementedException();
        }

        private string BuildPermissionsJson(SimsPrimaryUserRequest simsPrimaryUserRequest)
        {
            var jsonBuilder = new StringBuilder();

            jsonBuilder.Append("{");
            jsonBuilder.AppendFormat("\"ServiceId\": \"{0}\",", simsPrimaryUserRequest.ServiceId);

            jsonBuilder.AppendFormat("\"SecurityDomainsForRead\": {0},", JsonConvert.SerializeObject(simsPrimaryUserRequest.SecurityDomainsForRead));
            jsonBuilder.AppendFormat("\"SecurityDomainsForWrite\": {0}", JsonConvert.SerializeObject(simsPrimaryUserRequest.SecurityDomainsForWrite));

            jsonBuilder.Append("}");

            return jsonBuilder.ToString();
        }
    }
}