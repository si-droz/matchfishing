﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class CreateAzureApiManagementSubscriptionActivityTask : ActivityTask<CreateClientTemplateInstanceContext>
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ISettingsProvider _settingsProvider;

        public CreateAzureApiManagementSubscriptionActivityTask(IHttpClientFactory httpClientFactory, ISettingsProvider settingsProvider) : base("Create Azure Api Management Subscription Activity Task")
        {
            _httpClientFactory = httpClientFactory;
            _settingsProvider = settingsProvider;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(CreateClientTemplateInstanceContext context)
        {
            string apiManagementManagementApiBaseUri = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-BaseUri");
            string apiManagementManagementSubscriptionPrefix = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-SubscriptionPrefix");
            string azureApiManagementProductIdToSubscribeTo = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-ProductIdToSubscribeTo");

            string subscriptionId = string.Concat(apiManagementManagementSubscriptionPrefix, "--", context.FormattedIdentifier);

            using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                var newSubscription = new
                                      {
                                          userId = "/users/" + context.AzureManagementApiUserId,
                                          productId = azureApiManagementProductIdToSubscribeTo,
                                          state = "active"
                                      };

                string newSubscriptionAsJson = JsonConvert.SerializeObject(newSubscription);
                string requestUri = string.Format(apiManagementManagementApiBaseUri, $"/subscriptions/{subscriptionId}");
                HttpResponseMessage response = await httpClient.PutAsync(requestUri,
                                                                         new StringContent(newSubscriptionAsJson,
                                                                                           Encoding.UTF8,
                                                                                           ContentTypes.JsonContentType));
                response.EnsureSuccessStatusCode();
            }

            context.AzureManagementApiSubscriptionId = subscriptionId;

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(CreateClientTemplateInstanceContext context)
        {
            throw new NotImplementedException();
        }
    }
}