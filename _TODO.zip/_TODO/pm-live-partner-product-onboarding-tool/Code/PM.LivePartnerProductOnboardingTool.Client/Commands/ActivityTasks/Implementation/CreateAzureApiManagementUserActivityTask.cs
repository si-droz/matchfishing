﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class CreateAzureApiManagementUserActivityTask : ActivityTask<CreateClientTemplateInstanceContext>
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ISettingsProvider _settingsProvider;

        public CreateAzureApiManagementUserActivityTask(IHttpClientFactory httpClientFactory, ISettingsProvider settingsProvider) : base("Subscribe to Azure API Management instance")
        {
            _httpClientFactory = httpClientFactory;
            _settingsProvider = settingsProvider;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(CreateClientTemplateInstanceContext context)
        {
            string apiManagementManagementApiUserPrefix = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-UserPrefix");
            string apiManagementManagementApiBaseUri = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-BaseUri");

            string formattedPartnerName = context.Partner.Name.ToLower().Replace(' ', '-');
            string formattedProductName = context.Product.Name.ToLower().Replace(' ', '-');
            string formattedIdentifier = string.Concat(formattedPartnerName, "--", formattedProductName);
            string userId = string.Concat(apiManagementManagementApiUserPrefix, "--", formattedIdentifier);

            using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                var newUser = new
                              {
                                  firstName = context.Partner.Name,
                                  lastName = context.Product.Name,
                                  email = $"{userId}@sims-partners.com",
                                  password = Guid.NewGuid().ToString()
                              };

                string newUserAsJson = JsonConvert.SerializeObject(newUser);

                string requestUri = string.Format(apiManagementManagementApiBaseUri, $"/users/{userId}");
                HttpResponseMessage response = await httpClient.PutAsync(requestUri,
                                                                         new StringContent(newUserAsJson,
                                                                                           Encoding.UTF8,
                                                                                           ContentTypes.JsonContentType));
                response.EnsureSuccessStatusCode();
            }

            context.FormattedIdentifier = formattedIdentifier;
            context.AzureManagementApiUserId = userId;

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(CreateClientTemplateInstanceContext context)
        {
            throw new NotImplementedException();
        }
    }
}