﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class AssociateSimsIdClientToOrganisationActivityTask : ActivityTask<AssociateProductInstanceClientToOrganisationContext>
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public AssociateSimsIdClientToOrganisationActivityTask(IHttpClientFactory httpClientFactory) : base("Associate SIMS ID Client to Organisation")
        {
            _httpClientFactory = httpClientFactory;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            var content = new
                          {
                              clientId = context.ClientInstance.ClientId,
                              organisation = new
                                             {
                                                 organisationId = context.OrganisationId
                                             }
                          };

            string contentAsJson = JsonConvert.SerializeObject(content);

            using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                HttpResponseMessage response = await httpClient.PostAsync("v2/Client/AddOrganisation", new StringContent(contentAsJson,
                                                                                                                         Encoding.UTF8,
                                                                                                                         ContentTypes.JsonContentType));
                response.EnsureSuccessStatusCode();
            }

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}