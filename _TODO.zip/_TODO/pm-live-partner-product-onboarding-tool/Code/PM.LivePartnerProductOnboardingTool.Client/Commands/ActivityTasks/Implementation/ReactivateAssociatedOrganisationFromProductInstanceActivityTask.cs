﻿using System;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Storage;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class ReactivateAssociatedOrganisationFromProductInstanceActivityTask : ActivityTask<ReEnableClientAccessToOrganisationContext>
    {
        private readonly PartnerRepository _partnerRepository;

        public ReactivateAssociatedOrganisationFromProductInstanceActivityTask(PartnerRepository partnerRepository) : base("Reactivate Associated Organisation From Product Instance")
        {
            _partnerRepository = partnerRepository;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(ReEnableClientAccessToOrganisationContext context)
        {
            context.AssociatedOrganisation.IsActive = true;

            await _partnerRepository.UpdatePartnerAsync(context.Partner);

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(ReEnableClientAccessToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}