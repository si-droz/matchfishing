﻿using System;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Storage;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class DeactivateAssociatedOrganisationFromProductInstanceActivityTask : ActivityTask<RevokeClientAccessToOrganisationContext>
    {
        private readonly PartnerRepository _partnerRepository;

        public DeactivateAssociatedOrganisationFromProductInstanceActivityTask(PartnerRepository partnerRepository) : base("Deactivate Associated Organisation From Product Instance")
        {
            _partnerRepository = partnerRepository;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(RevokeClientAccessToOrganisationContext context)
        {
            context.AssociatedOrganisation.IsActive = false;

            await _partnerRepository.UpdatePartnerAsync(context.Partner);

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(RevokeClientAccessToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}