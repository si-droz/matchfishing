﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GetOcpApimKeyFromAzureApiManagementActivityTask : ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly ISettingsProvider _settingsProvider;

        public GetOcpApimKeyFromAzureApiManagementActivityTask(IHttpClientFactory httpClientFactory, ISettingsProvider settingsProvider) : base("Get ocp apim key from Azure Api management")
        {
            _httpClientFactory = httpClientFactory;
            _settingsProvider = settingsProvider;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            string apiManagementManagementApiBaseUri = await _settingsProvider.GetSettingValueAsync("AzureApiManagement-ManagementApi-BaseUri");

            using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForAzureApiManagementRestApiAsync())
            {
                foreach(var clientInstance in context.ProductInstance.ClientInstances)
                {
                    string requestUri = string.Format(apiManagementManagementApiBaseUri, $"/subscriptions/{clientInstance.AzureApiManagementSubscriptionId}");
                    HttpResponseMessage response = await httpClient.GetAsync(requestUri);
                    response.EnsureSuccessStatusCode();
                    AzureApiManagementSubscription subscription = await response.Content.ReadAsAsync<AzureApiManagementSubscription>();
                    context.ClientOcpApimKeys.Add(clientInstance.ClientId, subscription.PrimaryKey);
                }
            }

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            throw new NotImplementedException();
        }
    }
}