﻿using System;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask : ActivityTask<AssociateProductInstanceClientToOrganisationContext>
    {
        private readonly ITableStore<StorageConfigurationSetting> _tableStore;
        public const string SimsPrimaryUserCreationRequestEmailSubject = "SimsPrimaryUserCreationRequestEmailSubject";
        public const string SimsPrimaryUserCreationRequestEmailPlainTextBody = "SimsPrimaryUserCreationRequestEmailPlainTextBody";
        public const string SimsPrimaryUserCreationRequestEmailHtmlBody = "SimsPrimaryUserCreationRequestEmailHtmlBody";

        public GenerateSimsPrimaryUserCreationRequestGetEmailBodyFromTableStorageActivityTask(ITableStore<StorageConfigurationSetting> tableStore) : base("Get subject, html body and plain text body from table storage")
        {
            _tableStore = tableStore;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            await _tableStore.InitStorageAsync();
            context.EmailSubject = (await _tableStore.GetAsync(SimsPrimaryUserCreationRequestEmailSubject)).Value;
            context.EmailHtmlTemplateText = (await _tableStore.GetAsync(SimsPrimaryUserCreationRequestEmailHtmlBody)).Value;
            context.EmailPlainTextTemplateText = (await _tableStore.GetAsync(SimsPrimaryUserCreationRequestEmailPlainTextBody)).Value;

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}