﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using Serilog;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class RelinkAllPartnerProductSimsIdClientsFromOrganisationActivityTask : ActivityTask<ReEnableClientAccessToOrganisationContext>
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public RelinkAllPartnerProductSimsIdClientsFromOrganisationActivityTask(IHttpClientFactory httpClientFactory) : base("Re-link all Partner Product SIMS ID Clients from Organisation")
        {
            _httpClientFactory = httpClientFactory;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(ReEnableClientAccessToOrganisationContext context)
        {
            foreach(ClientInstance clientInstance in context.ProductInstance.ClientInstances)
            {
                Log.Information($"Re-linking client id {clientInstance.ClientId} from Organisation {context.AssociatedOrganisation.OrganisationId} for {context.Partner.Name} : {context.Product.Name}");

                var content = new
                              {
                                  clientId = clientInstance.ClientId,
                                  organisation = new
                                                 {
                                                     organisationId = context.AssociatedOrganisation.OrganisationId
                                                 }
                              };

                string contentAsJson = JsonConvert.SerializeObject(content);

                using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
                {
                    HttpResponseMessage response = await httpClient.PostAsync("v2/Client/AddOrganisation", new StringContent(contentAsJson,
                                                                                                                             Encoding.UTF8,
                                                                                                                             ContentTypes.JsonContentType));
                    if(!response.IsSuccessStatusCode)
                    {
                        Log.Error($"Error re-linking {clientInstance.ClientId} from Organisation {context.AssociatedOrganisation.OrganisationId} for {context.Partner.Name} : {context.Product.Name}. Error: {await response.Content.ReadAsStringAsync()}");
                    }
                }
            }

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(ReEnableClientAccessToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}