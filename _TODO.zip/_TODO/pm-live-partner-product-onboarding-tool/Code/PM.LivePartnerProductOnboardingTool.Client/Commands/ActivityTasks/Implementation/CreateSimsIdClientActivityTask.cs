﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Common;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class CreateSimsIdClientActivityTask : ActivityTask<CreateClientTemplateInstanceContext>
    {
        private readonly ISettingsProvider _settingsProvider;
        private readonly IHttpClientFactory _httpClientFactory;

        public CreateSimsIdClientActivityTask(IHttpClientFactory httpClientFactory, ISettingsProvider settingsProvider) : base("Create SIMS ID client")
        {
            _settingsProvider = settingsProvider;
            _httpClientFactory = httpClientFactory;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(CreateClientTemplateInstanceContext context)
        {
            string newClientNamePrefix = await _settingsProvider.GetSettingValueAsync("SIMSID-NewClient-NamePrefix");
            int partnerNameMaxLength = int.Parse(await _settingsProvider.GetSettingValueAsync("Partner-Name-Max-Length"));
            int productNameMaxLength = int.Parse(await _settingsProvider.GetSettingValueAsync("Product-Name-Max-Length"));

            string formattedPartnerName = FormatName(context.Partner.Name, partnerNameMaxLength);
            string formattedProductName = FormatName(context.Product.Name, productNameMaxLength);

            string clientId = $"{newClientNamePrefix}.{formattedPartnerName}.{formattedProductName}.{Guid.NewGuid():N}";
            var content = new
                          {
                              clientId,
                              grantedScopes = context.ClientTemplate.AccessibleScopes,
                              flow = "clientcredential",
                              generateSecrets = true,
                              vendorDetail = new
                                             {
                                                 vendorId = context.Partner.Id,
                                                 vendorName = context.Partner.Name,
                                                 applicationId = context.Product.Id,
                                                 applicationName = context.Product.Name
                                             }
                          };

            string contentAsJson = JsonConvert.SerializeObject(content);

            using(HttpClient httpClient = await _httpClientFactory.GetHttpClientConfiguredForSimsIdApiAsync())
            {
                HttpResponseMessage response = await httpClient.PostAsync("v2/Client/Create", new StringContent(contentAsJson,
                                                                                                                Encoding.UTF8,
                                                                                                                ContentTypes.JsonContentType));
                response.EnsureSuccessStatusCode();
            }

            context.ClientId = clientId;

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(CreateClientTemplateInstanceContext context)
        {
            throw new NotImplementedException();
        }

        private string FormatName(string name, int maxLength)
        {
            if(name.Length <= maxLength) maxLength = name.Length;

            return name.ToLower().Substring(0, maxLength).Trim().Replace(' ', '-');
        }
    }
}