﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GenerateSimsPrimaryUserRequestAttachmentActivityTask : ActivityTask<AssociateProductInstanceClientToOrganisationContext>
    {
        private const string ReadPermissionPrefix = "Read:";
        private const string WritePermissionPrefix = "Write:";

        private readonly int _readPermissionPrefixLength = ReadPermissionPrefix.Length;
        private readonly int _writePermissionPrefixLength = WritePermissionPrefix.Length;

        public GenerateSimsPrimaryUserRequestAttachmentActivityTask() : base("Generating SIMS Primary user request attachment")
        {
        }

        protected override Task<ActivityTaskOutcome> ExecuteAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            ClientTemplate createdFromClientTemplate = context.Product.ClientTemplates.Single(clientTemplate => clientTemplate.Id == context.ClientInstance.CreatedFromTemplateId);

            IEnumerable<string> readRoles = createdFromClientTemplate.AssociatedSecurityPrinciples
                                                                     .Where(securityPrinciple => securityPrinciple.StartsWith(ReadPermissionPrefix))
                                                                     .Select(securityPrinciple => securityPrinciple.Remove(0, _readPermissionPrefixLength))
                                                                     .ToList();

            IEnumerable<string> writeRoles = createdFromClientTemplate.AssociatedSecurityPrinciples
                                                                      .Where(securityPrinciple => securityPrinciple.StartsWith(WritePermissionPrefix))
                                                                      .Select(securityPrinciple => securityPrinciple.Remove(0, _writePermissionPrefixLength))
                                                                      .ToList();

            context.SimsPrimaryUserRequestAttachment = new SimsPrimaryUserRequest
                                                       {
                                                           ServiceId = context.ClientInstance.ClientId,
                                                           SecurityDomainsForRead = readRoles,
                                                           SecurityDomainsForWrite = writeRoles
                                                       };

            return Task.FromResult(new ActivityTaskOutcome(true));
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(AssociateProductInstanceClientToOrganisationContext context)
        {
            throw new NotImplementedException();
        }
    }
}