﻿using System;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Table;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation
{
    internal class GetEmailBodyFromTableStorageActivityTask : ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>
    {
        private readonly ITableStore<StorageConfigurationSetting> _tableStore;
        public const string ProductInstanceEmailSubject = "ProductInstanceEmailSubject";
        public const string ProductInstanceEmailPlainTextBody = "ProductInstanceEmailPlainTextBody";
        public const string ProductInstanceEmailHtmlBody = "ProductInstanceEmailHtmlBody";

        public GetEmailBodyFromTableStorageActivityTask(ITableStore<StorageConfigurationSetting> tableStore) : base("Get subject, html body and plain text body from table storage")
        {
            _tableStore = tableStore;
        }

        protected override async Task<ActivityTaskOutcome> ExecuteAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            await _tableStore.InitStorageAsync();
            context.EmailSubject = (await _tableStore.GetAsync(ProductInstanceEmailSubject)).Value;
            context.EmailHtmlTemplateText = (await _tableStore.GetAsync(ProductInstanceEmailHtmlBody)).Value;
            context.EmailPlainTextTemplateText = (await _tableStore.GetAsync(ProductInstanceEmailPlainTextBody)).Value;

            return new ActivityTaskOutcome(true);
        }

        protected override Task<ActivityTaskOutcome> CompensateAsync(SendProductInstanceDetailsEmailToPartnerContext context)
        {
            throw new NotImplementedException();
        }
    }
}