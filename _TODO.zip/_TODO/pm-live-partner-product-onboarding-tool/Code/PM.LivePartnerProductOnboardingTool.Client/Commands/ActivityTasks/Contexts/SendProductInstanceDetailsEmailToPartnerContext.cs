﻿using System.Collections.Generic;
using PM.LivePartnerProductOnboardingTool.Storage.DTOs.V1;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts
{
    internal class SendProductInstanceDetailsEmailToPartnerContext
    {
        public SendProductInstanceDetailsEmailToPartnerContext(Partner partner, Product product, ProductInstance productInstance)
        {
            Partner = partner;
            Product = product;
            ProductInstance = productInstance;
            ClientSecrets = new List<ClientSecret>();
            ClientOcpApimKeys = new Dictionary<string, string>();
        }

        public Partner Partner { get; }
        public Product Product { get; }
        public ProductInstance ProductInstance { get; }
        public string EmailSubject { get; set; }
        public string EmailHtmlTemplateText { get; set; }
        public string EmailPlainTextTemplateText { get; set; }
        public string EmailHtmlText { get; set; }
        public string EmailPlainText { get; set; }

        public IList<ClientSecret> ClientSecrets { get; set; }

        public IDictionary<string, string> ClientOcpApimKeys { get; set; }
    }
}