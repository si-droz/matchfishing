﻿using System.Collections.Generic;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts
{
    internal class SimsPrimaryUserRequest
    {
        public string ServiceId { get; set; }
        public IEnumerable<string> SecurityDomainsForRead { get; set; }
        public IEnumerable<string> SecurityDomainsForWrite { get; set; }
    }
}