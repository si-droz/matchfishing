﻿using System.Collections.Generic;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using SendGrid.Helpers.Mail;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts
{
    internal class AssociateProductInstanceClientToOrganisationContext
    {
        public AssociateProductInstanceClientToOrganisationContext(Partner partner,
                                                                   Product product,
                                                                   ClientInstance clientInstance,
                                                                   string organisationId)
        {
            EmailAttachments = new List<Attachment>();
            Partner = partner;
            Product = product;
            ClientInstance = clientInstance;
            OrganisationId = organisationId;
        }

        public Partner Partner { get; }
        public Product Product { get; }
        public ClientInstance ClientInstance { get; }
        public string OrganisationId { get; }
        public SimsPrimaryUserRequest SimsPrimaryUserRequestAttachment { get; set; }
        public string EmailHtmlText { get; set; }
        public string EmailPlainText { get; set; }
        public string EmailSubject { get; set; }
        public string EmailHtmlTemplateText { get; set; }
        public string EmailPlainTextTemplateText { get; set; }
        public List<Attachment> EmailAttachments { get; }
    }
}