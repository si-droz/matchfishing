﻿using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts
{
    internal class ReEnableClientAccessToOrganisationContext
    {
        public ReEnableClientAccessToOrganisationContext(Partner partner, Product product, ProductInstance productInstance, AssociatedOrganisation associatedOrganisation)
        {
            AssociatedOrganisation = associatedOrganisation;
            Partner = partner;
            Product = product;
            ProductInstance = productInstance;
        }

        public AssociatedOrganisation AssociatedOrganisation { get; }
        public Partner Partner { get; }
        public Product Product { get; }
        public ProductInstance ProductInstance { get; }
    }
}