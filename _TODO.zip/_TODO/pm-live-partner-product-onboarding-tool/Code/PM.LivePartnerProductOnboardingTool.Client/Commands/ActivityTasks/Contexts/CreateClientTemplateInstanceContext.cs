﻿using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts
{
    internal class CreateClientTemplateInstanceContext
    {
        public CreateClientTemplateInstanceContext(Partner partner, Product product, ClientTemplate clientTemplate)
        {
            Partner = partner;
            Product = product;
            ClientTemplate = clientTemplate;
        }

        public Partner Partner { get; }
        public Product Product { get; }
        public ClientTemplate ClientTemplate { get; }

        public string FormattedIdentifier { get; set; }
        public string ClientId { get; set; }
        public string AzureManagementApiUserId { get; set; }
        public string AzureManagementApiSubscriptionId { get; set; }
    }
}