﻿using System.Collections.Generic;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks
{
    internal interface IActivityTaskFactory
    {
        IEnumerable<ActivityTask<CreateClientTemplateInstanceContext>> GetCreateClientInstanceActivityTasks(ClientTemplate clientTemplate);
        IEnumerable<ActivityTask<AssociateProductInstanceClientToOrganisationContext>> GetAssociateProductInstanceClientToOrganisationActivityTasks(ClientTemplate clientTemplate);
        IEnumerable<ActivityTask<RevokeClientAccessToOrganisationContext>> GetUnlinkClientAccessToOrganisationActivityTasks();
        IEnumerable<ActivityTask<ReEnableClientAccessToOrganisationContext>> GetRelinkClientAccessToOrganisationActivityTasks();
        IEnumerable<ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>> GetSendEmailWithProductInstanceDetailsActivityTasks();
    }
}