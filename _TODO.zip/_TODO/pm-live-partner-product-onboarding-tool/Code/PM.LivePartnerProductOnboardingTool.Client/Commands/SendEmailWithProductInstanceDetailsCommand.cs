﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using Serilog;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class SendEmailWithProductInstanceDetailsCommand : Command
    {
        private readonly IActivityTaskFactory _activityTaskFactory;
        private readonly Partner _partner;
        private readonly Product _product;
        private readonly ProductInstance _productInstance;

        public SendEmailWithProductInstanceDetailsCommand(IInputOutputManager inputOutputManager,
                                                          IActivityTaskFactory activityTaskFactory,
                                                          Partner partner,
                                                          Product product,
                                                          ProductInstance productInstance) :
            base(inputOutputManager, $"Send email to {partner.Contact.Forename} {partner.Contact.Surname} at {partner.Name} with client access details for {product.Name} : {productInstance.Name}")
        {
            _partner = partner;
            _product = product;
            _productInstance = productInstance;
            _activityTaskFactory = activityTaskFactory;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            if(!InputOutputManager.AskQuestionAndWaitForYesOrNoInput($"IMPORTANT! Are you sure you want to send an email to {_partner.Contact.WorkEmail} ({_partner.Contact.Forename} {_partner.Contact.Surname}) containing client ids, secrets, scopes? y / n"))
            {
                Log.Information("Send email operation cancelled by user.");
                return null;
            }

            var compensatingTransactionExecuter = new CompensatingTransactionExecuter();

            IEnumerable<ActivityTask<SendProductInstanceDetailsEmailToPartnerContext>> activityTasks = _activityTaskFactory.GetSendEmailWithProductInstanceDetailsActivityTasks();

            var activityTaskContext = new SendProductInstanceDetailsEmailToPartnerContext(_partner, _product, _productInstance);

            await compensatingTransactionExecuter.ExecuteSynchronouslyAsync(activityTasks, activityTaskContext);

            return null;
        }
    }
}