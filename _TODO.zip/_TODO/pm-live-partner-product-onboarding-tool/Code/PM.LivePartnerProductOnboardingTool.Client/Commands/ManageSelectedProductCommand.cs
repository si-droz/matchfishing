﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ManageSelectedProductCommand : Command
    {
        private readonly CommandFactory _commandFactory;
        private readonly Partner _partner;
        private readonly Product _product;

        public ManageSelectedProductCommand(IInputOutputManager inputOutputManager,
                                            CommandFactory commandFactory,
                                            Partner partner,
                                            Product product) :
            base(inputOutputManager, $"{partner.Name} : {product.Name}", false)
        {
            _commandFactory = commandFactory;
            _partner = partner;
            _product = product;
        }

        protected override Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            IReadOnlyCollection<Command> manageSelectedProductCommands = _commandFactory.GetManageSelectedProductCommands(_partner, _product);

            return Task.FromResult(manageSelectedProductCommands);
        }
    }
}