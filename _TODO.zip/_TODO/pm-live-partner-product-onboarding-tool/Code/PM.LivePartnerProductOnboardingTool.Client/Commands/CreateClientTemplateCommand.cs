﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class CreateClientTemplateCommand : Command
    {
        public const string HowManyClientCredentialTypeClientsAreRequiredQuestion = "How many Client Credential type clients are required?";

        private readonly PartnerRepository _partnerRepository;
        private readonly RoleRepository _roleRepository;
        private readonly Partner _partner;
        private readonly Product _product;

        public CreateClientTemplateCommand(IInputOutputManager inputOutputManager,
                                           PartnerRepository partnerRepository,
                                           RoleRepository roleRepository,
                                           Partner partner,
                                           Product product) : base(inputOutputManager, "Create Product Instance Template")
        {
            _partnerRepository = partnerRepository;
            _roleRepository = roleRepository;
            _partner = partner;
            _product = product;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            string input = InputOutputManager.AskQuestionAndWaitForStringInput(HowManyClientCredentialTypeClientsAreRequiredQuestion);
            int clientCredentialTypeClientsRequested = int.Parse(input);

            if(_product.ClientTemplates == null) _product.ClientTemplates = new List<ClientTemplate>();

            for(var clientCredentialInstanceIndex = 0;
                clientCredentialInstanceIndex < clientCredentialTypeClientsRequested;
                clientCredentialInstanceIndex++)
            {
                InputOutputManager.Clear();
                string clientFriendlyName = InputOutputManager.AskQuestionAndWaitForStringInput($"What is the customer friendly name of client {clientCredentialInstanceIndex + 1} of {clientCredentialTypeClientsRequested}?", ProductInstanceTemplateNameIsUnique);
                IList<string> apis = await _roleRepository.GetApisAsync();

                string apiType = InputOutputManager.DisplayListAndWaitForSingleSelection($"Please select the API type for {clientFriendlyName}.", apis);

                ApiRoleDefinition apiRoleDefinition = await _roleRepository.GetApiRoleDefinition(apiType);

                IEnumerable<string> roles = apiRoleDefinition.Roles;
                IEnumerable<string> selectedRoles = InputOutputManager.DisplayListAndWaitForConfirmation($"Please select the roles for {clientFriendlyName} which is a {apiType} type API.", roles);

                _product.ClientTemplates.Add(new ClientTemplate
                                             {
                                                 Id = Guid.NewGuid().ToString(),
                                                 Created = DateTime.UtcNow,
                                                 AccessibleScopes = apiRoleDefinition.Scopes.ToList(),
                                                 ApiType = apiType,
                                                 FriendlyName = clientFriendlyName,
                                                 ClientType = ClientType.ClientCredential,
                                                 AssociatedSecurityPrinciples = selectedRoles
                                             });
            }

            await _partnerRepository.UpdatePartnerAsync(_partner);

            return null;
        }

        private bool ProductInstanceTemplateNameIsUnique(string clientTemplateFriendlyName)
        {
            if(string.IsNullOrWhiteSpace(clientTemplateFriendlyName)) return false;

            return _product.ClientTemplates == null || _product.ClientTemplates.All(productInstance => productInstance.FriendlyName != clientTemplateFriendlyName);
        }
    }
}