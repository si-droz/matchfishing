﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class AssociateProductInstanceToOrganisationInputCommand : Command
    {
        private readonly ContextCommand<AssociateProductInstanceToOrganisationCommandContext> _contextCommand;
        private readonly Partner _partner;
        private readonly Product _product;
        private readonly ProductInstance _productInstance;

        public AssociateProductInstanceToOrganisationInputCommand(IInputOutputManager inputOutputManager,
                                                                  ContextCommand<AssociateProductInstanceToOrganisationCommandContext> contextCommand,
                                                                  Partner partner,
                                                                  Product product,
                                                                  ProductInstance productInstance)
            : base(inputOutputManager, $"Associate {partner.Name} : {product.Name} : {productInstance.Name} to Organisation.")
        {
            _contextCommand = contextCommand;
            _partner = partner;
            _product = product;
            _productInstance = productInstance;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            string organisationId = InputOutputManager.AskQuestionAndWaitForStringInput($"What is the organisation ID you wish to associate {_partner.Name} : {_product.Name} : {_productInstance.Name} to?", ValidateInputIsGuid);

            string organisationName = InputOutputManager.AskQuestionAndWaitForStringInput($"What is the organisation Name of organisation ID {organisationId}?", ValidateInputHasValue);

            var context = new AssociateProductInstanceToOrganisationCommandContext(_partner, _product, _productInstance, organisationId, organisationName);
            await _contextCommand.ExecuteAsync(context);

            return null;
        }

        private bool ValidateInputHasValue(string input)
        {
            return input.Any();
        }

        private bool ValidateInputIsGuid(string input)
        {
            return ValidateInputHasValue(input) && Guid.TryParse(input, out Guid result);
        }
    }
}