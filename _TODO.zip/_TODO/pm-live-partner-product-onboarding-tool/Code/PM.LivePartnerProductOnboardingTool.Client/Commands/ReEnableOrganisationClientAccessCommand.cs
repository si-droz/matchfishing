﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using Serilog;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ReEnableOrganisationClientAccessCommand : Command
    {
        private readonly IActivityTaskFactory _activityTaskFactory;
        private readonly AssociatedOrganisation _associatedOrganisation;
        private readonly Partner _partner;
        private readonly Product _product;
        private readonly ProductInstance _productInstance;

        public ReEnableOrganisationClientAccessCommand(IInputOutputManager inputOutputManager,
                                                       IActivityTaskFactory activityTaskFactory,
                                                       Partner partner,
                                                       Product product,
                                                       ProductInstance productInstance,
                                                       AssociatedOrganisation associatedOrganisation) :
            base(inputOutputManager, $"{partner.Name} : {product.Name} : {productInstance.Name} : {associatedOrganisation.Name}({associatedOrganisation.OrganisationId})")
        {
            _activityTaskFactory = activityTaskFactory;
            _associatedOrganisation = associatedOrganisation;
            _partner = partner;
            _product = product;
            _productInstance = productInstance;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            if(!InputOutputManager.AskQuestionAndWaitForYesOrNoInput($"IMPORTANT! Are you sure you want to re-enable access for all previously revoked clients to {_partner.Name} : {_product.Name} : {_productInstance.Name} : {_associatedOrganisation.Name}({_associatedOrganisation.OrganisationId}) y / n?"))
            {
                Log.Information("Client access revoke operation cancelled by user.");
                return null;
            }

            var compensatingTransactionExecuter = new CompensatingTransactionExecuter();

            IEnumerable<ActivityTask<ReEnableClientAccessToOrganisationContext>> activityTasks = _activityTaskFactory.GetRelinkClientAccessToOrganisationActivityTasks();

            var activityTaskContext = new ReEnableClientAccessToOrganisationContext(_partner, _product, _productInstance, _associatedOrganisation);

            await compensatingTransactionExecuter.ExecuteAllWithoutCompensationSynchronouslyAsync(activityTasks, activityTaskContext);

            return null;
        }
    }
}