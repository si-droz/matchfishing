﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Client.Extensions;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class CreateProductCommand : Command
    {
        public const string WhatIsTheProductNameQuestion = "What is the product name?";

        private readonly Partner _partner;
        private readonly PartnerRepository _partnerRepository;

        public CreateProductCommand(IInputOutputManager inputOutputManager, Partner partner, PartnerRepository partnerRepository) : base(inputOutputManager, "Create Product")
        {
            _partner = partner;
            _partnerRepository = partnerRepository;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            string productName = InputOutputManager.AskQuestionAndWaitForStringInput(WhatIsTheProductNameQuestion, ValidateProductName);

            if(_partner.Products == null) _partner.Products = new List<Product>();
            _partner.Products.Add(new Product
                                  {
                                      Id = Guid.NewGuid().ToString(),
                                      Name = productName,
                                      Created = DateTime.UtcNow
                                  });
            await _partnerRepository.UpdatePartnerAsync(_partner);
            return null;
        }

        private bool ValidateProductName(string productName)
        {
            if(!productName.ValidateForSpecialCharacters()) return false;

            return _partner.Products == null || _partner.Products.All(product => product.Name != productName);
        }
    }
}