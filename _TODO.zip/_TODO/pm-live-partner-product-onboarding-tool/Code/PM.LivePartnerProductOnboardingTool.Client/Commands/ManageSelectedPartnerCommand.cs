﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ManageSelectedPartnerCommand : Command
    {
        private readonly CommandFactory _commandFactory;
        private readonly Partner _partner;

        public ManageSelectedPartnerCommand(IInputOutputManager inputOutputManager, CommandFactory commandFactory, Partner partner) : base(inputOutputManager, partner.Name, false)
        {
            _commandFactory = commandFactory;
            _partner = partner;
        }

        protected override Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            IReadOnlyCollection<Command> managePartnerCommands = _commandFactory.GetManagePartnerCommands(_partner);

            return Task.FromResult(managePartnerCommands);
        }
    }
}