﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Client.Extensions;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class CreatePartnerCommand : Command
    {
        public const string WhatIsThePartnersNameQuestion = "What is the partners Name?";
        public const string WhatIsThePartnersContactTitleQuestion = "What is the partners contact Title?";
        public const string WhatIsThePartnersContactForenameQuestion = "What is the partners contact Forename?";
        public const string WhatIsThePartnersContactSurnameQuestion = "What is the partners contact Surname?";
        public const string WhatIsThePartnersContactWorkEmailQuestion = "What is the partners contact Work Email?";

        private readonly PartnerRepository _partnerRepository;

        private readonly EmailAddressAttribute _emailValidator = new EmailAddressAttribute();

        public CreatePartnerCommand(IInputOutputManager inputOutputManager, PartnerRepository partnerRepository) : base(inputOutputManager, "Create Partner")
        {
            _partnerRepository = partnerRepository;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            string partnerName = await InputOutputManager.AskQuestionAndWaitForStringInputAsync(WhatIsThePartnersNameQuestion, ValidatePartnerName);
            string contactTitle = InputOutputManager.AskQuestionAndWaitForStringInput(WhatIsThePartnersContactTitleQuestion, ValidateInputHasValue);
            string contactForename = InputOutputManager.AskQuestionAndWaitForStringInput(WhatIsThePartnersContactForenameQuestion, ValidateInputHasValue);
            string contactSurname = InputOutputManager.AskQuestionAndWaitForStringInput(WhatIsThePartnersContactSurnameQuestion, ValidateInputHasValue);
            string contactWorkEmail = InputOutputManager.AskQuestionAndWaitForStringInput(WhatIsThePartnersContactWorkEmailQuestion, ValidateEmailAddress);

            var partner = new Partner
                          {
                              Id = Guid.NewGuid().ToString(),
                              Name = partnerName,
                              Contact = new Contact
                                        {
                                            Forename = contactForename,
                                            Surname = contactSurname,
                                            Title = contactTitle,
                                            WorkEmail = contactWorkEmail
                                        },
                              Created = DateTime.UtcNow
                          };
            await _partnerRepository.CreatePartnerAsync(partner);
            return null;
        }

        private async Task<bool> ValidatePartnerName(string partnerName)
        {
            if(!partnerName.ValidateForSpecialCharacters()) return false;

            IEnumerable<Partner> partners = await _partnerRepository.GetPartnersAsync();

            return partners == null || partners.All(partner => partner.Name != partnerName);
        }

        private bool ValidateInputHasValue(string input)
        {
            return input.Any();
        }

        private bool ValidateEmailAddress(string emailAddress)
        {
            return !string.IsNullOrWhiteSpace(emailAddress) && _emailValidator.IsValid(emailAddress);
        }
    }
}