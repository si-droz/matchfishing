﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ListExistingProductsCommand : Command
    {
        private readonly CommandFactory _commandFactory;
        private readonly Partner _partner;

        public ListExistingProductsCommand(IInputOutputManager inputOutputManager, CommandFactory commandFactory, Partner partner) : base(inputOutputManager, "Manage Existing Product", false)
        {
            _commandFactory = commandFactory;
            _partner = partner;
        }

        protected override Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            var commands = new List<Command>();

            foreach(Product product in _partner.Products)
            {
                commands.Add(_commandFactory.GetManageSelectedProductCommand(_partner, product));
            }

            return Task.FromResult<IReadOnlyCollection<Command>>(commands.AsReadOnly());
        }
    }
}