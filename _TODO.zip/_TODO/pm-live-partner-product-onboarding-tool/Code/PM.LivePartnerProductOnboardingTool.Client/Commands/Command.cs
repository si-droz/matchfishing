﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using Serilog;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal abstract class Command
    {
        private readonly bool _waitForUserInputOnCompletion;

        protected Command(IInputOutputManager inputOutputManager, string displayText, bool waitForUserInputOnCompletion = true)
        {
            InputOutputManager = inputOutputManager;
            _waitForUserInputOnCompletion = waitForUserInputOnCompletion;
            DisplayText = displayText;
        }

        public async Task<IReadOnlyCollection<Command>> ExecuteAsync()
        {
            string commandName = GetType().Name;
            Log.Information("Executing command {commandName} with the display text of {DisplayText}", commandName, DisplayText);

            try
            {
                IReadOnlyCollection<Command> commandsToReturn = await ExecuteAsyncCore();

                Log.Information("Execution of command {DisplayText} completed with no uncaught exceptions. Press any key to continue.", DisplayText);

                if(_waitForUserInputOnCompletion) InputOutputManager.PressAnyKeyToContinue();

                return commandsToReturn;
            }
            catch(Exception ex)
            {
                Log.Error($"An error has occurred when executing the command {commandName} with the display text of {DisplayText}", commandName, DisplayText);
                Log.Error(ex, "");
                Log.Information("\n\nPress any key to continue.");
                InputOutputManager.PressAnyKeyToContinue();
            }

            return null;
        }

        protected abstract Task<IReadOnlyCollection<Command>> ExecuteAsyncCore();
        protected IInputOutputManager InputOutputManager { get; }
        public string DisplayText { get; }
    }
}