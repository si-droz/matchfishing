﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ManageSelectedProductInstanceCommand : Command
    {
        private readonly CommandFactory _commandFactory;
        private readonly Partner _partner;
        private readonly Product _product;
        private readonly ProductInstance _productInstance;

        public ManageSelectedProductInstanceCommand(IInputOutputManager inputOutputManager,
                                                    CommandFactory commandFactory,
                                                    Partner partner,
                                                    Product product,
                                                    ProductInstance productInstance) :
            base(inputOutputManager, $"{partner.Name} : {product.Name} : {productInstance.Name}", false)
        {
            _commandFactory = commandFactory;
            _partner = partner;
            _product = product;
            _productInstance = productInstance;
        }

        protected override Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            IReadOnlyCollection<Command> manageSelectedProductCommands = _commandFactory.GetManageSelectedProductInstanceCommands(_partner, _product, _productInstance);

            return Task.FromResult(manageSelectedProductCommands);
        }
    }
}