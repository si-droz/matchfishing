﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Client.Extensions;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class CreateProductInstanceCommand : Command
    {
        public const string WhatIsTheNameOfThisProductInstanceQuestion = "What is the name of this product instance?";

        private readonly IActivityTaskFactory _activityTaskFactory;
        private readonly PartnerRepository _partnerRepository;
        private readonly Partner _partner;
        private readonly Product _product;

        public CreateProductInstanceCommand(IInputOutputManager inputOutputManager,
                                            IActivityTaskFactory activityTaskFactory,
                                            PartnerRepository partnerRepository,
                                            Partner partner,
                                            Product product) : base(inputOutputManager, "Create Product Instance")
        {
            _activityTaskFactory = activityTaskFactory;
            _partnerRepository = partnerRepository;
            _partner = partner;
            _product = product;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            string productInstanceName = InputOutputManager.AskQuestionAndWaitForStringInput(WhatIsTheNameOfThisProductInstanceQuestion, ValidateProductInstanceNameIsUnique);

            var compensatingTransactionExecuter = new CompensatingTransactionExecuter();

            var successfullyCompletedContexts = new List<CreateClientTemplateInstanceContext>();

            foreach(ClientTemplate clientTemplate in _product.ClientTemplates)
            {
                IEnumerable<ActivityTask<CreateClientTemplateInstanceContext>> activityTasks = _activityTaskFactory.GetCreateClientInstanceActivityTasks(clientTemplate);

                var context = new CreateClientTemplateInstanceContext(_partner, _product, clientTemplate);

                ActivityOutcome activityOutcome = await compensatingTransactionExecuter.ExecuteSynchronouslyAsync(activityTasks, context);

                if(activityOutcome.CompletedSuccessfully) successfullyCompletedContexts.Add(context);
            }

            //THOUGHT: It might be worth putting this (the Partner Product Instance update in a ActivityTask too and do it each time a client is created... Not too sure at the moment.
            if(_product.ProductInstances == null) _product.ProductInstances = new List<ProductInstance>();

            var productInstance = new ProductInstance
                                  {
                                      Created = DateTime.UtcNow,
                                      Name = productInstanceName,
                                      ClientInstances = new List<ClientInstance>()
                                  };
            _product.ProductInstances.Add(productInstance);

            foreach(CreateClientTemplateInstanceContext context in successfullyCompletedContexts)
            {
                productInstance.ClientInstances.Add(new ClientInstance
                                                    {
                                                        Created = DateTime.UtcNow,
                                                        ClientId = context.ClientId,
                                                        AzureApiManagementUserId = context.AzureManagementApiUserId,
                                                        AzureApiManagementSubscriptionId = context.AzureManagementApiSubscriptionId,
                                                        CreatedFromTemplateId = context.ClientTemplate.Id
                                                    });
            }

            await _partnerRepository.UpdatePartnerAsync(_partner);

            return null;
        }

        private bool ValidateProductInstanceNameIsUnique(string productInstanceName)
        {
            if(!productInstanceName.ValidateForSpecialCharacters()) return false;

            return _product.ProductInstances == null || _product.ProductInstances.All(productInstance => productInstance.Name != productInstanceName);
        }
    }
}