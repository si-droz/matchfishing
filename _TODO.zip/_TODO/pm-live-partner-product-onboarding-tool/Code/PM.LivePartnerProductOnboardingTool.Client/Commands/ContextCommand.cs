﻿using System.Threading.Tasks;
using Newtonsoft.Json;
using Serilog;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal abstract class ContextCommand<TContext>
    {
        public async Task ExecuteAsync(TContext context)
        {
            string commandName = GetType().Name;
            string contextJson = JsonConvert.SerializeObject(context);
            Log.Information("Executing Context Command {commandName} with the context of {contextJson}", commandName, contextJson);
            await ExecuteCoreAsync(context);
            Log.Information("Execution of Context Command {commandName} completed with no uncaught exceptions.", commandName);
        }

        protected abstract Task ExecuteCoreAsync(TContext context);
    }
}