﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ListExistingProductInstancesCommand : Command
    {
        private readonly CommandFactory _commandFactory;
        private readonly Partner _partner;
        private readonly Product _product;

        public ListExistingProductInstancesCommand(IInputOutputManager inputOutputManager, CommandFactory commandFactory, Partner partner, Product product) :
            base(inputOutputManager, "Manage Existing Partner Instances", false)
        {
            _commandFactory = commandFactory;
            _partner = partner;
            _product = product;
        }

        protected override Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            var commands = new List<Command>();

            foreach(ProductInstance productInstance in _product.ProductInstances ?? new List<ProductInstance>())
            {
                commands.Add(_commandFactory.GetManageSelectedProductInstanceCommand(_partner, _product, productInstance));
            }

            return Task.FromResult<IReadOnlyCollection<Command>>(commands.AsReadOnly());
        }
    }
}