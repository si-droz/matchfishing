﻿using System.Collections.Generic;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class CommandFactory
    {
        private readonly IUnityContainer _unityContainer;
        private readonly IInputOutputManager _inputOutputManager;

        public CommandFactory(IUnityContainer unityContainer)
        {
            _unityContainer = unityContainer;
            _inputOutputManager = _unityContainer.Resolve<IInputOutputManager>();
        }

        public IReadOnlyCollection<Command> GetRootCommands()
        {
            return new List<Command>
                   {
                       _unityContainer.Resolve<CreatePartnerCommand>(),
                       _unityContainer.Resolve<ListExistingPartnersCommand>()
                   };
        }

        public IReadOnlyCollection<Command> GetManagePartnerCommands(Partner partner)
        {
            return new List<Command>
                   {
                       GetCreateProductCommand(partner),
                       new ListExistingProductsCommand(_inputOutputManager, this, partner)
                   }.AsReadOnly();
        }

        public Command GetCreateProductCommand(Partner partner)
        {
            var partnerRepository = _unityContainer.Resolve<PartnerRepository>();
            return new CreateProductCommand(_inputOutputManager, partner, partnerRepository);
        }

        public Command GetManageExistingPartnerCommand(Partner partner)
        {
            return new ManageSelectedPartnerCommand(_inputOutputManager, this, partner);
        }

        public Command GetManageSelectedProductCommand(Partner partner, Product product)
        {
            return new ManageSelectedProductCommand(_inputOutputManager, this, partner, product);
        }

        public Command GetManageSelectedProductInstanceCommand(Partner partner, Product product, ProductInstance productInstance)
        {
            return new ManageSelectedProductInstanceCommand(_inputOutputManager, this, partner, product, productInstance);
        }

        public IReadOnlyCollection<Command> GetManageSelectedProductCommands(Partner partner, Product product)
        {
            return new List<Command>
                   {
                       GetCreateProductInstanceTemplateCommand(partner, product),
                       GetCreateProductInstanceCommand(partner, product),
                       new ListExistingProductInstancesCommand(_inputOutputManager, this, partner, product)
                   };
        }

        public IReadOnlyCollection<Command> GetManageSelectedProductInstanceCommands(Partner partner, Product product, ProductInstance productInstance)
        {
            var activityTaskFactory = _unityContainer.Resolve<IActivityTaskFactory>();
            return new List<Command>
                   {
                       GetAssociateProductInstanceToOrganisationCommand(partner, product, productInstance),
                       new ListExistingProductInstancesRevokeCommand(_inputOutputManager, this, partner, product, productInstance),
                       new ListExistingProductInstancesReEnableCommand(_inputOutputManager, this, partner, product, productInstance),
                       new SendEmailWithProductInstanceDetailsCommand(_inputOutputManager, activityTaskFactory, partner, product, productInstance)
                   };
        }

        public Command GetCreateProductInstanceTemplateCommand(Partner partner, Product product)
        {
            var partnerRepository = _unityContainer.Resolve<PartnerRepository>();
            var roleRepository = _unityContainer.Resolve<RoleRepository>();
            return new CreateClientTemplateCommand(_inputOutputManager, partnerRepository, roleRepository, partner, product);
        }

        public Command GetCreateProductInstanceCommand(Partner partner, Product product)
        {
            var activityTaskFactory = _unityContainer.Resolve<IActivityTaskFactory>();
            var partnerRepository = _unityContainer.Resolve<PartnerRepository>();
            return new CreateProductInstanceCommand(_inputOutputManager, activityTaskFactory, partnerRepository, partner, product);
        }

        public Command GetAssociateProductInstanceToOrganisationCommand(Partner partner, Product product, ProductInstance productInstance)
        {
            var associateProductInstanceToOrganisationContextCommand = _unityContainer.Resolve<AssociateProductInstanceToOrganisationContextCommand>();
            return new AssociateProductInstanceToOrganisationInputCommand(_inputOutputManager, associateProductInstanceToOrganisationContextCommand, partner, product, productInstance);
        }

        public Command GetRevokeOrganisationClientAccessCommand(Partner partner, Product product, ProductInstance productInstance, AssociatedOrganisation associatedOrganisation)
        {
            var activityTaskFactory = _unityContainer.Resolve<IActivityTaskFactory>();
            return new RevokeOrganisationClientAccessCommand(_inputOutputManager, activityTaskFactory, partner, product, productInstance, associatedOrganisation);
        }

        public Command GetReEnableOrganisationClientAccessCommand(Partner partner, Product product, ProductInstance productInstance, AssociatedOrganisation associatedOrganisation)
        {
            var activityTaskFactory = _unityContainer.Resolve<IActivityTaskFactory>();
            return new ReEnableOrganisationClientAccessCommand(_inputOutputManager, activityTaskFactory, partner, product, productInstance, associatedOrganisation);
        }
    }
}