﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.Commands.Contexts;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction;
using PM.LivePartnerProductOnboardingTool.Client.CompensatingTransaction.Implementation;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class AssociateProductInstanceToOrganisationContextCommand : ContextCommand<AssociateProductInstanceToOrganisationCommandContext>
    {
        private readonly IActivityTaskFactory _activityTaskFactory;
        private readonly PartnerRepository _partnerRepository;

        public AssociateProductInstanceToOrganisationContextCommand(IActivityTaskFactory activityTaskFactory, PartnerRepository partnerRepository)
        {
            _activityTaskFactory = activityTaskFactory;
            _partnerRepository = partnerRepository;
        }

        protected override async Task ExecuteCoreAsync(AssociateProductInstanceToOrganisationCommandContext commandContext)
        {
            ICompensatingTransactionExecuter compensatingTransactionExecuter = new CompensatingTransactionExecuter();

            foreach(ClientInstance clientInstance in commandContext.ProductInstance.ClientInstances)
            {
                ClientTemplate creationClientTemplate = commandContext.Product.ClientTemplates.SingleOrDefault(clientTemplate => clientTemplate.Id == clientInstance.CreatedFromTemplateId);
                if(creationClientTemplate == null) throw new InvalidOperationException($"The Product Client Template with the ID of {clientInstance.CreatedFromTemplateId} cannot be found in the Product with the ID of {commandContext.Product.Id}. Something has gone wrong somewhere. Check the Products configuration document.");

                IEnumerable<ActivityTask<AssociateProductInstanceClientToOrganisationContext>> activityTasks = _activityTaskFactory.GetAssociateProductInstanceClientToOrganisationActivityTasks(creationClientTemplate);

                var context = new AssociateProductInstanceClientToOrganisationContext(commandContext.Partner,
                                                                                      commandContext.Product,
                                                                                      clientInstance,
                                                                                      commandContext.OrganisationId);
                await compensatingTransactionExecuter.ExecuteSynchronouslyAsync(activityTasks, context);
            }

            var associatedOrganisations = commandContext.ProductInstance.AssociatedOrganisations ?? new List<AssociatedOrganisation>();

            if(associatedOrganisations.Any(associatedOrganisation => associatedOrganisation.OrganisationId == commandContext.OrganisationId)) return;

            associatedOrganisations.Add(new AssociatedOrganisation
                                        {
                                            Created = DateTime.UtcNow,
                                            Id = Guid.NewGuid().ToString(),
                                            Name = commandContext.OrganisationName,
                                            OrganisationId = commandContext.OrganisationId,
                                            IsActive = true
                                        });

            commandContext.ProductInstance.AssociatedOrganisations = associatedOrganisations;

            await _partnerRepository.UpdatePartnerAsync(commandContext.Partner);
        }
    }
}