﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ListExistingProductInstancesRevokeCommand : Command
    {
        private readonly CommandFactory _commandFactory;
        private readonly Partner _partner;
        private readonly Product _product;
        private readonly ProductInstance _productInstance;

        public ListExistingProductInstancesRevokeCommand(IInputOutputManager inputOutputManager,
                                                         CommandFactory commandFactory,
                                                         Partner partner,
                                                         Product product,
                                                         ProductInstance productInstance) :
            base(inputOutputManager, $"Revoke {partner.Name} : {product.Name} : {productInstance.Name} client access to Organisation", false)
        {
            _commandFactory = commandFactory;
            _partner = partner;
            _product = product;
            _productInstance = productInstance;
        }

        protected override Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            var commands = new List<Command>();

            foreach(AssociatedOrganisation associatedOrganisation in _productInstance.AssociatedOrganisations.Where(organisation => organisation.IsActive))
            {
                commands.Add(_commandFactory.GetRevokeOrganisationClientAccessCommand(_partner, _product, _productInstance, associatedOrganisation));
            }

            return Task.FromResult<IReadOnlyCollection<Command>>(commands.AsReadOnly());
        }
    }
}