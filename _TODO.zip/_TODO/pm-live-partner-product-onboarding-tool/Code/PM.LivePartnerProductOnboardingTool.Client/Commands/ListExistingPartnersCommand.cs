﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Storage;
using PM.LivePartnerProductOnboardingTool.Storage.Entities.V1;

namespace PM.LivePartnerProductOnboardingTool.Client.Commands
{
    internal class ListExistingPartnersCommand : Command
    {
        private readonly CommandFactory _commandFactory;
        private readonly PartnerRepository _partnerRepository;

        public ListExistingPartnersCommand(IInputOutputManager inputOutputManager, CommandFactory commandFactory, PartnerRepository partnerRepository) : base(inputOutputManager, "Manage Existing Partners", false)
        {
            _commandFactory = commandFactory;
            _partnerRepository = partnerRepository;
        }

        protected override async Task<IReadOnlyCollection<Command>> ExecuteAsyncCore()
        {
            IEnumerable<Partner> partners = await _partnerRepository.GetPartnersAsync();

            var mangePartnerCommands = new List<Command>();

            foreach(Partner partner in partners)
            {
                Command manageExistingPartnerCommand = _commandFactory.GetManageExistingPartnerCommand(partner);
                mangePartnerCommands.Add(manageExistingPartnerCommand);
            }

            return mangePartnerCommands.AsReadOnly();
        }
    }
}