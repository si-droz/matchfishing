﻿using System.Text.RegularExpressions;

namespace PM.LivePartnerProductOnboardingTool.Client.Extensions
{
    internal static class StringValidatorExtension
    {
        public static bool ValidateForSpecialCharacters(this string value)
        {
            if(string.IsNullOrWhiteSpace(value)) return false;

            const string allowedCharacters = @"^[\w\s-_]+$";

            Regex regex = new Regex(allowedCharacters);

            return regex.IsMatch(value);
        }
    }
}