﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Serilog;

namespace PM.LivePartnerProductOnboardingTool.Client.Control.Implementation
{
    internal class ConsoleInputOutputManager : IInputOutputManager
    {
        public void Clear()
        {
            Console.Clear();
        }

        public string AskQuestionAndWaitForStringInput(string question)
        {
            Console.WriteLine(question);
            string answer = Console.ReadLine();

            string userName = ClaimsPrincipal.Current.Identity.Name;
            Log.Information("User {userName} asked: {question} responded: {answer}", userName, question, answer);
            return answer;
        }

        public string AskQuestionAndWaitForStringInput(string question, Predicate<string> validator)
        {
            string answer;
            do
            {
                Console.WriteLine(question);
                answer = Console.ReadLine();
            } while(!validator.Invoke(answer));

            string userName = ClaimsPrincipal.Current.Identity.Name;
            Log.Information("User {userName} asked: {question} responded: {answer}", userName, question, answer);
            return answer;
        }

        public async Task<string> AskQuestionAndWaitForStringInputAsync(string question, AsyncPredicate<string> validator)
        {
            string answer;
            do
            {
                Console.WriteLine(question);
                answer = Console.ReadLine();
            } while(!await validator.Invoke(answer));

            string userName = ClaimsPrincipal.Current.Identity.Name;
            Log.Information("User {userName} asked: {question} responded: {answer}", userName, question, answer);
            return answer;
        }

        public char AskQuestionAndWaitForCharInput(string question)
        {
            string userName = ClaimsPrincipal.Current.Identity.Name;
            Console.WriteLine(question);
            char answer = Console.ReadKey().KeyChar;
            Log.Information("User {userName} asked: {question} responded: {answer}", userName, question, answer);
            return answer;
        }

        public bool AskQuestionAndWaitForYesOrNoInput(string question)
        {
            char yesOrNo = AskQuestionAndWaitForCharInput(question);

            return yesOrNo == 'y' || yesOrNo == 'Y';
        }

        public void PressAnyKeyToContinue()
        {
            Console.ReadKey();
        }

        public IEnumerable<string> DisplayListAndWaitForConfirmation(string message, IEnumerable<string> items)
        {
            List<Choice<string>> itemChoices = items.Select(item => new Choice<string>(item)).ToList();

            string input;
            do
            {
                Console.Clear();
                Console.WriteLine(message);
                for(var index = 0; index < itemChoices.Count; index++)
                {
                    Choice<string> itemChoice = itemChoices[index];
                    char isSelected = itemChoice.Selected ? 'X' : '-';
                    Console.WriteLine($"{index + 1,3} [{isSelected}]:{itemChoice.Item}");
                }

                Console.WriteLine("Enter role number or enter x to continue");
                input = Console.ReadLine();
                if(!string.IsNullOrWhiteSpace(input) && input != "x")
                {
                    if(input.Contains("-"))
                    {
                        SelectMultipleItemChoices(input, itemChoices);
                    }
                    else
                    {
                        if(int.TryParse(input, out int numericInput)) SelectItemChoice(numericInput, itemChoices);
                    }
                }
            } while(input != "x");

            List<string> selectedItems = itemChoices.Where(itemChoice => itemChoice.Selected)
                                                    .Select(itemChoice => itemChoice.Item)
                                                    .ToList();

            string userName = ClaimsPrincipal.Current.Identity.Name;
            Log.Information("User {userName} given list: {inputList} selected: {answer}", userName, items, selectedItems);

            return new ReadOnlyCollection<string>(selectedItems);
        }

        public string DisplayListAndWaitForSingleSelection(string message, IList<string> items)
        {
            Console.WriteLine(message);
            for(int index = 0; index < items.Count; index++)
            {
                Console.WriteLine($"{index + 1}: {items[index]}");
            }

            int selection;
            int maxItems = items.Count - 1;
            bool isValid;
            do
            {
                string input = Console.ReadLine();
                int.TryParse(input, out selection);
                isValid = selection > 0 && selection <= maxItems;
            } while(!isValid);

            string answer = items[selection - 1];

            string userName = ClaimsPrincipal.Current.Identity.Name;
            Log.Information("User {userName} asked: {message} responded: {answer}", userName, message, answer);
            return answer;
        }

        private static void SelectMultipleItemChoices(string input, IReadOnlyList<Choice<string>> itemChoices)
        {
            var selectedValues = input.Split('-');

            if(selectedValues.Length == 2 &&
               int.TryParse(selectedValues[0], out int from) &&
               int.TryParse(selectedValues[1], out int to) &&
               from < to)
            {
                for(int multiSelectIndex = from; multiSelectIndex <= to; multiSelectIndex++)
                {
                    SelectItemChoice(multiSelectIndex, itemChoices);
                }
            }
        }

        private static void SelectItemChoice(int numericInput, IReadOnlyList<Choice<string>> itemChoices)
        {
            if(numericInput >= 0 && numericInput <= itemChoices.Count)
            {
                Choice<string> itemChoice = itemChoices[numericInput - 1];
                itemChoice.Selected = !itemChoice.Selected;
            }
        }

        private class Choice<T>
        {
            public Choice(T item)
            {
                Item = item;
            }

            public bool Selected { get; set; }
            public T Item { get; }
        }
    }
}