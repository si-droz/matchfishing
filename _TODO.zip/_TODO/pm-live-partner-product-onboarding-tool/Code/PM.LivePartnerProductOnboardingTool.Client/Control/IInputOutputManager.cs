﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PM.LivePartnerProductOnboardingTool.Client.Control
{
    internal interface IInputOutputManager
    {
        void Clear();
        string AskQuestionAndWaitForStringInput(string question);
        string AskQuestionAndWaitForStringInput(string question, Predicate<string> validator);
        Task<string> AskQuestionAndWaitForStringInputAsync(string question, AsyncPredicate<string> validator);
        char AskQuestionAndWaitForCharInput(string question);
        bool AskQuestionAndWaitForYesOrNoInput(string question);
        void PressAnyKeyToContinue();
        IEnumerable<string> DisplayListAndWaitForConfirmation(string message, IEnumerable<string> items);
        string DisplayListAndWaitForSingleSelection(string message, IList<string> items);
    }

    public delegate Task<bool> AsyncPredicate<in T>(T obj);
}