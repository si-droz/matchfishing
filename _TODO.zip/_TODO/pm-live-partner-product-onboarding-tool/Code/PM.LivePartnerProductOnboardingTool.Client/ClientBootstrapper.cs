﻿using PM.LivePartnerProductOnboardingTool.Client.Commands;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks;
using PM.LivePartnerProductOnboardingTool.Client.Commands.ActivityTasks.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.Control;
using PM.LivePartnerProductOnboardingTool.Client.Control.Implementation;
using PM.LivePartnerProductOnboardingTool.Client.Support;
using PM.LivePartnerProductOnboardingTool.Client.Support.Implementation;
using Unity;

namespace PM.LivePartnerProductOnboardingTool.Client
{
    internal static class ClientBootstrapper
    {
        public static IUnityContainer RegisterClientDependencies(this IUnityContainer unityContainer)
        {
            return unityContainer.RegisterType<CommandFactory>()
                                 .RegisterType<IHttpClientFactory, HttpClientFactory>()
                                 .RegisterType<CreatePartnerCommand>()
                                 .RegisterType<CreateProductCommand>()
                                 .RegisterType<ListExistingPartnersCommand>()
                                 .RegisterType<IActivityTaskFactory, ActivityTaskFactory>()
                                 .RegisterType<ISendGridFactory, SendGridFactory>()
                                 .RegisterSingleton<IInputOutputManager, ConsoleInputOutputManager>();
        }
    }
}