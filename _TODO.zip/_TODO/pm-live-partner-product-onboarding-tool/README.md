# Introduction 
The Partner Management - Live Partner Product Onboarding Tool is a command line driven tool that enables a Partner Management administrator to perform the current actions:

* Create a new Partner in the live data store
* Create and associate a Product to the Partner
* Create and associate a Product Instance Template to the Partner Product
* Create a Product Instance which will provision the relevant systems in SIMS ID, Azure API Manager and generate a configuration file for the SIMS Primary onboarding tool.
* Send information to the specified partner about their Product Instance

# Terminology
* Partner - An person/organisation that has been greenlit to use the SIMS Partner Management API's
* Product - A definition of a Partners software product which details how the product is set up with the various surrounding systems.
* Product Instance Template - Defines how an instance of a product manifests itself in systems that the Partner Management product uses. In this case SIMS ID, Azure API Management and SIMS Primary
* Product Instance - A physical deployment of the Product's Product Instance Template. A product may be:
    * Single Instance - There is one deployment of the Product's Instance Template. This is usually used when the Partner has a centralised cloud system and accesses all associated SIMS Primary Tenants from there.
    * Multi Instance - There is more than one deployment of the Product's Product Instance Template. Each deployment will be named uniquely dependent on the domain of the Partner. For example a Partner System that is deployed in LA's may use the LA names to uniquely define their deployments. The name should be fit for the Partners Customers consumption as they will be using this to select which instance of the Partner Product they wish to use (when the App Store comes). 
    
        Each deployment of an instance can be associated to specific organisations uniquely. This gives a level of isolation between the instances ensuring one instance cannot access another instances organisations.

# Getting Started
The Partner Management - Live Partner Product Onboarding Tool uses Cosmos DB to store its configuration information. You must download and install the Cosmos DB Emulator to get developing locally. Please visit the Cosmos DB introduction documentation [here](https://docs.microsoft.com/en-us/azure/cosmos-db/local-emulator).

# Technical choice reasoning
Cosmos DB was chosen as the persistance mechanism for a number of reasons:
* It is very cheap compared to hosting a SQL Database server (pennies for the volume of data per month vs £10 - £60 dependent on deployment style).
* Document storage is a very quick and easy to get up and running
* Document storage works perfectly for the scenario here
* Azure Active Directory, the Azure Portal and a number of other Microsoft based cloud systems use Cosmos DB as a backend for storing their configuration information

# Build and Test
There will be a build and release plan as per our other software products.